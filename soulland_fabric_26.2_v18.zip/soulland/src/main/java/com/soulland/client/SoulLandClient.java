package com.soulland.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.soulland.Actions;
import com.soulland.SoulLand;
import com.soulland.net.ActionPayload;
import com.soulland.net.AwakenPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public class SoulLandClient implements ClientModInitializer {
    private static final KeyMapping.Category CATEGORY =
            KeyMapping.Category.register(Identifier.fromNamespaceAndPath(SoulLand.MOD_ID, "main"));

    private static KeyMapping key(String name, int code) {
        return KeyMappingHelper.registerKeyMapping(
                new KeyMapping("key.soulland." + name, InputConstants.Type.KEYSYM, code, CATEGORY));
    }

    @Override
    public void onInitializeClient() {
        HudElementRegistry.addLast(
                Identifier.fromNamespaceAndPath(SoulLand.MOD_ID, "soul_hud"),
                SoulHud::extract);

        KeyMapping awaken = key("awaken", GLFW.GLFW_KEY_M);
        KeyMapping reroll = key("reroll", GLFW.GLFW_KEY_N);
        KeyMapping toggleSoul = key("toggle_soul", GLFW.GLFW_KEY_G);
        KeyMapping toggleRings = key("toggle_rings", GLFW.GLFW_KEY_H);
        KeyMapping nextSkill = key("next_skill", GLFW.GLFW_KEY_V);
        KeyMapping useSkill = key("use_skill", GLFW.GLFW_KEY_R);

        // วงแหวนใต้เท้า: วาดเองฝั่งไคลเอนต์ทุกเฟรม (ไม่ใช้เอนทิตี/พาร์ติเคิล)
        LevelRenderEvents.COLLECT_SUBMITS.register(context -> {
            Minecraft mc = Minecraft.getInstance();
            float partial = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);
            var cam = context.levelState().cameraRenderState.pos;
            java.util.List<RingRenderer.Draw> draws = RingRenderer.collect(mc, partial);
            java.util.List<KnightRenderer.Quad> quads = KnightRenderer.collect(mc, partial, cam.x, cam.z);
            if (draws.isEmpty() && quads.isEmpty()) return;
            var collector = context.submitNodeCollector();
            for (RingRenderer.Draw d : draws) {
                var renderType = RenderTypes.entityTranslucentEmissive(d.texture());
                collector.submitCustomGeometry(new PoseStack(), renderType,
                        (pose, buffer) -> RingRenderer.writeQuad(pose, buffer, d, cam.x, cam.y, cam.z));
            }
            for (KnightRenderer.Quad q : quads) {
                var renderType = RenderTypes.entityTranslucentEmissive(q.texture());
                collector.submitCustomGeometry(new PoseStack(), renderType,
                        (pose, buffer) -> KnightRenderer.write(pose, buffer, q, cam.x, cam.y, cam.z));
            }
        });

        // อนิเมชั่นปลุกวิญญาณยุทธ์ (เซิร์ฟเวอร์สั่งเริ่ม)
        ClientPlayNetworking.registerGlobalReceiver(AwakenPayload.TYPE,
                (payload, context) -> AwakenAnim.start(Minecraft.getInstance()));
        ClientTickEvents.START_CLIENT_TICK.register(AwakenAnim::tickStart);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            AwakenAnim.tick(client);
            RingRenderer.tick(client);
            if (client.player == null) return;
            poll(awaken, Actions.AWAKEN);
            poll(reroll, Actions.REROLL);
            poll(toggleSoul, Actions.TOGGLE_SOUL);
            poll(toggleRings, Actions.TOGGLE_RINGS);
            poll(nextSkill, Actions.NEXT_SKILL);
            poll(useSkill, Actions.USE_SKILL);
        });
    }

    private static void poll(KeyMapping key, int action) {
        while (key.consumeClick()) {
            ClientPlayNetworking.send(new ActionPayload(action));
        }
    }
}
