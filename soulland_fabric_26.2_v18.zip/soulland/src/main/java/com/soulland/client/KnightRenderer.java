package com.soulland.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.soulland.Soul;
import com.soulland.SoulLand;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

import java.util.ArrayList;
import java.util.List;

/**
 * อัศวินศักดิ์สิทธิ์ (เปิดวิญญาณยุทธ์): ปีกเทวดาด้านหลัง + ฮาโลเหนือหัว
 * วาดฝั่งไคลเอนต์ทุกเฟรมจากภาพอ้างอิง (ปีกกระพือเบาๆ ฮาโลหันเข้าหากล้อง)
 */
public final class KnightRenderer {
    private static final Identifier WING = Identifier.fromNamespaceAndPath(SoulLand.MOD_ID, "textures/fx/wing.png");
    private static final Identifier HALO = Identifier.fromNamespaceAndPath(SoulLand.MOD_ID, "textures/fx/halo.png");

    /** สี่เหลี่ยม 4 มุม (พิกัดโลก) + UV */
    public record Quad(Identifier texture, double[] p, float[] u, float[] v) {}

    private KnightRenderer() {}

    private static Quad quad(Identifier tex, double[] p, float[] u, float[] v) {
        return new Quad(tex, p, u, v);
    }

    public static List<Quad> collect(Minecraft mc, float partial, double camX, double camZ) {
        List<Quad> out = new ArrayList<>();
        LocalPlayer pl = mc.player;
        if (pl == null || !Soul.KNIGHT.equals(Soul.soul(pl)) || !Soul.soulOpen(pl)) return out;
        if (mc.options.getCameraType().isFirstPerson()) return out;

        double px = Mth.lerp((double) partial, pl.xo, pl.getX());
        double py = Mth.lerp((double) partial, pl.yo, pl.getY());
        double pz = Mth.lerp((double) partial, pl.zo, pl.getZ());
        float bodyYaw = Mth.rotLerp(partial, pl.yBodyRotO, pl.yBodyRot);
        double ang = Math.toRadians(bodyYaw);
        double fx = -Math.sin(ang), fz = Math.cos(ang);   // ทิศหน้า
        double lx = Math.cos(ang), lz = Math.sin(ang);    // ซ้ายของผู้เล่น
        double t = (mc.level != null ? mc.level.getGameTime() : 0) + partial;
        double h = pl.getBbHeight();

        // ---- ปีก 2 ข้าง ----
        double shoulderY = py + h * 0.55;
        double wingW = 2.3;
        double wingH = wingW * 267.0 / 256.0;
        for (int s = 1; s >= -1; s -= 2) {
            double alpha = Math.toRadians(40 + Math.sin(t * 0.12) * 7);
            double ldx = s * lx * Math.cos(alpha) - fx * Math.sin(alpha);
            double ldz = s * lz * Math.cos(alpha) - fz * Math.sin(alpha);
            double lean = Math.toRadians(14);
            double udx = -fx * Math.sin(lean), udz = -fz * Math.sin(lean), udy = Math.cos(lean);
            double ox = px - fx * 0.22 + s * lx * 0.1;
            double oy = shoulderY - 0.2;
            double oz = pz - fz * 0.22 + s * lz * 0.1;
            double[][] ab = {{0, 0}, {1, 0}, {1, 1}, {0, 1}};
            double[] p = new double[12];
            float[] u = new float[4];
            float[] v = new float[4];
            for (int i = 0; i < 4; i++) {
                double a = ab[i][0], b = ab[i][1];
                p[i * 3] = ox + ldx * a * wingW + udx * b * wingH;
                p[i * 3 + 1] = oy + udy * b * wingH;
                p[i * 3 + 2] = oz + ldz * a * wingW + udz * b * wingH;
                u[i] = (float) (s > 0 ? 1.0 - a : a);   // ปีกซ้ายใช้ภาพตรง ปีกขวากลับด้าน
                v[i] = (float) (1.0 - b);
            }
            out.add(quad(WING, p, u, v));
        }

        // ---- ฮาโลเหนือหัว (หันเข้าหากล้อง) ----
        double cy = py + h + 0.5;
        double nx = camX - px, nz = camZ - pz;
        double nl = Math.max(1e-6, Math.hypot(nx, nz));
        nx /= nl;
        nz /= nl;
        double ax = -nz, az = nx;                           // แกนซ้าย-ขวาของฮาโล
        double pulse = 1.0 + 0.04 * Math.sin(t * 0.1);
        double hw = 0.65 * pulse, hh = hw * 214.0 / 256.0;
        double[][] c = {{-1, -1}, {1, -1}, {1, 1}, {-1, 1}};
        float[] hu = {0f, 1f, 1f, 0f};
        float[] hv = {1f, 1f, 0f, 0f};
        double[] hp = new double[12];
        for (int i = 0; i < 4; i++) {
            hp[i * 3] = px + ax * c[i][0] * hw;
            hp[i * 3 + 1] = cy + c[i][1] * hh;
            hp[i * 3 + 2] = pz + az * c[i][0] * hw;
        }
        out.add(quad(HALO, hp, hu, hv));
        return out;
    }

    public static void write(PoseStack.Pose pose, VertexConsumer buf, Quad q, double cx, double cy, double cz) {
        for (int i = 0; i < 4; i++) {
            vertex(buf, pose, (float) (q.p()[i * 3] - cx), (float) (q.p()[i * 3 + 1] - cy), (float) (q.p()[i * 3 + 2] - cz),
                    q.u()[i], q.v()[i], 1f);
        }
        for (int i = 3; i >= 0; i--) {
            vertex(buf, pose, (float) (q.p()[i * 3] - cx), (float) (q.p()[i * 3 + 1] - cy), (float) (q.p()[i * 3 + 2] - cz),
                    q.u()[i], q.v()[i], -1f);
        }
    }

    private static void vertex(VertexConsumer buf, PoseStack.Pose pose, float x, float y, float z, float u, float v, float ny) {
        buf.addVertex(pose, x, y, z)
                .setColor(0xFFFFFFFF)
                .setUv(u, v)
                .setOverlay(655360)
                .setLight(15728880)
                .setNormal(pose, 0f, ny, 0f);
    }
}
