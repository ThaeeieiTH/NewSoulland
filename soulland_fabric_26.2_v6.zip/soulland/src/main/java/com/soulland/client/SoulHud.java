package com.soulland.client;

import com.soulland.Soul;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;

/** HUD มุมซ้ายบน: หัวข้อ Soul Land / วิญญาณยุทธ์ / เลเวล / พลังวิญญาณ / EXP + ช่องวงแหวน */
public final class SoulHud {
    private static final int[] RING_COLORS = {
            0xFFFFFFFF, 0xFFFFE600, 0xFFAA00FF, 0xFF222222, 0xFFFF2222, 0xFFFFC800
    };

    private SoulHud() {}

    public static void extract(GuiGraphicsExtractor g, DeltaTracker tracker) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null) return;

        int level = Soul.level(p);
        int power = Soul.power(p);
        int maxPower = Soul.maxPower(p);
        String exp = level >= Soul.MAX_LEVEL ? "MAX" : Soul.exp(p) + "/" + (level * 3);
        String rings = Soul.rings(p);

        int x = 6, y = 6, line = 11;
        int w = 112;
        int h = 8 + line * 5 + (rings.isEmpty() ? 0 : 14);

        g.fill(x - 3, y - 3, x - 3 + w, y - 3 + h, 0x90000000);

        g.text(mc.font, "Soul Land", x, y, 0xFFC77DFF, true);
        g.text(mc.font, "วิญญาณยุทธ์: ค้อนฟ้า", x, y + line, 0xFFFFFFFF, true);
        g.text(mc.font, "เลเวล: " + level, x, y + line * 2, 0xFFFFFFFF, true);
        g.text(mc.font, "พลังวิญญาณ: " + power + "/" + maxPower, x, y + line * 3, 0xFFFFFFFF, true);
        g.text(mc.font, "EXP: " + exp, x, y + line * 4, 0xFFFFFFFF, true);

        int ry = y + line * 5 + 1;
        for (int i = 0; i < rings.length(); i++) {
            int c = rings.charAt(i) - '0';
            if (c < 0 || c >= RING_COLORS.length) continue;
            int rx = x + i * 11;
            g.fill(rx - 1, ry - 1, rx + 9, ry + 9, 0xFF000000);
            g.fill(rx, ry, rx + 8, ry + 8, RING_COLORS[c]);
        }
    }
}
