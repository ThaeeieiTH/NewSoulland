package com.soulland;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;

public final class Soul {
    public static final int MAX_LEVEL = 100;
    public static final int MAX_RINGS = 9;

    /** สิบปีสีขาว, ร้อยปีสีเหลือง, พันปีสีม่วง, หมื่นปีสีดำ, แสนปีสีแดง, ล้านปีสีทอง */
    public static final int[] RING_MIN_LEVEL = {10, 10, 30, 50, 70, 90};
    public static final double[] RING_BONUS = {1, 2, 4, 7, 12, 20};
    public static final String[] RING_NAMES = {"สิบปีสีขาว", "ร้อยปีสีเหลือง", "พันปีสีม่วง", "หมื่นปีสีดำ", "แสนปีสีแดง", "ล้านปีสีทอง"};
    public static final int[] RING_RGB = {0xFFFFFF, 0xFFE600, 0xAA00FF, 0x222222, 0xFF2222, 0xFFC800};

    private Soul() {}

    public static int level(Player p) {
        return p.getAttachedOrElse(ModAttachments.LEVEL, 1);
    }

    public static int exp(Player p) {
        return p.getAttachedOrElse(ModAttachments.EXP, 0);
    }

    public static String rings(Player p) {
        return p.getAttachedOrElse(ModAttachments.RINGS, "");
    }

    public static int maxPower(Player p) {
        return 100 + level(p) * 10 + rings(p).length() * 20;
    }

    public static int power(Player p) {
        return p.getAttachedOrElse(ModAttachments.POWER, maxPower(p));
    }

    public static void setPower(Player p, int value) {
        p.setAttached(ModAttachments.POWER, Mth.clamp(value, 0, maxPower(p)));
    }

    public static double ringBonus(Player p) {
        double sum = 0;
        for (char c : rings(p).toCharArray()) {
            int i = c - '0';
            if (i >= 0 && i < RING_BONUS.length) sum += RING_BONUS[i];
        }
        return sum;
    }

    public static void addExp(ServerPlayer p, int amount) {
        int lv = level(p);
        int xp = exp(p) + amount;
        boolean up = false;
        while (lv < MAX_LEVEL && xp >= lv * 3) {
            xp -= lv * 3;
            lv++;
            up = true;
        }
        if (lv >= MAX_LEVEL) xp = 0;
        p.setAttached(ModAttachments.LEVEL, lv);
        p.setAttached(ModAttachments.EXP, xp);
        if (up) {
            setPower(p, maxPower(p));
            p.sendSystemMessage(Component.literal("เลื่อนระดับพลังวิญญาณ! Lv." + lv), false);
        }
    }

    /** คืนค่า null ถ้าดูดซับสำเร็จ ไม่งั้นคืนข้อความเหตุผล */
    public static String tryAbsorb(ServerPlayer p, int color) {
        int lv = level(p);
        String r = rings(p);
        if (r.length() >= MAX_RINGS) return "มีวงแหวนวิญญาณครบ " + MAX_RINGS + " วงแล้ว";
        if (r.length() >= lv / 10) return "ระดับพลังวิญญาณยังไม่พอ (ได้วงแหวนเพิ่มทุก 10 เลเวล)";
        if (lv < RING_MIN_LEVEL[color]) {
            return "วงแหวน" + RING_NAMES[color] + "ต้องการ Lv." + RING_MIN_LEVEL[color];
        }
        p.setAttached(ModAttachments.RINGS, r + color);
        return null;
    }
}
