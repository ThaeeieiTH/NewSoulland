package com.soulland;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

public class SoulLand implements ModInitializer {
    public static final String MOD_ID = "soulland";

    @Override
    public void onInitialize() {
        ModAttachments.init();
        ModItems.init();

        // ฆ่ามอนสเตอร์ = ได้ EXP วิญญาณ
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (source.getEntity() instanceof ServerPlayer sp && !(entity instanceof Player)) {
                Soul.addExp(sp, 1);
            }
        });

        // ฟื้นพลังวิญญาณทุก 1 วินาที
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            RingEffect.tick(server);
            if (server.getTickCount() % 20 != 0) return;
            for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                int cur = Soul.power(p);
                int max = Soul.maxPower(p);
                if (cur < max) {
                    Soul.setPower(p, cur + 1 + Soul.level(p) / 20);
                }
            }
        });
    }
}
