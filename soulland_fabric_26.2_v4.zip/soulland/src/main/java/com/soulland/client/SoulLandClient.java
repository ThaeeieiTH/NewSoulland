package com.soulland.client;

import com.soulland.SoulLand;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.resources.Identifier;

public class SoulLandClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        HudElementRegistry.addLast(
                Identifier.fromNamespaceAndPath(SoulLand.MOD_ID, "soul_hud"),
                SoulHud::extract);
    }
}
