package com.soulland.item;

import com.soulland.Soul;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

/** ผลึกวิญญาณ: คลิกขวาเพื่อรับ EXP วิญญาณ +30 (ไว้ฝึกฝน/ทดสอบ) */
public class SoulCrystalItem extends Item {
    public SoulCrystalItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level.isClientSide() || !(player instanceof ServerPlayer sp)) {
            return InteractionResult.PASS;
        }
        player.getItemInHand(hand).shrink(1);
        Soul.addExp(sp, 30);
        sp.sendSystemMessage(Component.literal("ดูดซับผลึกวิญญาณ +30 EXP"), true);
        return InteractionResult.SUCCESS;
    }
}
