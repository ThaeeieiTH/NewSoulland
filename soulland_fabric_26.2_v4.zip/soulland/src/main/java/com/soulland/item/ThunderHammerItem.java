package com.soulland.item;

import com.soulland.RingEffect;
import com.soulland.Soul;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

import java.util.List;

/** ค้อนฟ้า: คลิกขวา = สายฟ้าฟาดศัตรูรอบตัว (ใช้พลังวิญญาณ) */
public class ThunderHammerItem extends Item {
    public static final int COST = 30;
    private static final double RADIUS = 8.0;
    private static final int MAX_TARGETS = 8;

    public ThunderHammerItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (!(level instanceof ServerLevel server) || !(player instanceof ServerPlayer sp)) {
            return InteractionResult.PASS;
        }

        if (Soul.power(sp) < COST) {
            sp.sendSystemMessage(Component.literal("พลังวิญญาณไม่พอ (ต้องใช้ " + COST + ")"), true);
            return InteractionResult.FAIL;
        }

        RingEffect.start(sp);

        double damage = 8.0 + Soul.level(sp) * 0.4 + Soul.ringBonus(sp);
        DamageSource source = server.damageSources().playerAttack(sp);

        List<LivingEntity> targets = server.getEntitiesOfClass(
                LivingEntity.class,
                sp.getBoundingBox().inflate(RADIUS),
                e -> e != sp && e.isAlive());

        int hit = 0;
        for (LivingEntity target : targets) {
            if (hit >= MAX_TARGETS) break;
            LightningBolt bolt = new LightningBolt(EntityType.LIGHTNING_BOLT, server);
            bolt.setPos(target.getX(), target.getY(), target.getZ());
            bolt.setVisualOnly(true);
            server.addFreshEntity(bolt);
            target.hurtServer(server, source, (float) damage);
            hit++;
        }

        server.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                sp.getX(), sp.getY() + 0.5, sp.getZ(), 40, RADIUS / 3, 0.3, RADIUS / 3, 0.2);

        Soul.setPower(sp, Soul.power(sp) - COST);
        sp.sendSystemMessage(Component.literal("ค้อนฟ้า! โดน " + hit + " เป้าหมาย"), true);
        return InteractionResult.SUCCESS;
    }
}
