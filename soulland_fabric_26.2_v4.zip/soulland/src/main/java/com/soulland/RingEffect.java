package com.soulland;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * เอฟเฟกต์ตอนเปิดวงแหวน: วงเวทซ้อนกันใต้เท้า (วงเล็กในสุด = วงแหวนระดับต่ำ, วงนอกสุด = ระดับสูงสุด)
 * วงนอกสุดมีหนามเฉียง 4 มุมตามภาพ และมีไฟสีม่วงตรงกลาง
 */
public final class RingEffect {
    private static final int DURATION = 40;
    private static final int POINTS = 32;
    private static final Map<UUID, Integer> ACTIVE = new HashMap<>();

    private RingEffect() {}

    public static void start(ServerPlayer p) {
        if (Soul.rings(p).isEmpty()) return;
        ACTIVE.put(p.getUUID(), DURATION);
        emit(p);
    }

    public static void tick(MinecraftServer server) {
        if (ACTIVE.isEmpty()) return;
        Iterator<Map.Entry<UUID, Integer>> it = ACTIVE.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Integer> e = it.next();
            ServerPlayer p = server.getPlayerList().getPlayer(e.getKey());
            int left = e.getValue() - 1;
            if (p == null || left <= 0) {
                it.remove();
                continue;
            }
            e.setValue(left);
            if (left % 5 == 0) emit(p);
        }
    }

    private static void emit(ServerPlayer p) {
        if (!(p.level() instanceof ServerLevel sl)) return;

        List<Integer> tiers = new ArrayList<>();
        for (char c : Soul.rings(p).toCharArray()) {
            int t = c - '0';
            if (t >= 0 && t < Soul.RING_RGB.length) tiers.add(t);
        }
        if (tiers.isEmpty()) return;
        Collections.sort(tiers); // ต่ำ -> สูง : ในสุด -> นอกสุด

        double x = p.getX(), y = p.getY() + 0.05, z = p.getZ();

        double radius = 1.2;
        for (int tier : tiers) {
            DustParticleOptions dust = new DustParticleOptions(Soul.RING_RGB[tier], 1.0f);
            for (int i = 0; i < POINTS; i++) {
                double a = Math.PI * 2 * i / POINTS;
                sl.sendParticles(dust, x + Math.cos(a) * radius, y, z + Math.sin(a) * radius, 1, 0, 0, 0, 0);
            }
            radius += 0.5;
        }

        // หนามเฉียง 4 มุม + ลายดาวตรงทิศหลัก ที่วงนอกสุด
        double outer = radius - 0.5;
        DustParticleOptions top = new DustParticleOptions(Soul.RING_RGB[tiers.get(tiers.size() - 1)], 1.3f);
        for (int n = 0; n < 4; n++) {
            double a = Math.PI / 4 + n * Math.PI / 2;
            for (int s = 1; s <= 6; s++) {
                double rr = outer + 0.18 * s;
                sl.sendParticles(top, x + Math.cos(a) * rr, y, z + Math.sin(a) * rr, 1, 0, 0, 0, 0);
            }
            double b = n * Math.PI / 2;
            for (int s = -1; s <= 1; s++) {
                double rr = outer + 0.2 * s;
                sl.sendParticles(top, x + Math.cos(b) * rr, y, z + Math.sin(b) * rr, 1, 0, 0, 0, 0);
            }
        }

        // ไฟสีม่วงกลางวง
        sl.sendParticles(new DustParticleOptions(0xAA00FF, 1.6f), x, y + 0.4, z, 6, 0.25, 0.5, 0.25, 0);
    }
}
