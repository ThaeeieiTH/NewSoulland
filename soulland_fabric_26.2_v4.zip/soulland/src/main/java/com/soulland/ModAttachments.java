package com.soulland;

import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentSyncPredicate;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.resources.Identifier;

/** ข้อมูลผู้เล่น: เซฟลงโลก ติดตัวหลังตาย และซิงก์ไปไคลเอนต์อัตโนมัติ (ใช้แสดงบน HUD) */
public final class ModAttachments {
    public static final AttachmentType<Integer> LEVEL = intAttachment("soul_level");
    public static final AttachmentType<Integer> EXP = intAttachment("soul_exp");
    public static final AttachmentType<Integer> POWER = intAttachment("soul_power");

    /** วงแหวนที่ดูดซับแล้ว เก็บเป็นตัวเลขต่อกัน 0=ขาว 1=เหลือง 2=ม่วง 3=ดำ 4=แดง เช่น "0012" */
    public static final AttachmentType<String> RINGS = AttachmentRegistry.create(
            Identifier.fromNamespaceAndPath(SoulLand.MOD_ID, "soul_rings"),
            builder -> builder
                    .persistent(Codec.STRING)
                    .copyOnDeath()
                    .syncWith(ByteBufCodecs.STRING_UTF8, AttachmentSyncPredicate.targetOnly())
    );

    private static AttachmentType<Integer> intAttachment(String name) {
        return AttachmentRegistry.create(
                Identifier.fromNamespaceAndPath(SoulLand.MOD_ID, name),
                builder -> builder
                        .persistent(Codec.INT)
                        .copyOnDeath()
                        .syncWith(ByteBufCodecs.VAR_INT, AttachmentSyncPredicate.targetOnly())
        );
    }

    public static void init() {
        // เรียกเพื่อโหลดคลาส
    }
}
