package com.soulland;

import com.soulland.item.SoulCrystalItem;
import com.soulland.item.SoulRingItem;
import com.soulland.item.ThunderHammerItem;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;

import java.util.function.Function;

public final class ModItems {
    public static final Item THUNDER_HAMMER = register("thunder_hammer", ThunderHammerItem::new,
            new Item.Properties().stacksTo(1).useCooldown(2.0f));
    public static final Item SOUL_CRYSTAL = register("soul_crystal", SoulCrystalItem::new, new Item.Properties());

    public static final Item[] RINGS = new Item[6];
    public static final String[] RING_IDS = {"ring_ten", "ring_hundred", "ring_thousand", "ring_tenthousand", "ring_hundredthousand", "ring_million"};

    static {
        for (int i = 0; i < RINGS.length; i++) {
            final int color = i;
            RINGS[i] = register(RING_IDS[i], props -> new SoulRingItem(props, color), new Item.Properties());
        }
    }

    private static <T extends Item> T register(String name, Function<Item.Properties, T> factory, Item.Properties props) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(SoulLand.MOD_ID, name));
        T item = factory.apply(props.setId(key));
        Registry.register(BuiltInRegistries.ITEM, key, item);
        return item;
    }

    public static void init() {
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(tab -> {
            tab.accept(THUNDER_HAMMER);
            tab.accept(SOUL_CRYSTAL);
            for (Item ring : RINGS) tab.accept(ring);
        });
    }
}
