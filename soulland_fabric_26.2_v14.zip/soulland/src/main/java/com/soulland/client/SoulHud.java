package com.soulland.client;

import com.soulland.Skills;
import com.soulland.Soul;
import com.soulland.SoulLand;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

/**
 * HUD แบบ Soul Land: กรอบวงเวทซ้าย (รูปวิญญาณยุทธ์ + ขั้นฝึก) / ป้ายชื่อวิญญาณยุทธ์ + เลเวล /
 * แถบเลือด แถบพลังงาน (พลังวิญญาณ) แถบ EXP
 */
public final class SoulHud {
    private static final Identifier PANEL = tex("hud_panel");
    private static final Identifier PLATE = tex("hud_plate");
    private static final Identifier BAR_RED = tex("hud_bar_red");
    private static final Identifier BAR_BLUE = tex("hud_bar_blue");
    private static final Identifier BAR_GOLD = tex("hud_bar_gold");

    private static final int WHITE = 0xFFFFFFFF;

    private SoulHud() {}

    private static Identifier tex(String name) {
        return Identifier.fromNamespaceAndPath(SoulLand.MOD_ID, "textures/gui/" + name + ".png");
    }

    /** วาดแถบ 1 แถว: กรอบ + ช่องเติม (3 ชั้นไล่เฉด) + ตัวเลข */
    private static void bar(GuiGraphicsExtractor g, Minecraft mc, Identifier frame, int x, int y,
                            double ratio, int light, int main, int dark, String label, int labelColor) {
        g.blit(RenderPipelines.GUI_TEXTURED, frame, x, y, 0, 0, 124, 13, 124, 13);
        int w = (int) Math.round(59 * Math.max(0.0, Math.min(1.0, ratio)));
        if (w > 0) {
            int sx = x + 16, sy = y + 4;
            g.fill(sx, sy, sx + w, sy + 1, light);
            g.fill(sx, sy + 1, sx + w, sy + 4, main);
            g.fill(sx, sy + 4, sx + w, sy + 6, dark);
        }
        g.text(mc.font, label, x + 81, y + 3, labelColor, true);
    }

    public static void extract(GuiGraphicsExtractor g, DeltaTracker tracker) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null) return;

        String soulId = Soul.soul(p);
        boolean awake = !soulId.isEmpty();
        int level = Soul.level(p);
        int power = Soul.power(p);
        int maxPower = Math.max(1, Soul.maxPower(p));
        float hp = p.getHealth();
        float maxHp = Math.max(1f, p.getMaxHealth());

        int px = 4, py = 4;

        // ---- กรอบซ้าย (รูปค้อน + ขั้นฝึก) ----
        g.blit(RenderPipelines.GUI_TEXTURED, PANEL, px, py, 0, 0, 92, 80, 184, 166, 184, 166);
        String rank = awake ? Soul.rankName(level) : "ยังไม่ปลุก";
        int rw = mc.font.width(rank);
        g.text(mc.font, rank, px + 46 - rw / 2, py + 63, 0xFFFFD27A, true);

        // ---- ป้ายชื่อวิญญาณยุทธ์ + เลเวล ----
        int rx = 98;
        g.blit(RenderPipelines.GUI_TEXTURED, PLATE, rx, 8, 0, 0, 112, 17, 112, 17);
        g.text(mc.font, Soul.soulName(soulId), rx + 9, 12, WHITE, true);
        String lv = "Lv." + level;
        g.text(mc.font, lv, rx + 105 - mc.font.width(lv), 12, 0xFFFFE680, true);

        // ---- แถบเลือด ----
        bar(g, mc, BAR_RED, rx, 29, hp / maxHp,
                0xFFFF7A7A, 0xFFE0141E, 0xFF820A12,
                Math.round(hp) + "/" + Math.round(maxHp), WHITE);

        // ---- แถบพลังงาน (พลังวิญญาณ) ----
        bar(g, mc, BAR_BLUE, rx, 43, (double) power / maxPower,
                0xFF86E6FF, 0xFF1EAAFF, 0xFF0A5AAA,
                power + "/" + maxPower, WHITE);

        // ---- แถบ EXP ----
        double expRatio;
        String expLabel;
        int expColor = WHITE;
        if (level >= Soul.MAX_LEVEL) {
            expRatio = 1.0;
            expLabel = "MAX";
        } else if (level >= Soul.levelCap(p)) {
            expRatio = 1.0;
            expLabel = "ตัน/วงแหวน";
            expColor = 0xFFFFA040;
        } else {
            int need = Math.max(1, Soul.expNeeded(level));
            expRatio = (double) Soul.exp(p) / need;
            expLabel = Soul.exp(p) + "/" + need;
        }
        bar(g, mc, BAR_GOLD, rx, 57, expRatio,
                0xFFFFF096, 0xFFFFC81E, 0xFFAA6E00,
                expLabel, expColor);

        // ---- ทักษะที่เลือก ----
        if (awake) {
            int s = Soul.skill(p);
            if (s < 0 || s >= Skills.NAMES.length) s = 0;
            boolean locked = !Skills.unlocked(p, s);
            g.text(mc.font, "ทักษะ " + (s + 1) + ": " + Skills.NAMES[s] + (locked ? " (ล็อก)" : ""),
                    rx, 73, locked ? 0xFFFF7777 : 0xFF8AE6FF, true);
        }
    }
}
