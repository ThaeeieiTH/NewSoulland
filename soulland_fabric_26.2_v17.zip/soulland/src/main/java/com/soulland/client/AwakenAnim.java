package com.soulland.client;

import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/**
 * อนิเมชั่นปลุกวิญญาณยุทธ์ (ฝั่งไคลเอนต์ ~3.6 วินาที):
 * กล้องสลับไปด้านหน้าตัวละคร → ตัวละครลอยขึ้น 2 บล็อก → กล้องหมุนรอบตัว 1 รอบ (ตัวละครหันคงที่) → ลงพื้น คืนกล้อง
 */
public final class AwakenAnim {
    private static final int RISE = 22;
    private static final int HOLD_END = 50;
    private static final int TOTAL = 72;       // น้อยกว่า 80 tick กันระบบเซิร์ฟเวอร์ถือว่าบินนานเกิน
    private static final int ORBIT_START = 6;
    private static final int ORBIT_END = 66;

    private static boolean active = false;
    private static int t = 0;
    private static double sx, sy, sz;
    private static float startYaw, startPitch;
    private static CameraType prevCamera;

    private AwakenAnim() {}

    private static double ease(double x) {
        x = Mth.clamp(x, 0.0, 1.0);
        return x * x * (3 - 2 * x);
    }

    public static void start(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || active) return;
        active = true;
        t = 0;
        sx = p.getX();
        sy = p.getY();
        sz = p.getZ();
        startYaw = p.getYRot();
        startPitch = p.getXRot();
        prevCamera = mc.options.getCameraType();
        mc.options.setCameraType(CameraType.THIRD_PERSON_FRONT);
        p.setNoGravity(true);
    }

    /** ก่อนเริ่มแต่ละ tick: หยุดแรงเคลื่อนที่ของผู้เล่น */
    public static void tickStart(Minecraft mc) {
        if (active && mc.player != null) {
            mc.player.setDeltaMovement(Vec3.ZERO);
        }
    }

    public static void tick(Minecraft mc) {
        if (!active) return;
        LocalPlayer p = mc.player;
        if (p == null || !p.isAlive()) {
            finish(mc);
            return;
        }
        t++;
        double h;
        if (t <= RISE) {
            h = 2.0 * ease(t / (double) RISE);
        } else if (t <= HOLD_END) {
            h = 2.0;
        } else {
            h = 2.0 * (1.0 - ease((t - HOLD_END) / (double) (TOTAL - HOLD_END)));
        }
        p.setPos(sx, sy + h, sz);
        p.setDeltaMovement(Vec3.ZERO);
        p.resetFallDistance();

        float orbit = (float) (360.0 * ease((t - ORBIT_START) / (double) (ORBIT_END - ORBIT_START)));
        p.setYRot(startYaw + orbit);   // กล้องหมุนตามมุมนี้
        p.setXRot(12f);
        p.setYBodyRot(startYaw);        // ตัวละครหันคงที่
        p.setYHeadRot(startYaw);

        if (t >= TOTAL) finish(mc);
    }

    private static void finish(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p != null) {
            p.setNoGravity(false);
            p.setPos(sx, sy, sz);
            p.setYRot(startYaw);
            p.setXRot(startPitch);
            p.setDeltaMovement(Vec3.ZERO);
            p.resetFallDistance();
        }
        if (prevCamera != null) mc.options.setCameraType(prevCamera);
        active = false;
    }
}
