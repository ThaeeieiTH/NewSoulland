package com.soulland.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.soulland.Soul;
import com.soulland.SoulLand;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * วงแหวนใต้เท้า: วาดฝั่งไคลเอนต์เป็นสี่เหลี่ยมมีลายวงเวท (ไม่ใช้เอนทิตี ไม่ใช้พาร์ติเคิล)
 * วางราบที่ระดับเอวรอบตัว ขยับตามตัวผู้เล่นทุกเฟรม ซ้อนกัน (ในสุด = ระดับต่ำ, นอกสุด = ระดับสูงสุด) หมุนสลับทิศ
 * อนิเมชั่นเปิด: ขยายออกทีละวง หมุนเร็วแล้วช้าลง / ปิด: หดกลับ
 */
public final class RingRenderer {
    private static final String[] IDS = {"ten", "hundred", "thousand", "tenthousand", "hundredthousand", "million"};
    private static final Identifier[] FULL = new Identifier[IDS.length];
    private static final Identifier[] BAND = new Identifier[IDS.length];

    static {
        for (int i = 0; i < IDS.length; i++) {
            FULL[i] = Identifier.fromNamespaceAndPath(SoulLand.MOD_ID, "textures/ring/full_" + IDS[i] + ".png");
            BAND[i] = Identifier.fromNamespaceAndPath(SoulLand.MOD_ID, "textures/ring/band_" + IDS[i] + ".png");
        }
    }

    /** ข้อมูลสำหรับวาดหนึ่งวง (ตำแหน่งโลก) */
    public record Draw(Identifier texture, double x, double y, double z, double half, float angle, int color) {}

    private static final double WAIST = 0.53;     // สัดส่วนความสูงตัวผู้เล่น
    private static final int OPEN_TICKS = 14;

    private static int anim = 0;                  // ความคืบหน้าอนิเมชั่นเปิด/ปิด (tick) จำกัดไม่เกินตอนเปิดเต็ม
    private static int age = 0;                   // เวลาที่เปิดอยู่ (ใช้คุมการหมุนเร็วตอนเปิด)
    private static double spin = 0;               // ตัวนับการหมุน (สะสมเร็วช่วงเปิด)
    private static String shown = "";             // วงแหวนที่กำลังแสดง

    private RingRenderer() {}

    public static void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        boolean want = p != null && p.isAlive() && Soul.ringsOpen(p) && !Soul.rings(p).isEmpty();
        if (want) {
            String r = Soul.rings(p);
            if (!r.equals(shown)) {
                shown = r;
                anim = 0;
                age = 0; // วงแหวนเปลี่ยน (ดูดซับใหม่) = เล่นอนิเมชั่นเปิดใหม่
            }
            // จำกัด anim ไว้แค่ตอนเปิดเต็ม เพื่อให้ตอนปิดเริ่มหดทันที (ไม่ค้าง)
            int full = OPEN_TICKS + 3 * Math.max(0, shown.length() - 1) + 1;
            anim = Math.min(anim + 1, full);
            age++;
            double boost = 1.0 + 5.0 * Math.max(0.0, 1.0 - age / 30.0);
            spin += boost;
        } else if (anim > 0) {
            anim = Math.max(0, anim - 2);
            spin += 1.0;
            if (anim == 0) {
                shown = "";
                age = 0;
            }
        }
    }

    private static double ease(double t) {
        t = Mth.clamp(t, 0.0, 1.0);
        return t * t * (3 - 2 * t);
    }

    /** รวบรวมวงที่ต้องวาดในเฟรมนี้ */
    public static List<Draw> collect(Minecraft mc, float partial) {
        List<Draw> out = new ArrayList<>();
        LocalPlayer p = mc.player;
        if (p == null || anim <= 0 || shown.isEmpty()) return out;

        List<Integer> tiers = new ArrayList<>();
        for (char c : shown.toCharArray()) {
            int t = c - '0';
            if (t >= 0 && t < IDS.length) tiers.add(t);
        }
        if (tiers.isEmpty()) return out;
        Collections.sort(tiers); // ต่ำ -> สูง : ในสุด -> นอกสุด

        double px = Mth.lerp((double) partial, p.xo, p.getX());
        double py = Mth.lerp((double) partial, p.yo, p.getY());
        double pz = Mth.lerp((double) partial, p.zo, p.getZ());
        double waist = py + p.getBbHeight() * WAIST;

        double animT = anim + partial;
        for (int k = 0; k < tiers.size(); k++) {
            double t = ease((animT - 3.0 * k) / OPEN_TICKS);
            if (t <= 0.01) continue;
            int tier = tiers.get(k);
            boolean outer = k == tiers.size() - 1;
            double radius = (1.0 + 0.4 * k) * t;
            double half = radius * 2.5 / 2.0;
            double sp = (spin + partial) * (1.5 + 0.35 * k);
            float angle = (float) Math.toRadians((k % 2 == 0 ? sp : -sp) % 360.0);
            int alpha = (int) (255 * Math.min(1.0, t * 1.4));
            int color = (alpha << 24) | 0xFFFFFF;
            out.add(new Draw(outer ? FULL[tier] : BAND[tier], px, waist + k * 0.004, pz, half, angle, color));
        }
        return out;
    }

    /** เขียนสี่เหลี่ยมราบ 2 ด้าน (บน/ล่าง) ลงบัฟเฟอร์ — พิกัดสัมพันธ์กับกล้อง */
    public static void writeQuad(PoseStack.Pose pose, VertexConsumer buf, Draw d, double camX, double camY, double camZ) {
        float cx = (float) (d.x() - camX);
        float cy = (float) (d.y() - camY);
        float cz = (float) (d.z() - camZ);
        float h = (float) d.half();
        float cos = (float) Math.cos(d.angle());
        float sin = (float) Math.sin(d.angle());
        float[][] c = {{-h, -h}, {-h, h}, {h, h}, {h, -h}};
        float[][] uv = {{0f, 0f}, {0f, 1f}, {1f, 1f}, {1f, 0f}};
        // ด้านบน
        for (int i = 0; i < 4; i++) {
            float lx = c[i][0], lz = c[i][1];
            vertex(buf, pose, cx + lx * cos - lz * sin, cy, cz + lx * sin + lz * cos, uv[i][0], uv[i][1], d.color(), 1f);
        }
        // ด้านล่าง (ลำดับกลับ)
        for (int i = 3; i >= 0; i--) {
            float lx = c[i][0], lz = c[i][1];
            vertex(buf, pose, cx + lx * cos - lz * sin, cy - 0.001f, cz + lx * sin + lz * cos, uv[i][0], uv[i][1], d.color(), -1f);
        }
    }

    private static void vertex(VertexConsumer buf, PoseStack.Pose pose, float x, float y, float z,
                               float u, float v, int color, float ny) {
        buf.addVertex(pose, x, y, z)
                .setColor(color)
                .setUv(u, v)
                .setOverlay(655360)      // OverlayTexture.NO_OVERLAY
                .setLight(15728880)      // เต็มสว่าง
                .setNormal(pose, 0f, ny, 0f);
    }
}
