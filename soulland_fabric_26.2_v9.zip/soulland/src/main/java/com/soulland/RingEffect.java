package com.soulland;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * วงแหวนใต้เท้า (เปิด/ปิดด้วยปุ่ม H) เป็นโมเดลจริง ไม่ใช่พาร์ติเคิล:
 * ใช้เอนทิตี item_display ของเกม แสดงรูปวงเวท (ทำจากภาพอ้างอิง ย้อมสีตามระดับวงแหวน) วางราบกับพื้น
 * วงซ้อนกัน: ในสุด = ระดับต่ำ, นอกสุด = ระดับสูงสุด (วงนอกสุดลายเต็มมีหอก 4 มุม) หมุนช้าๆ สลับทิศ ตามตัวผู้เล่น
 */
public final class RingEffect {
    private static final String[] IDS = {"ten", "hundred", "thousand", "tenthousand", "hundredthousand", "million"};
    private static final String TAG = "soulland_ring";

    private static final class State {
        String rings;
        ServerLevel level;
        final List<UUID> ids = new ArrayList<>();
    }

    private static final Map<UUID, State> STATES = new HashMap<>();

    private RingEffect() {}

    public static void tick(MinecraftServer server) {
        long now = server.getTickCount();
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            State st = STATES.get(p.getUUID());
            boolean want = p.isAlive() && Soul.ringsOpen(p) && !Soul.rings(p).isEmpty();
            if (!want) {
                if (st != null) {
                    discard(st);
                    STATES.remove(p.getUUID());
                }
                continue;
            }
            if (!(p.level() instanceof ServerLevel sl)) continue;
            String rings = Soul.rings(p);
            if (st == null || st.level != sl || !st.rings.equals(rings) || missing(st)) {
                if (st != null) discard(st);
                st = build(server, sl, p, rings);
                if (st == null) {
                    STATES.remove(p.getUUID());
                    p.setAttached(ModAttachments.RINGS_OPEN, 0);
                    Soul.msg(p, "สร้างวงแหวนไม่สำเร็จ", true);
                    continue;
                }
                STATES.put(p.getUUID(), st);
            }
            follow(st, p, now);
        }

        // ผู้เล่นที่ออกจากเกมแล้ว: เก็บวงแหวนออก
        Iterator<Map.Entry<UUID, State>> it = STATES.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, State> e = it.next();
            if (server.getPlayerList().getPlayer(e.getKey()) == null) {
                discard(e.getValue());
                it.remove();
            }
        }
    }

    public static void removeAll() {
        for (State st : STATES.values()) discard(st);
        STATES.clear();
    }

    /** ลบวงแหวนที่ค้างจากรอบก่อน (เช่น เกมปิดผิดปกติ) */
    public static void cleanupOrphans(MinecraftServer server) {
        CommandSourceStack src = server.createCommandSourceStack().withSuppressedOutput();
        server.getCommands().performPrefixedCommand(src, "kill @e[tag=" + TAG + "]");
    }

    private static boolean missing(State st) {
        for (UUID id : st.ids) {
            if (st.level.getEntity(id) == null) return true;
        }
        return false;
    }

    private static void discard(State st) {
        for (UUID id : st.ids) {
            Entity e = st.level.getEntity(id);
            if (e != null) e.discard();
        }
        st.ids.clear();
    }

    private static State build(MinecraftServer server, ServerLevel sl, ServerPlayer p, String rings) {
        List<Integer> tiers = new ArrayList<>();
        for (char c : rings.toCharArray()) {
            int t = c - '0';
            if (t >= 0 && t < IDS.length) tiers.add(t);
        }
        if (tiers.isEmpty()) return null;
        Collections.sort(tiers); // ต่ำ -> สูง : ในสุด -> นอกสุด

        State st = new State();
        st.rings = rings;
        st.level = sl;

        CommandSourceStack src = server.createCommandSourceStack().withLevel(sl).withSuppressedOutput();
        for (int k = 0; k < tiers.size(); k++) {
            boolean outer = k == tiers.size() - 1;
            String model = (outer ? "ring_full_" : "ring_band_") + IDS[tiers.get(k)];
            double radius = 1.3 + 0.6 * k;
            double size = radius * 2.5;
            UUID u = UUID.randomUUID();
            int a = (int) (u.getMostSignificantBits() >> 32);
            int b = (int) u.getMostSignificantBits();
            int c = (int) (u.getLeastSignificantBits() >> 32);
            int d = (int) u.getLeastSignificantBits();
            String cmd = String.format(Locale.ROOT,
                    "summon minecraft:item_display %.3f %.3f %.3f {UUID:[I;%d,%d,%d,%d],Tags:[\"%s\"],"
                            + "item:{id:\"minecraft:stick\",count:1,components:{\"minecraft:item_model\":\"soulland:%s\"}},"
                            + "item_display:\"fixed\",billboard:\"fixed\",brightness:{sky:15,block:15},"
                            + "teleport_duration:2,view_range:2.0f,"
                            + "transformation:{left_rotation:[-0.70710677f,0f,0f,0.70710677f],right_rotation:[0f,0f,0f,1f],"
                            + "translation:[0f,0f,0f],scale:[%.3ff,%.3ff,%.3ff]}}",
                    p.getX(), p.getY() + 0.03 + k * 0.004, p.getZ(), a, b, c, d, TAG, model, size, size, size);
            server.getCommands().performPrefixedCommand(src, cmd);
            if (sl.getEntity(u) == null) {
                discard(st);
                return null;
            }
            st.ids.add(u);
        }
        return st;
    }

    private static void follow(State st, ServerPlayer p, long now) {
        for (int k = 0; k < st.ids.size(); k++) {
            Entity e = st.level.getEntity(st.ids.get(k));
            if (e == null) continue;
            e.setPos(p.getX(), p.getY() + 0.03 + k * 0.004, p.getZ());
            float yaw = (float) ((now * (1.5 + 0.35 * k)) % 360.0);
            e.setYRot(k % 2 == 0 ? yaw : -yaw);
        }
    }
}
