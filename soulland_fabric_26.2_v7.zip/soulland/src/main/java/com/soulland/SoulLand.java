package com.soulland;

import com.soulland.net.ActionPayload;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

public class SoulLand implements ModInitializer {
    public static final String MOD_ID = "soulland";

    @Override
    public void onInitialize() {
        ModAttachments.init();
        ModItems.init();

        // ปุ่มจากไคลเอนต์
        PayloadTypeRegistry.serverboundPlay().register(ActionPayload.TYPE, ActionPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(ActionPayload.TYPE, (payload, context) -> {
            ServerPlayer p = context.player();
            Actions.handle(p, payload.action());
        });

        // เกราะเฮ่าเทียน = อมตะช่วงสั้นๆ
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity instanceof ServerPlayer p && p.level() instanceof ServerLevel sl) {
                if (Skills.isInvulnerable(p, sl.getServer().getTickCount())) return false;
            }
            return true;
        });

        // ฆ่ามอนสเตอร์ = ได้ EXP (ต้องปลุกวิญญาณยุทธ์แล้ว) / ตาย = เก็บวิญญาณและวงแหวนเข้าตัว
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof ServerPlayer dead) {
                dead.setAttached(ModAttachments.SOUL_OPEN, 0);
                dead.setAttached(ModAttachments.RINGS_OPEN, 0);
                Skills.clear(dead);
                return;
            }
            if (source.getEntity() instanceof ServerPlayer sp && !Soul.soul(sp).isEmpty()) {
                Soul.addExp(sp, Soul.killExp(entity));
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            Scheduler.tick();
            RingEffect.tick(server);
            if (server.getTickCount() % 20 != 0) return;
            for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                int cur = Soul.power(p);
                int max = Soul.maxPower(p);
                if (cur < max) {
                    Soul.setPower(p, cur + 1 + Soul.level(p) / 20);
                }
            }
        });

        ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            Scheduler.clear();
            Skills.clearAll();
            Actions.clearAll();
        });
    }
}
