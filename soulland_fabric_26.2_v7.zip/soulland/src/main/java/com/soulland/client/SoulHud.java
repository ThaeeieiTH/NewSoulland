package com.soulland.client;

import com.soulland.Skills;
import com.soulland.Soul;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;

/** HUD มุมซ้ายบน: Soul Land / วิญญาณยุทธ์ / เลเวล / พลังวิญญาณ / EXP / ทักษะ */
public final class SoulHud {
    private SoulHud() {}

    public static void extract(GuiGraphicsExtractor g, DeltaTracker tracker) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null) return;

        String soulId = Soul.soul(p);
        boolean awake = !soulId.isEmpty();
        int level = Soul.level(p);
        int power = Soul.power(p);
        int maxPower = Soul.maxPower(p);
        String exp = level >= Soul.MAX_LEVEL ? "MAX" : Soul.exp(p) + "/" + Soul.expNeeded(level);

        int x = 6, y = 6, line = 11;
        int lines = awake ? 6 : 5;
        int w = 124;
        int h = 6 + line * lines;

        g.fill(x - 3, y - 3, x - 3 + w, y - 3 + h, 0x90000000);

        g.text(mc.font, "Soul Land", x, y, 0xFFC77DFF, true);
        g.text(mc.font, "วิญญาณยุทธ์: " + Soul.soulName(soulId), x, y + line, 0xFFFFFFFF, true);
        g.text(mc.font, "เลเวล: " + level, x, y + line * 2, 0xFFFFFFFF, true);
        g.text(mc.font, "พลังวิญญาณ: " + power + "/" + maxPower, x, y + line * 3, 0xFFFFFFFF, true);
        g.text(mc.font, "EXP: " + exp, x, y + line * 4, 0xFFFFFFFF, true);

        if (awake) {
            int s = Soul.skill(p);
            if (s < 0 || s >= Skills.NAMES.length) s = 0;
            boolean locked = !Skills.unlocked(p, s);
            g.text(mc.font, "ทักษะ " + (s + 1) + ": " + Skills.NAMES[s] + (locked ? " (ล็อก)" : ""),
                    x, y + line * 5, locked ? 0xFFFF7777 : 0xFF8AE6FF, true);
        }
    }
}
