package com.soulland.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.soulland.Actions;
import com.soulland.SoulLand;
import com.soulland.net.ActionPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public class SoulLandClient implements ClientModInitializer {
    private static final KeyMapping.Category CATEGORY =
            KeyMapping.Category.register(Identifier.fromNamespaceAndPath(SoulLand.MOD_ID, "main"));

    private static KeyMapping key(String name, int code) {
        return KeyMappingHelper.registerKeyMapping(
                new KeyMapping("key.soulland." + name, InputConstants.Type.KEYSYM, code, CATEGORY));
    }

    @Override
    public void onInitializeClient() {
        HudElementRegistry.addLast(
                Identifier.fromNamespaceAndPath(SoulLand.MOD_ID, "soul_hud"),
                SoulHud::extract);

        KeyMapping awaken = key("awaken", GLFW.GLFW_KEY_M);
        KeyMapping reroll = key("reroll", GLFW.GLFW_KEY_N);
        KeyMapping toggleSoul = key("toggle_soul", GLFW.GLFW_KEY_G);
        KeyMapping toggleRings = key("toggle_rings", GLFW.GLFW_KEY_H);
        KeyMapping nextSkill = key("next_skill", GLFW.GLFW_KEY_V);
        KeyMapping useSkill = key("use_skill", GLFW.GLFW_KEY_R);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;
            poll(awaken, Actions.AWAKEN);
            poll(reroll, Actions.REROLL);
            poll(toggleSoul, Actions.TOGGLE_SOUL);
            poll(toggleRings, Actions.TOGGLE_RINGS);
            poll(nextSkill, Actions.NEXT_SKILL);
            poll(useSkill, Actions.USE_SKILL);
        });
    }

    private static void poll(KeyMapping key, int action) {
        while (key.consumeClick()) {
            ClientPlayNetworking.send(new ActionPayload(action));
        }
    }
}
