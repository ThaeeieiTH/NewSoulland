package com.soulland.item;

import com.soulland.Soul;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

/** ผลึกวิญญาณ: คลิกขวาเพื่อรับ EXP วิญญาณ +100 (ต้องปลุกวิญญาณยุทธ์ก่อน) */
public class SoulCrystalItem extends Item {
    public SoulCrystalItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level.isClientSide() || !(player instanceof ServerPlayer sp)) {
            return InteractionResult.PASS;
        }
        if (Soul.soul(sp).isEmpty()) {
            Soul.msg(sp, "ต้องปลุกวิญญาณยุทธ์ก่อน (กด M)", true);
            return InteractionResult.FAIL;
        }
        player.getItemInHand(hand).shrink(1);
        Soul.addExp(sp, 100);
        Soul.msg(sp, "ดูดซับผลึกวิญญาณ +100 EXP", true);
        return InteractionResult.SUCCESS;
    }
}
