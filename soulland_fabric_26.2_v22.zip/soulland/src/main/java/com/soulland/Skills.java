package com.soulland;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/** 9 ทักษะของค้อนเฮ่าเทียน — ต้องมีวงแหวน: ทักษะที่ k ใช้ได้เมื่อมีวงแหวนครบ k วง */
public final class Skills {
    public static final String[] HAMMER_NAMES = {
            "สายฟ้าฟาดฟ้า", "ค้อนสะท้านพื้น", "พุ่งสายฟ้า", "เกราะเฮ่าเทียน", "คลื่นฟ้าตรง",
            "พายุสายฟ้า", "ฟ้าผ่าเป้าหมาย", "วงคลื่นสายฟ้า", "เฮ่าเทียนทลายฟ้า"
    };
    public static final int[] HAMMER_COST = {20, 30, 25, 40, 35, 60, 45, 70, 120};

    public static final String[] SCYTHE_NAMES = {
            "คมเคียวแสงศักดิ์สิทธิ์", "จิตเคียวเทวะ", "วงล้อพิพากษา", "สายฟ้าพิพากษาสวรรค์", "ปีกเทวะทำลายล้าง",
            "สุริยันคลื่นสวรรค์", "กายแท้เคียวศักดิ์สิทธิ์", "มหาคำพิพากษาเทวะ", "เคียวเทพทำลายล้างนิรันดร์"
    };
    public static final int[] SCYTHE_COST = {20, 30, 35, 55, 45, 65, 50, 80, 130};

    public static final String[] KNIGHT_NAMES = {
            "ฟันกางเขน", "โล่ศักดิ์สิทธิ์", "พุ่งชนด้วยโล่", "ปีกคุ้มครอง", "ดาบแสงสวรรค์",
            "วงอาญาสิทธิ์", "ปราการศักดิ์สิทธิ์", "ทัพเทวทูต", "จุติเทพ"
    };
    public static final int[] KNIGHT_COST = {20, 40, 30, 45, 40, 60, 70, 75, 120};

    public static String[] names(String soul) {
        return switch (soul) {
            case Soul.SCYTHE -> SCYTHE_NAMES;
            case Soul.KNIGHT -> KNIGHT_NAMES;
            default -> HAMMER_NAMES;
        };
    }

    public static int[] costs(String soul) {
        return switch (soul) {
            case Soul.SCYTHE -> SCYTHE_COST;
            case Soul.KNIGHT -> KNIGHT_COST;
            default -> HAMMER_COST;
        };
    }
    public static final int[] COOLDOWN_TICKS = {60, 60, 60, 60, 60, 60, 60, 60, 60}; // ทุกสกิลคูลดาวน์ 3 วินาที

    private static final DustParticleOptions BLUE = new DustParticleOptions(0x2EE6FF, 1.2f);
    private static final DustParticleOptions GOLD = new DustParticleOptions(0xFFC800, 1.3f);
    private static final DustParticleOptions PURPLE = new DustParticleOptions(0xAA00FF, 1.4f);

    private static final Map<UUID, long[]> COOLDOWNS = new HashMap<>();
    private static final Map<UUID, Long> INVULN_UNTIL = new HashMap<>();
    private static final Random RNG = new Random();

    private Skills() {}

    /** ทักษะลำดับ i (เริ่มที่ 0) ต้องมีวงแหวนอย่างน้อย i+1 วง (ไม่มีวงแหวน = ใช้สกิลไม่ได้) */
    public static boolean unlocked(Player p, int i) {
        return Soul.rings(p).length() >= i + 1;
    }

    public static boolean isInvulnerable(ServerPlayer p, long nowTick) {
        Long until = INVULN_UNTIL.get(p.getUUID());
        return until != null && nowTick < until;
    }

    public static void clear(ServerPlayer p) {
        Buffs.clear(p);
        COOLDOWNS.remove(p.getUUID());
        INVULN_UNTIL.remove(p.getUUID());
    }

    public static void clearAll() {
        Buffs.clearAll();
        COOLDOWNS.clear();
        INVULN_UNTIL.clear();
    }

    public static void use(ServerPlayer p) {
        if (!(p.level() instanceof ServerLevel sl)) return;
        MinecraftServer server = sl.getServer();
        String soul = Soul.soul(p);
        String[] names = names(soul);
        int[] cost = costs(soul);
        int i = Soul.skill(p);
        if (i < 0 || i >= names.length) i = 0;

        if (!unlocked(p, i)) {
            Soul.msg(p, "ใช้ทักษะ " + (i + 1) + " ไม่ได้ ต้องมีวงแหวนครบ " + (i + 1) + " วง (ตอนนี้มี " + Soul.rings(p).length() + ")", true);
            return;
        }
        long now = server.getTickCount();
        long[] cd = COOLDOWNS.computeIfAbsent(p.getUUID(), k -> new long[names.length]);
        if (now < cd[i]) {
            Soul.msg(p, "ทักษะยังคูลดาวน์ อีก " + ((cd[i] - now + 19) / 20) + " วินาที", true);
            return;
        }
        if (Soul.power(p) < cost[i]) {
            Soul.msg(p, "พลังวิญญาณไม่พอ (ต้องใช้ " + cost[i] + ")", true);
            return;
        }

        boolean ok = switch (soul) {
            case Soul.SCYTHE -> scythe(i, sl, p);
            case Soul.KNIGHT -> knight(i, sl, p, now);
            default -> hammer(i, sl, p, now);
        };
        if (!ok) return;

        Soul.setPower(p, Soul.power(p) - cost[i]);
        cd[i] = now + COOLDOWN_TICKS[i];
        Soul.msg(p, "ทักษะ " + (i + 1) + ": " + names[i], true);
    }

    private static boolean hammer(int i, ServerLevel sl, ServerPlayer p, long now) {
        return switch (i) {
            case 0 -> s1(sl, p);
            case 1 -> s2(sl, p);
            case 2 -> s3(sl, p);
            case 3 -> s4(sl, p, now);
            case 4 -> s5(sl, p);
            case 5 -> s6(sl, p);
            case 6 -> s7(sl, p);
            case 7 -> s8(sl, p);
            case 8 -> s9(sl, p);
            default -> false;
        };
    }

    private static boolean scythe(int i, ServerLevel sl, ServerPlayer p) {
        return switch (i) {
            case 0 -> c1(sl, p);
            case 1 -> c2(sl, p);
            case 2 -> c3(sl, p);
            case 3 -> c4(sl, p);
            case 4 -> c5(sl, p);
            case 5 -> c6(sl, p);
            case 6 -> c7(sl, p);
            case 7 -> c8(sl, p);
            case 8 -> c9(sl, p);
            default -> false;
        };
    }

    private static boolean knight(int i, ServerLevel sl, ServerPlayer p, long now) {
        return switch (i) {
            case 0 -> k1(sl, p);
            case 1 -> k2(sl, p, now);
            case 2 -> k3(sl, p);
            case 3 -> k4(sl, p);
            case 4 -> k5(sl, p);
            case 5 -> k6(sl, p);
            case 6 -> k7(sl, p);
            case 7 -> k8(sl, p);
            case 8 -> k9(sl, p);
            default -> false;
        };
    }

    // ---------- helpers ----------

    private static float dmg(ServerPlayer p, double mult) {
        return (float) ((8 + Soul.level(p) * 0.4 + Soul.ringBonus(p)) * mult * Buffs.attackMult(p));
    }

    private static java.util.List<LivingEntity> around(ServerLevel sl, ServerPlayer p, double r) {
        return sl.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(r), e -> e != p && e.isAlive());
    }

    private static void hit(ServerLevel sl, ServerPlayer p, LivingEntity t, float d) {
        SoulLand.SKILL_HIT = true;
        try {
            t.hurtServer(sl, sl.damageSources().playerAttack(p), d);
        } finally {
            SoulLand.SKILL_HIT = false;
        }
    }

    /** ผลักเป้าหมายให้ห่างจากผู้เล่น (แทน knockback ที่เปลี่ยนรูปแบบใน 26.2) */
    private static void shove(LivingEntity t, ServerPlayer p, double strength) {
        double dx = t.getX() - p.getX();
        double dz = t.getZ() - p.getZ();
        double len = Math.max(0.001, Math.hypot(dx, dz));
        t.push(dx / len * strength, 0.35, dz / len * strength);
    }

    // ---------- 9 ทักษะ (เอฟเฟกต์พาร์ติเคิลที่ประกอบเอง) ----------

    /** 1 สายฟ้าฟาดฟ้า: วงเวทใต้เท้า แล้วฟ้าผ่าศัตรูรอบตัว (8 ตัว) */
    private static boolean s1(ServerLevel sl, ServerPlayer p) {
        float d = dmg(p, 1.0);
        Fx.rune(sl, p.getX(), p.getY() + 0.05, p.getZ(), 2.6, Fx.BLUE, Fx.CYAN);
        Fx.helix(sl, Fx.CYAN, p.getX(), p.getY(), p.getZ(), 0.9, 2.4, 2, 0);
        Fx.groundBolts(sl, p.getX(), p.getY(), p.getZ(), 7, 6);
        Fx.sphere(sl, ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 1, p.getZ(), 0.35, 60);
        Fx.risingRings(sl, Fx.CYAN, p.getX(), p.getY(), p.getZ(), 1.6, 4);
        int n = 0;
        for (LivingEntity t : around(sl, p, 8)) {
            if (n++ >= 8) break;
            Fx.bolt(sl, t.getX(), t.getY(), t.getZ(), 16);
            hit(sl, p, t, d);
        }
        if (n == 0) {
            for (int i = 0; i < 3; i++) {
                double a = RNG.nextDouble() * Math.PI * 2;
                Fx.bolt(sl, p.getX() + Math.cos(a) * 4, p.getY(), p.getZ() + Math.sin(a) * 4, 14);
            }
        }
        return true;
    }

    /** 2 ค้อนสะท้านพื้น: ฟาดพื้นเป็นคลื่นกระแทก 3 ระลอก ผลักศัตรูออก */
    private static boolean s2(ServerLevel sl, ServerPlayer p) {
        float d = dmg(p, 1.3);
        final double cx = p.getX(), cy = p.getY(), cz = p.getZ();
        for (LivingEntity t : around(sl, p, 6)) {
            hit(sl, p, t, d);
            shove(t, p, 0.9);
        }
        Fx.rune(sl, cx, cy + 0.05, cz, 2.2, Fx.GOLD, Fx.CYAN);
        Fx.groundBolts(sl, cx, cy, cz, 8, 8);
        Fx.crown(sl, Fx.CYAN, cx, cy, cz, 2.2, 14, 2.5);
        for (int k = 0; k < 3; k++) {
            final double r = 1.2 + k * 1.6;
            Scheduler.after(1 + k * 4, () -> {
                Fx.shock(sl, cx, cy, cz, r);
                Fx.ring(sl, Fx.BLUE, cx, cy + 0.1, cz, r);
            });
        }
        Fx.spark(sl, cx, cy + 0.3, cz, 26, 3.5);
        Fx.sound(sl, cx, cy, cz, 1.0f, 0.7f);
        return true;
    }

    /** 3 พุ่งสายฟ้า: พุ่งไปข้างหน้า 8 บล็อก ทิ้งรอยสายฟ้า ศัตรูที่ขวางโดนดาเมจ */
    private static boolean s3(ServerLevel sl, ServerPlayer p) {
        Vec3 dir = Vec3.directionFromRotation(0, p.getYRot());
        AABB box = p.getBoundingBox();
        int dist = 0;
        for (int i = 1; i <= 8; i++) {
            if (!sl.noCollision(box.move(dir.x * i, 0, dir.z * i))) break;
            dist = i;
        }
        if (dist == 0) {
            Soul.msg(p, "ข้างหน้าถูกขวาง พุ่งไม่ได้", true);
            return false;
        }
        Vec3 from = p.position();
        float d = dmg(p, 1.2);
        AABB path = box.expandTowards(dir.x * dist, 0, dir.z * dist).inflate(1.5);
        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, path, e -> e != p && e.isAlive())) {
            hit(sl, p, t, d);
            Fx.impact(sl, t.getX(), t.getY(), t.getZ());
        }
        Fx.shock(sl, from.x, from.y, from.z, 1.0);
        Fx.ring(sl, Fx.CYAN, from.x, from.y + 0.1, from.z, 1.2);
        Fx.beam(sl, from.x, from.y + 1.0, from.z, dir.x, 0, dir.z, dist);
        Fx.sphere(sl, ParticleTypes.ELECTRIC_SPARK, from.x, from.y + 1, from.z, 0.3, 40);
        double ex = from.x + dir.x * dist, ez = from.z + dir.z * dist;
        p.connection.teleport(ex, from.y, ez, p.getYRot(), p.getXRot());
        Fx.rune(sl, ex, from.y + 0.05, ez, 1.8, Fx.BLUE, Fx.CYAN);
        Fx.sphere(sl, ParticleTypes.END_ROD, ex, from.y + 1, ez, 0.3, 40);
        Fx.groundBolts(sl, ex, from.y, ez, 4, 4);
        Fx.sound(sl, ex, from.y, ez, 0.8f, 1.4f);
        return true;
    }

    /** 4 เกราะเฮ่าเทียน: อมตะ 2 วินาที + เกราะดูดซับ + ออร่าเกลียวทองห่อตัว */
    private static boolean s4(ServerLevel sl, ServerPlayer p, long now) {
        INVULN_UNTIL.put(p.getUUID(), now + 40);
        p.setAbsorptionAmount(Math.max(p.getAbsorptionAmount(), 6.0f));
        Fx.rune(sl, p.getX(), p.getY() + 0.05, p.getZ(), 2.0, Fx.GOLD, Fx.CYAN);
        Fx.vortex(sl, Fx.GOLD, p.getX(), p.getY(), p.getZ(), 2.2, 0.6, 3, 3, 0);
        Fx.risingRings(sl, Fx.GOLD, p.getX(), p.getY(), p.getZ(), 1.4, 5);
        for (int k = 0; k < 12; k++) {
            final int step = k;
            Scheduler.after(1 + step * 5, () -> {
                if (!p.isAlive()) return;
                Fx.helix(sl, Fx.GOLD, p.getX(), p.getY(), p.getZ(), 1.0, 2.2, 1.5, step * 0.7);
                Fx.ring(sl, Fx.CYAN, p.getX(), p.getY() + 0.3 + (step % 4) * 0.55, p.getZ(), 0.9);
                Fx.shell(sl, Fx.CYAN, p.getX(), p.getY() + 0.9, p.getZ(), 1.5, 36);
            });
        }
        Fx.sound(sl, p.getX(), p.getY(), p.getZ(), 0.7f, 1.6f);
        return true;
    }

    /** 5 คลื่นฟ้าตรง: ลำแสงสายฟ้าพุ่งเป็นเส้นตรง 14 บล็อก */
    private static boolean s5(ServerLevel sl, ServerPlayer p) {
        Vec3 dir = p.getLookAngle();
        Vec3 start = p.position();
        double len = 14;
        float d = dmg(p, 1.2);
        AABB box = p.getBoundingBox().expandTowards(dir.x * len, dir.y * len, dir.z * len).inflate(2.5);
        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, box, e -> e != p && e.isAlive())) {
            Vec3 rel = t.position().subtract(start);
            double along = rel.dot(dir);
            if (along < 0 || along > len) continue;
            if (rel.subtract(dir.x * along, dir.y * along, dir.z * along).length() > 2.5) continue;
            hit(sl, p, t, d);
            Fx.impact(sl, t.getX(), t.getY(), t.getZ());
        }
        Fx.beam(sl, start.x, start.y + 1.2, start.z, dir.x, dir.y, dir.z, len);
        Fx.rune(sl, start.x, start.y + 0.05, start.z, 1.6, Fx.BLUE, Fx.CYAN);
        double ex = start.x + dir.x * len, ey = start.y + 1.2 + dir.y * len, ez = start.z + dir.z * len;
        Fx.spark(sl, ex, ey, ez, 16, 1.5);
        Fx.sphere(sl, ParticleTypes.END_ROD, ex, ey, ez, 0.3, 50);
        Fx.shock(sl, ex, start.y, ez, 1.5);
        Fx.sphere(sl, ParticleTypes.ELECTRIC_SPARK, start.x, start.y + 1, start.z, 0.3, 40);
        Fx.sound(sl, start.x, start.y, start.z, 0.9f, 1.2f);
        return true;
    }

    /** 6 พายุสายฟ้า: ฟ้าผ่าสุ่มรอบตัว 6 ครั้งใน 3 วินาที พร้อมวงเวทใหญ่ */
    private static boolean s6(ServerLevel sl, ServerPlayer p) {
        float d = dmg(p, 1.0);
        Fx.rune(sl, p.getX(), p.getY() + 0.05, p.getZ(), 4.5, Fx.BLUE, Fx.PURPLE);
        for (int i = 0; i < 6; i++) {
            Scheduler.after(i * 10 + 1, () -> {
                if (!p.isAlive()) return;
                double a = RNG.nextDouble() * Math.PI * 2;
                double r = 3 + RNG.nextDouble() * 6;
                double x = p.getX() + Math.cos(a) * r;
                double z = p.getZ() + Math.sin(a) * r;
                double y = p.getY();
                Fx.bolt(sl, x, y, z, 18);
                Fx.ring(sl, Fx.BLUE, x, y + 0.1, z, 2.0);
                Fx.groundBolts(sl, x, y, z, 4, 5);
                Fx.sphere(sl, ParticleTypes.ELECTRIC_SPARK, x, y + 1, z, 0.3, 30);
                AABB area = new AABB(x - 3, y - 2, z - 3, x + 3, y + 3, z + 3);
                for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, area, e -> e != p && e.isAlive())) {
                    hit(sl, p, t, d);
                }
            });
        }
        return true;
    }

    /** 7 ฟ้าผ่าเป้าหมาย: เสาฟ้าผ่าใส่ตัวที่เล็งอยู่ ดาเมจ x3 */
    private static boolean s7(ServerLevel sl, ServerPlayer p) {
        Vec3 dir = p.getLookAngle();
        Vec3 eye = p.getEyePosition();
        double len = 32;
        AABB box = p.getBoundingBox().expandTowards(dir.x * len, dir.y * len, dir.z * len).inflate(2.0);
        LivingEntity best = null;
        double bestAlong = Double.MAX_VALUE;
        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, box, e -> e != p && e.isAlive())) {
            Vec3 rel = t.getEyePosition().subtract(eye);
            double along = rel.dot(dir);
            if (along < 0 || along > len) continue;
            if (rel.subtract(dir.x * along, dir.y * along, dir.z * along).length() > 1.8) continue;
            if (along < bestAlong) {
                bestAlong = along;
                best = t;
            }
        }
        if (best == null) {
            Soul.msg(p, "ไม่มีเป้าหมายในแนวสายตา", true);
            return false;
        }
        final double x = best.getX(), y = best.getY(), z = best.getZ();
        Fx.rune(sl, x, y + 0.05, z, 2.4, Fx.PURPLE, Fx.CYAN);
        Fx.bolt(sl, x, y, z, 26);
        Fx.bolt(sl, x, y, z, 26);
        Fx.bolt(sl, x, y, z, 26);
        Fx.pillar(sl, x, y, z, 10);
        Fx.sphere(sl, ParticleTypes.ELECTRIC_SPARK, x, y + 1, z, 0.45, 80);
        Fx.groundBolts(sl, x, y, z, 6, 6);
        Fx.risingRings(sl, Fx.PURPLE, x, y, z, 2.0, 5);
        Fx.shock(sl, x, y, z, 1.5);
        Scheduler.after(4, () -> Fx.shock(sl, x, y, z, 3.0));
        hit(sl, p, best, dmg(p, 3.0));
        return true;
    }

    /** 8 วงคลื่นสายฟ้า: วงคลื่นขยายออกจากตัวรัศมี 12 บล็อก มีสายฟ้าผ่าตามขอบคลื่น */
    private static boolean s8(ServerLevel sl, ServerPlayer p) {
        final double cx = p.getX(), cy = p.getY() + 0.1, cz = p.getZ();
        final Set<UUID> done = new HashSet<>();
        final float d = dmg(p, 1.5);
        Fx.rune(sl, cx, cy, cz, 3.2, Fx.GOLD, Fx.CYAN);
        Fx.sphere(sl, ParticleTypes.ELECTRIC_SPARK, cx, cy + 1, cz, 0.4, 60);
        Fx.risingRings(sl, Fx.GOLD, cx, cy, cz, 2.2, 5);
        for (int t = 1; t <= 10; t++) {
            final int step = t;
            Scheduler.after(step * 2, () -> {
                double r = 1.5 + step * 1.15;
                Fx.ring(sl, Fx.GOLD, cx, cy, cz, r);
                Fx.shock(sl, cx, cy, cz, r);
                if (step % 3 == 0) {
                    double a = RNG.nextDouble() * Math.PI * 2;
                    Fx.bolt(sl, cx + Math.cos(a) * r, cy, cz + Math.sin(a) * r, 10);
                }
                AABB area = new AABB(cx - r - 1.5, cy - 2, cz - r - 1.5, cx + r + 1.5, cy + 4, cz + r + 1.5);
                for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, area, x -> x != p && x.isAlive())) {
                    double dist = Math.hypot(e.getX() - cx, e.getZ() - cz);
                    if (Math.abs(dist - r) <= 1.4 && done.add(e.getUUID())) {
                        hit(sl, p, e, d);
                    }
                }
            });
        }
        Fx.sound(sl, cx, cy, cz, 1.0f, 0.9f);
        return true;
    }

    /** 9 เฮ่าเทียนทลายฟ้า: รวมพลัง 1 วินาที วงเวทหดเข้า แล้วฟ้าผ่า 12 ครั้ง เสาแสง คลื่นกระแทกซ้อน ดาเมจ x4 */
    private static boolean s9(ServerLevel sl, ServerPlayer p) {
        final float d = dmg(p, 4.0);
        final double cx = p.getX(), cy = p.getY(), cz = p.getZ();
        for (int k = 0; k < 4; k++) {
            final int step = k;
            Scheduler.after(step * 5 + 1, () -> {
                if (!p.isAlive()) return;
                double r = 7 - step * 1.4;
                Fx.rune(sl, p.getX(), p.getY() + 0.05, p.getZ(), r, Fx.PURPLE, Fx.CYAN);
                Fx.vortex(sl, Fx.PURPLE, p.getX(), p.getY(), p.getZ(), r * 0.7, 0.5, 4.5, 3, step);
                Fx.sound(sl, p.getX(), p.getY(), p.getZ(), 0.4f, 0.6f + step * 0.2f);
            });
        }
        Scheduler.after(20, () -> {
            if (!p.isAlive()) return;
            Fx.pillar(sl, cx, cy, cz, 14);
            Fx.groundBolts(sl, cx, cy, cz, 12, 14);
            Fx.sphere(sl, ParticleTypes.END_ROD, cx, cy + 1, cz, 0.6, 140);
            Fx.crown(sl, Fx.GOLD, cx, cy, cz, 10, 24, 6);
            Fx.risingRings(sl, Fx.GOLD, cx, cy, cz, 5, 6);
            for (int i = 0; i < 12; i++) {
                double a = RNG.nextDouble() * Math.PI * 2;
                double r = 2 + RNG.nextDouble() * 10;
                Fx.bolt(sl, cx + Math.cos(a) * r, cy, cz + Math.sin(a) * r, 20);
            }
            for (LivingEntity t : around(sl, p, 12)) {
                hit(sl, p, t, d);
                shove(t, p, 1.2);
            }
            Fx.rune(sl, cx, cy + 0.05, cz, 10, Fx.GOLD, Fx.CYAN);
            for (int k = 1; k <= 4; k++) {
                final double r = k * 2.5;
                Scheduler.after(k * 2, () -> {
                    Fx.shock(sl, cx, cy, cz, r);
                    Fx.ring(sl, Fx.GOLD, cx, cy + 0.1, cz, r);
                });
            }
            Fx.spark(sl, cx, cy + 1, cz, 40, 6.0);
            Fx.sound(sl, cx, cy, cz, 1.5f, 0.6f);
        });
        return true;
    }
    // =====================================================================
    //  ตัวช่วยสำหรับเคียวศักดิ์สิทธิ์ / อัศวินศักดิ์สิทธิ์
    // =====================================================================

    private static Vec3 face(ServerPlayer p) {
        return Vec3.directionFromRotation(0, p.getYRot());
    }

    private static int clearDistance(ServerLevel sl, ServerPlayer p, Vec3 dir, int max) {
        AABB box = p.getBoundingBox();
        int dist = 0;
        for (int i = 1; i <= max; i++) {
            if (!sl.noCollision(box.move(dir.x * i, 0, dir.z * i))) break;
            dist = i;
        }
        return dist;
    }

    private static LivingEntity aimed(ServerLevel sl, ServerPlayer p, double len, double tol) {
        Vec3 dir = p.getLookAngle();
        Vec3 eye = p.getEyePosition();
        AABB box = p.getBoundingBox().expandTowards(dir.x * len, dir.y * len, dir.z * len).inflate(2.0);
        LivingEntity best = null;
        double bestAlong = Double.MAX_VALUE;
        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, box, e -> e != p && e.isAlive())) {
            Vec3 rel = t.getEyePosition().subtract(eye);
            double along = rel.dot(dir);
            if (along < 0 || along > len) continue;
            if (rel.subtract(dir.x * along, dir.y * along, dir.z * along).length() > tol) continue;
            if (along < bestAlong) {
                bestAlong = along;
                best = t;
            }
        }
        return best;
    }

    /** เป้าหมายในกรวยด้านหน้า */
    private static java.util.List<LivingEntity> cone(ServerLevel sl, ServerPlayer p, double range, double halfDeg) {
        Vec3 f = face(p);
        double cos = Math.cos(Math.toRadians(halfDeg));
        java.util.List<LivingEntity> out = new java.util.ArrayList<>();
        for (LivingEntity t : around(sl, p, range)) {
            double dx = t.getX() - p.getX(), dz = t.getZ() - p.getZ();
            double len = Math.hypot(dx, dz);
            if (len > range) continue;
            if (len < 0.8 || (dx * f.x + dz * f.z) / len >= cos) out.add(t);
        }
        return out;
    }

    /** เป้าหมายในแถบตามแนวหน้า (ยาว len กว้างครึ่งหนึ่ง half) */
    private static java.util.List<LivingEntity> strip(ServerLevel sl, ServerPlayer p, double len, double half) {
        Vec3 f = face(p);
        java.util.List<LivingEntity> out = new java.util.ArrayList<>();
        for (LivingEntity t : around(sl, p, len + 2)) {
            double dx = t.getX() - p.getX(), dz = t.getZ() - p.getZ();
            double along = dx * f.x + dz * f.z;
            double lat = Math.abs(-dx * f.z + dz * f.x);
            if (along >= 0 && along <= len && lat <= half) out.add(t);
        }
        return out;
    }

    /** เป้าหมายในวงกลมรัศมี r รอบจุด (cx,cz) */
    private static java.util.List<LivingEntity> within(ServerLevel sl, ServerPlayer p, double cx, double cy, double cz, double r) {
        AABB area = new AABB(cx - r, cy - 3, cz - r, cx + r, cy + 4, cz + r);
        java.util.List<LivingEntity> out = new java.util.ArrayList<>();
        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, area, e -> e != p && e.isAlive())) {
            if (Math.hypot(t.getX() - cx, t.getZ() - cz) <= r) out.add(t);
        }
        return out;
    }

    private static void heal(ServerPlayer p, double amount) {
        p.heal((float) amount);
    }

    // =====================================================================
    //  เคียวศักดิ์สิทธิ์ 9 ทักษะ (เอฟเฟกต์ทั้งหมดเป็นของมอดเอง)
    // =====================================================================

    /** 1 คมเคียวแสงศักดิ์สิทธิ์: ปล่อยคลื่นคมเคียวสีทอง 3 ลูกพุ่งไปข้างหน้า โจมตีศัตรูแนวตรง 16 บล็อก */
    private static boolean c1(ServerLevel sl, ServerPlayer p) {
        final Vec3 f = face(p);
        final double ox = p.getX(), oy = p.getY() + 1.0, oz = p.getZ();
        float d = dmg(p, 1.4);
        for (LivingEntity t : strip(sl, p, 16, 3.5)) {
            hit(sl, p, t, d);
            Fx.impact(sl, t.getX(), t.getY(), t.getZ());
        }
        for (int k = 0; k < 3; k++) {
            final int step = k;
            Scheduler.after(1 + k * 3, () -> Fx.wave(sl, Fx.GOLD, ox, oy, oz, f.x, f.z, 4.5 + step * 1.5, 1.3, 14));
        }
        Fx.rune(sl, ox, p.getY() + 0.05, oz, 1.8, Fx.GOLD, Fx.CYAN);
        Fx.sound(sl, ox, oy, oz, 0.7f, 1.5f);
        return true;
    }

    /** 2 จิตเคียวเทวะ: เพิ่มพลังโจมตี x1.5 และระยะโจมตีของเคียว +2.5 บล็อก นาน 10 วินาที */
    private static boolean c2(ServerLevel sl, ServerPlayer p) {
        Buffs.apply(p, "mind", 200, 1.5, 0.0, 2.5);
        double x = p.getX(), y = p.getY(), z = p.getZ();
        Fx.rune(sl, x, y + 0.05, z, 2.6, Fx.GOLD, Fx.CYAN);
        Fx.shell(sl, Fx.GOLD, x, y + 0.9, z, 1.8, 0);
        Fx.pillar(sl, x, y, z, 4);
        Fx.risingRings(sl, Fx.GOLD, x, y, z, 1.5, 5);
        Fx.scythe(sl, x, y + 2.8, z, 1.8, -40, 40, 30);
        Fx.spark(sl, x, y + 1.0, z, 16, 1.6);
        Soul.msg(p, "พลังโจมตี x1.5 และระยะเคียว +2.5 เป็นเวลา 10 วินาที", false);
        Fx.sound(sl, x, y, z, 0.7f, 1.6f);
        return true;
    }

    /** 3 วงล้อพิพากษา: หมุนเคียวปล่อยวงแหวนพลังขยายออก 3 ระลอก โจมตีศัตรูรอบตัวรัศมี 6 */
    private static boolean c3(ServerLevel sl, ServerPlayer p) {
        float d = dmg(p, 1.3);
        final double cx = p.getX(), cy = p.getY(), cz = p.getZ();
        for (LivingEntity t : around(sl, p, 6)) {
            hit(sl, p, t, d);
            shove(t, p, 0.8);
        }
        Fx.scythe(sl, cx, cy + 1.6, cz, 3.2, -90, 270, 14);
        for (int k = 0; k < 3; k++) {
            final int step = k;
            Scheduler.after(1 + k * 4, () -> {
                Fx.shock(sl, cx, cy + 0.6 + step * 0.4, cz, 6.0);
                for (int i = 0; i < 6; i++) {
                    double a = i * Math.PI / 3 + step * 0.5;
                    Fx.wave(sl, Fx.GOLD, cx, cy + 1.0, cz, Math.cos(a), Math.sin(a), 3.2, 0.7, 10);
                }
            });
        }
        Fx.rune(sl, cx, cy + 0.05, cz, 5.0, Fx.GOLD, Fx.CYAN);
        Fx.sound(sl, cx, cy, cz, 0.8f, 1.1f);
        return true;
    }

    /** 4 สายฟ้าพิพากษาสวรรค์: เรียกสายฟ้าศักดิ์สิทธิ์โจมตีพื้นที่เป้าหมาย (เป้าที่เล็ง หรือด้านหน้า 8 บล็อก) */
    private static boolean c4(ServerLevel sl, ServerPlayer p) {
        LivingEntity t = aimed(sl, p, 20, 2.0);
        Vec3 f = face(p);
        final double cx = t != null ? t.getX() : p.getX() + f.x * 8;
        final double cy = t != null ? t.getY() : p.getY();
        final double cz = t != null ? t.getZ() : p.getZ() + f.z * 8;
        final float d = dmg(p, 1.0);
        Fx.rune(sl, cx, cy + 0.05, cz, 5.0, Fx.GOLD, Fx.CYAN);
        for (int i = 0; i < 6; i++) {
            Scheduler.after(2 + i * 4, () -> {
                double a = RNG.nextDouble() * Math.PI * 2;
                double r = RNG.nextDouble() * 4.0;
                double x = cx + Math.cos(a) * r, z = cz + Math.sin(a) * r;
                Fx.bolt(sl, x, cy, z, 22);
                for (LivingEntity e : within(sl, p, x, cy, z, 3.0)) hit(sl, p, e, d);
            });
        }
        Scheduler.after(30, () -> {
            Fx.bolt(sl, cx, cy, cz, 26);
            Fx.pillar(sl, cx, cy, cz, 12);
            Fx.shock(sl, cx, cy, cz, 4.5);
            for (LivingEntity e : within(sl, p, cx, cy, cz, 4.5)) hit(sl, p, e, d * 2.0f);
        });
        return true;
    }

    /** 5 ปีกเทวะทำลายล้าง: สร้างปีกพลังงาน เพิ่มความเร็วเดิน +40% และพลังโจมตี x1.3 นาน 12 วินาที */
    private static boolean c5(ServerLevel sl, ServerPlayer p) {
        Buffs.apply(p, "wings", 240, 1.3, 0.4, 0.0);
        double x = p.getX(), y = p.getY(), z = p.getZ();
        Fx.wingsBound(sl, p.getId(), x, y, z, 1.7, 240);
        Fx.rune(sl, x, y + 0.05, z, 2.4, Fx.GOLD, Fx.CYAN);
        Fx.spark(sl, x, y + 1.4, z, 30, 2.6);
        Fx.risingRings(sl, Fx.GOLD, x, y, z, 1.6, 5);
        Soul.msg(p, "ปีกเทวะ: ความเร็ว +40% พลังโจมตี x1.3 เป็นเวลา 12 วินาที", false);
        Fx.sound(sl, x, y, z, 0.8f, 1.7f);
        return true;
    }

    /** 6 สุริยันคลื่นสวรรค์: รวมพลังแสงเป็นดวงอาทิตย์เหนือหัว แล้วระเบิดเป็นวงกว้างรัศมี 12 */
    private static boolean c6(ServerLevel sl, ServerPlayer p) {
        final double x = p.getX(), y = p.getY(), z = p.getZ();
        final float d = dmg(p, 2.5);
        Fx.rune(sl, x, y + 0.05, z, 3.2, Fx.GOLD, Fx.CYAN);
        Fx.sun(sl, x, y + 3.8, z, 0.4, 3.2, 26);
        Fx.risingRings(sl, Fx.GOLD, x, y, z, 1.8, 6);
        Scheduler.after(26, () -> {
            if (!p.isAlive()) return;
            Fx.sun(sl, x, y + 3.8, z, 3.2, 16.0, 16);
            for (int k = 1; k <= 4; k++) {
                final double r = k * 3.0;
                Scheduler.after(k * 2, () -> Fx.shock(sl, x, y, z, r));
            }
            Fx.pillar(sl, x, y, z, 12);
            Fx.spark(sl, x, y + 2.0, z, 40, 8.0);
            for (LivingEntity t : around(sl, p, 12)) {
                hit(sl, p, t, d);
                shove(t, p, 1.2);
            }
            Fx.sound(sl, x, y, z, 1.4f, 0.6f);
        });
        return true;
    }

    /** 7 กายแท้เคียวศักดิ์สิทธิ์: เพิ่มพลังโจมตีและความเร็วเป็น 2 เท่า นาน 12 วินาที */
    private static boolean c7(ServerLevel sl, ServerPlayer p) {
        Buffs.apply(p, "body", 240, 2.0, 1.0, 0.0);
        double x = p.getX(), y = p.getY(), z = p.getZ();
        Fx.rune(sl, x, y + 0.05, z, 3.4, Fx.GOLD, Fx.CYAN);
        Fx.pillar(sl, x, y, z, 8);
        Fx.shell(sl, Fx.GOLD, x, y + 0.9, z, 2.2, 0);
        Fx.sun(sl, x, y + 1.2, z, 0.5, 2.0, 22);
        Fx.risingRings(sl, Fx.GOLD, x, y, z, 1.7, 6);
        Fx.spark(sl, x, y + 1.0, z, 30, 2.2);
        Soul.msg(p, "กายแท้เคียวศักดิ์สิทธิ์: พลังโจมตีและความเร็ว x2 เป็นเวลา 12 วินาที", false);
        Fx.sound(sl, x, y, z, 1.0f, 0.9f);
        return true;
    }

    /** 8 มหาคำพิพากษาเทวะ: วงเวทใหญ่รัศมี 12 เรียกพลังศักดิ์สิทธิ์โจมตีศัตรูทั้งหมดในอาณาเขตเป็นจังหวะ */
    private static boolean c8(ServerLevel sl, ServerPlayer p) {
        final double cx = p.getX(), cy = p.getY(), cz = p.getZ();
        final float d = dmg(p, 0.9);
        Fx.rune(sl, cx, cy + 0.05, cz, 12, Fx.GOLD, Fx.CYAN);
        for (int k = 1; k <= 6; k++) {
            final int step = k;
            Scheduler.after(k * 12, () -> {
                if (step % 2 == 0) Fx.rune(sl, cx, cy + 0.05, cz, 12, Fx.GOLD, Fx.CYAN);
                Fx.shock(sl, cx, cy, cz, 12);
                for (LivingEntity t : within(sl, p, cx, cy, cz, 12)) {
                    Fx.bolt(sl, t.getX(), t.getY(), t.getZ(), 20);
                    hit(sl, p, t, step == 6 ? d * 2.0f : d);
                }
                double a = RNG.nextDouble() * Math.PI * 2;
                Fx.pillar(sl, cx + Math.cos(a) * 8, cy, cz + Math.sin(a) * 8, 10);
            });
        }
        Fx.sound(sl, cx, cy, cz, 1.2f, 0.7f);
        return true;
    }

    /** 9 เคียวเทพทำลายล้างนิรันดร์: ปลดปล่อยร่างเทพแห่งเคียว ฟันปล่อยมหาคลื่นพลังแสง ดาเมจ x4 */
    private static boolean c9(ServerLevel sl, ServerPlayer p) {
        final Vec3 f = face(p);
        final double ox = p.getX(), oy = p.getY(), oz = p.getZ();
        final float d = dmg(p, 4.0);
        Fx.rune(sl, ox, oy + 0.05, oz, 10, Fx.GOLD, Fx.CYAN);
        Fx.scythe(sl, ox - f.x * 3.0, oy + 4.6, oz - f.z * 3.0, 9.0, -75, 80, 16);
        Fx.sun(sl, ox, oy + 1.4, oz, 0.5, 2.6, 16);
        Scheduler.after(8, () -> {
            if (!p.isAlive()) return;
            double[] offs = {-40, -20, 0, 20, 40};
            for (double o : offs) {
                double a = Math.atan2(f.z, f.x) + Math.toRadians(o);
                Fx.wave(sl, Fx.GOLD, ox, oy + 1.0, oz, Math.cos(a), Math.sin(a), 12, 1.6, 16);
            }
            for (LivingEntity t : strip(sl, p, 22, 9)) hit(sl, p, t, d);
            for (LivingEntity t : around(sl, p, 5)) {
                hit(sl, p, t, d * 0.5f);
                shove(t, p, 1.0);
            }
            Fx.pillar(sl, ox, oy, oz, 14);
            Fx.shock(sl, ox, oy, oz, 8);
            Fx.spark(sl, ox, oy + 1.5, oz, 40, 6.0);
            Fx.sound(sl, ox, oy, oz, 1.5f, 0.6f);
        });
        return true;
    }

    // =====================================================================
    //  อัศวินศักดิ์สิทธิ์ 9 ทักษะ
    // =====================================================================

    /** 1 ฟันกางเขน: ลำแสงตรงไปข้างหน้า 8 บล็อก ตัดกับแนวขวางที่ระยะ 4 เป็นกางเขน */
    private static boolean k1(ServerLevel sl, ServerPlayer p) {
        Vec3 f = face(p);
        double lxv = -f.z, lzv = f.x;
        float d = dmg(p, 1.2);
        for (LivingEntity t : around(sl, p, 9)) {
            double dx = t.getX() - p.getX(), dz = t.getZ() - p.getZ();
            double along = dx * f.x + dz * f.z;
            double lat = dx * lxv + dz * lzv;
            boolean a = along >= 0 && along <= 8 && Math.abs(lat) <= 1.4;
            boolean b = Math.abs(along - 4) <= 1.4 && Math.abs(lat) <= 3.5;
            if (a || b) {
                hit(sl, p, t, d);
                Fx.impact(sl, t.getX(), t.getY(), t.getZ());
            }
        }
        double ox = p.getX(), oy = p.getY() + 1.1, oz = p.getZ();
        Fx.beam(sl, ox, oy, oz, f.x, 0, f.z, 8);
        double mx = ox + f.x * 4, mz = oz + f.z * 4;
        Fx.line(sl, ParticleTypes.END_ROD, mx - lxv * 3.5, oy, mz - lzv * 3.5, mx + lxv * 3.5, oy, mz + lzv * 3.5, 0.3);
        Fx.line(sl, Fx.GOLD, mx - lxv * 3.5, oy, mz - lzv * 3.5, mx + lxv * 3.5, oy, mz + lzv * 3.5, 0.45);
        Fx.sphere(sl, ParticleTypes.END_ROD, mx, oy, mz, 0.3, 40);
        Fx.rune(sl, ox, p.getY() + 0.05, oz, 1.8, Fx.GOLD, Fx.CYAN);
        Fx.sound(sl, ox, oy, oz, 0.8f, 1.3f);
        return true;
    }

    /** 2 โล่ศักดิ์สิทธิ์: อมตะ 2 วินาที + เกราะดูดซับ ภายใต้โดมแสงทอง */
    private static boolean k2(ServerLevel sl, ServerPlayer p, long now) {
        INVULN_UNTIL.put(p.getUUID(), now + 40);
        p.setAbsorptionAmount(Math.max(p.getAbsorptionAmount(), 8.0f));
        Fx.rune(sl, p.getX(), p.getY() + 0.05, p.getZ(), 2.4, Fx.GOLD, Fx.CYAN);
        Fx.star(sl, Fx.GOLD, p.getX(), p.getY() + 0.1, p.getZ(), 2.2, 6, 0);
        for (int k = 0; k < 8; k++) {
            final int step = k;
            Scheduler.after(1 + step * 5, () -> {
                if (!p.isAlive()) return;
                Fx.shell(sl, Fx.GOLD, p.getX(), p.getY() + 0.9, p.getZ(), 1.7, 48);
                Fx.shell(sl, Fx.CYAN, p.getX(), p.getY() + 0.9, p.getZ(), 1.5, 30);
            });
        }
        Fx.sound(sl, p.getX(), p.getY(), p.getZ(), 0.7f, 1.6f);
        return true;
    }

    /** 3 พุ่งชนด้วยโล่: พุ่งไปข้างหน้า 6 บล็อก ชนศัตรูกระเด็น */
    private static boolean k3(ServerLevel sl, ServerPlayer p) {
        Vec3 dir = face(p);
        int dist = clearDistance(sl, p, dir, 6);
        if (dist == 0) {
            Soul.msg(p, "ข้างหน้าถูกขวาง พุ่งไม่ได้", true);
            return false;
        }
        Vec3 from = p.position();
        float d = dmg(p, 1.4);
        AABB path = p.getBoundingBox().expandTowards(dir.x * dist, 0, dir.z * dist).inflate(1.5);
        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, path, e -> e != p && e.isAlive())) {
            hit(sl, p, t, d);
            shove(t, p, 1.2);
            Fx.impact(sl, t.getX(), t.getY(), t.getZ());
        }
        Fx.crescent(sl, Fx.GOLD, from.x, from.y + 1.0, from.z, dir.x, dir.z, 1.8, 120, 0.9);
        Fx.beam(sl, from.x, from.y + 1.0, from.z, dir.x, 0, dir.z, dist);
        double ex = from.x + dir.x * dist, ez = from.z + dir.z * dist;
        p.connection.teleport(ex, from.y, ez, p.getYRot(), p.getXRot());
        Fx.shell(sl, Fx.GOLD, ex + dir.x * 0.6, from.y + 1.0, ez + dir.z * 0.6, 1.6, 40);
        Fx.sphere(sl, ParticleTypes.ELECTRIC_SPARK, ex, from.y + 1.0, ez, 0.35, 50);
        Fx.shock(sl, ex, from.y, ez, 1.5);
        Fx.sound(sl, ex, from.y, ez, 0.9f, 0.9f);
        return true;
    }

    /** 4 ปีกคุ้มครอง: กางปีก ฟื้นเลือด 8 และเกราะดูดซับ */
    private static boolean k4(ServerLevel sl, ServerPlayer p) {
        final Vec3 f = face(p);
        heal(p, 8);
        p.setAbsorptionAmount(Math.max(p.getAbsorptionAmount(), 4.0f));
        Fx.wings(sl, p.getX(), p.getY(), p.getZ(), f.x, f.z, 1.6);
        Scheduler.after(6, () -> {
            if (p.isAlive()) Fx.wings(sl, p.getX(), p.getY(), p.getZ(), f.x, f.z, 2.1);
        });
        Fx.risingRings(sl, Fx.GOLD, p.getX(), p.getY(), p.getZ(), 1.5, 5);
        Fx.helix(sl, Fx.CYAN, p.getX(), p.getY(), p.getZ(), 1.0, 2.4, 2, 0);
        Fx.sphere(sl, ParticleTypes.END_ROD, p.getX(), p.getY() + 1.0, p.getZ(), 0.3, 50);
        Fx.sound(sl, p.getX(), p.getY(), p.getZ(), 0.7f, 1.7f);
        return true;
    }

    /** 5 ดาบแสงสวรรค์: คลื่นดาบแสงพุ่งตรง 16 บล็อก ทะลุทุกเป้าหมาย */
    private static boolean k5(ServerLevel sl, ServerPlayer p) {
        Vec3 dir = p.getLookAngle();
        Vec3 start = p.position();
        double len = 16;
        float d = dmg(p, 1.5);
        AABB box = p.getBoundingBox().expandTowards(dir.x * len, dir.y * len, dir.z * len).inflate(2.5);
        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, box, e -> e != p && e.isAlive())) {
            Vec3 rel = t.position().subtract(start);
            double along = rel.dot(dir);
            if (along < 0 || along > len) continue;
            if (rel.subtract(dir.x * along, dir.y * along, dir.z * along).length() > 1.8) continue;
            hit(sl, p, t, d);
            Fx.impact(sl, t.getX(), t.getY(), t.getZ());
        }
        Fx.beam(sl, start.x, start.y + 1.2, start.z, dir.x, dir.y, dir.z, len);
        Fx.rune(sl, start.x, start.y + 0.05, start.z, 1.8, Fx.GOLD, Fx.CYAN);
        Fx.lightSword(sl, start.x + dir.x * len, start.y, start.z + dir.z * len, 6);
        Fx.sphere(sl, ParticleTypes.END_ROD, start.x + dir.x * len, start.y + 1.2 + dir.y * len, start.z + dir.z * len, 0.3, 50);
        Fx.sound(sl, start.x, start.y, start.z, 0.9f, 1.4f);
        return true;
    }

    /** 6 วงอาญาสิทธิ์: วงเวทใหญ่ ตามด้วยเสาแสงพิพากษาหลัง 1 วินาที (ใส่เป้าหมายที่เล็ง หรือด้านหน้า 8 บล็อก) */
    private static boolean k6(ServerLevel sl, ServerPlayer p) {
        LivingEntity t = aimed(sl, p, 20, 2.0);
        Vec3 f = face(p);
        final double cx = t != null ? t.getX() : p.getX() + f.x * 8;
        final double cy = t != null ? t.getY() : p.getY();
        final double cz = t != null ? t.getZ() : p.getZ() + f.z * 8;
        final float d = dmg(p, 2.5);
        Fx.rune(sl, cx, cy + 0.05, cz, 5.0, Fx.GOLD, Fx.CYAN);
        Fx.star(sl, Fx.GOLD, cx, cy + 0.1, cz, 4.5, 8, 0);
        for (int k = 0; k < 4; k++) {
            final int step = k;
            Scheduler.after(1 + k * 5, () -> {
                Fx.risingRings(sl, Fx.GOLD, cx, cy, cz, 4.0 - step * 0.6, 3);
                Fx.shock(sl, cx, cy, cz, 5.0 - step);
            });
        }
        Scheduler.after(20, () -> {
            Fx.pillar(sl, cx, cy, cz, 14);
            Fx.groundBolts(sl, cx, cy, cz, 5, 8);
            Fx.sphere(sl, ParticleTypes.END_ROD, cx, cy + 1, cz, 0.5, 90);
            for (LivingEntity e : within(sl, p, cx, cy, cz, 5)) hit(sl, p, e, d);
            Fx.shock(sl, cx, cy, cz, 5.0);
            Fx.sound(sl, cx, cy, cz, 1.3f, 0.7f);
        });
        return true;
    }

    /** 7 ปราการศักดิ์สิทธิ์: เสาแสง 8 ต้นล้อมตัว ผลักศัตรูออกรัศมี 6 */
    private static boolean k7(ServerLevel sl, ServerPlayer p) {
        float d = dmg(p, 1.0);
        final double cx = p.getX(), cy = p.getY(), cz = p.getZ();
        for (LivingEntity t : around(sl, p, 6)) {
            hit(sl, p, t, d);
            shove(t, p, 1.2);
        }
        Fx.rune(sl, cx, cy + 0.05, cz, 4.5, Fx.GOLD, Fx.CYAN);
        for (int i = 0; i < 8; i++) {
            double a = Math.PI * 2 * i / 8;
            Fx.pillar(sl, cx + Math.cos(a) * 4, cy, cz + Math.sin(a) * 4, 6);
        }
        Fx.shock(sl, cx, cy, cz, 4.0);
        Scheduler.after(4, () -> Fx.shock(sl, cx, cy, cz, 6.0));
        Fx.sound(sl, cx, cy, cz, 1.0f, 0.9f);
        return true;
    }

    /** 8 ทัพเทวทูต: ดาบแสงตกลงมา 3 ระลอก ระลอกละ 7 เล่ม ในกรวยด้านหน้า */
    private static boolean k8(ServerLevel sl, ServerPlayer p) {
        final Vec3 f = face(p);
        final double lxv = -f.z, lzv = f.x;
        final float d = dmg(p, 0.9);
        Fx.wings(sl, p.getX(), p.getY(), p.getZ(), f.x, f.z, 1.8);
        Fx.rune(sl, p.getX(), p.getY() + 0.05, p.getZ(), 2.2, Fx.GOLD, Fx.CYAN);
        for (int w = 0; w < 3; w++) {
            Scheduler.after(1 + w * 8, () -> {
                if (!p.isAlive()) return;
                for (int i = 0; i < 7; i++) {
                    double s = 4 + RNG.nextDouble() * 8;
                    double lat = (RNG.nextDouble() - 0.5) * 10;
                    double x = p.getX() + f.x * s + lxv * lat;
                    double z = p.getZ() + f.z * s + lzv * lat;
                    double y = p.getY();
                    Fx.lightSword(sl, x, y, z, 7);
                    for (LivingEntity t : within(sl, p, x, y, z, 2.5)) hit(sl, p, t, d);
                }
                Fx.sound(sl, p.getX(), p.getY(), p.getZ(), 0.8f, 1.0f);
            });
        }
        return true;
    }

    /** 9 จุติเทพ: กางปีกยักษ์ รวมพลัง 1 วินาที แล้วเสาแสงลงมาทำลายรัศมี 11 ดาเมจ x4 ฟื้นเลือด 20 */
    private static boolean k9(ServerLevel sl, ServerPlayer p) {
        final Vec3 f = face(p);
        final float d = dmg(p, 4.0);
        final double cx = p.getX(), cy = p.getY(), cz = p.getZ();
        Fx.wings(sl, cx, cy, cz, f.x, f.z, 2.6);
        for (int k = 0; k < 4; k++) {
            final int step = k;
            Scheduler.after(step * 5 + 1, () -> {
                if (!p.isAlive()) return;
                Fx.vortex(sl, Fx.GOLD, p.getX(), p.getY(), p.getZ(), 6 - step * 1.2, 0.6, 5, 3, step);
                Fx.rune(sl, p.getX(), p.getY() + 0.05, p.getZ(), 7 - step * 1.4, Fx.GOLD, Fx.CYAN);
                Fx.sound(sl, p.getX(), p.getY(), p.getZ(), 0.4f, 0.6f + step * 0.2f);
            });
        }
        Scheduler.after(20, () -> {
            if (!p.isAlive()) return;
            Fx.wings(sl, cx, cy, cz, f.x, f.z, 2.8);
            Fx.pillar(sl, cx, cy, cz, 16);
            Fx.groundBolts(sl, cx, cy, cz, 12, 14);
            Fx.sphere(sl, ParticleTypes.END_ROD, cx, cy + 1, cz, 0.6, 140);
            Fx.crown(sl, Fx.GOLD, cx, cy, cz, 10, 24, 7);
            for (LivingEntity t : around(sl, p, 11)) {
                hit(sl, p, t, d);
                shove(t, p, 1.0);
            }
            heal(p, 20);
            p.setAbsorptionAmount(Math.max(p.getAbsorptionAmount(), 10.0f));
            Fx.rune(sl, cx, cy + 0.05, cz, 11, Fx.GOLD, Fx.CYAN);
            Fx.risingRings(sl, Fx.GOLD, cx, cy, cz, 5, 6);
            for (int k = 1; k <= 4; k++) {
                final double r = k * 2.5;
                Scheduler.after(k * 2, () -> {
                    Fx.shock(sl, cx, cy, cz, r);
                    Fx.ring(sl, Fx.GOLD, cx, cy + 0.1, cz, r);
                });
            }
            Fx.sound(sl, cx, cy, cz, 1.5f, 0.6f);
        });
        return true;
    }
}
