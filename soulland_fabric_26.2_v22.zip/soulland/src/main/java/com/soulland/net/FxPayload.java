package com.soulland.net;

import com.soulland.SoulLand;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

import java.nio.ByteBuffer;

/**
 * เซิร์ฟเวอร์ -> ไคลเอนต์: สั่งแสดงเอฟเฟกต์สกิลแบบสร้างเอง (วาดด้วยภาพ/โมเดลของมอดเอง ไม่ใช้พาร์ติเคิลของเกม)
 * ข้อมูลแพ็กเป็นไบต์: type, x,y,z, x2,y2,z2, size, life, tint, ref
 */
public record FxPayload(byte[] data) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<FxPayload> TYPE =
            new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(SoulLand.MOD_ID, "fx"));

    public static final StreamCodec<ByteBuf, FxPayload> CODEC =
            StreamCodec.composite(ByteBufCodecs.BYTE_ARRAY, FxPayload::data, FxPayload::new);

    /** ข้อมูลที่ถอดแล้ว */
    public record Decoded(int type, float x, float y, float z, float x2, float y2, float z2,
                          float size, int life, int tint, int ref) {}

    public static FxPayload make(int type, double x, double y, double z, double x2, double y2, double z2,
                                 double size, int life, int tint, int ref) {
        ByteBuffer b = ByteBuffer.allocate(44);
        b.putInt(type);
        b.putFloat((float) x).putFloat((float) y).putFloat((float) z);
        b.putFloat((float) x2).putFloat((float) y2).putFloat((float) z2);
        b.putFloat((float) size);
        b.putInt(life).putInt(tint).putInt(ref);
        return new FxPayload(b.array());
    }

    public Decoded decode() {
        ByteBuffer b = ByteBuffer.wrap(data);
        int type = b.getInt();
        float x = b.getFloat(), y = b.getFloat(), z = b.getFloat();
        float x2 = b.getFloat(), y2 = b.getFloat(), z2 = b.getFloat();
        float size = b.getFloat();
        int life = b.getInt(), tint = b.getInt(), ref = b.getInt();
        return new Decoded(type, x, y, z, x2, y2, z2, size, life, tint, ref);
    }

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
