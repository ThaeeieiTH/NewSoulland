package com.soulland.net;

import com.soulland.SoulLand;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** เซิร์ฟเวอร์ -> ไคลเอนต์: เริ่มอนิเมชั่นปลุกวิญญาณยุทธ์ (กล้อง + ลอยตัว) */
public record AwakenPayload(int unused) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<AwakenPayload> TYPE =
            new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(SoulLand.MOD_ID, "awaken"));

    public static final StreamCodec<ByteBuf, AwakenPayload> CODEC =
            StreamCodec.composite(ByteBufCodecs.VAR_INT, AwakenPayload::unused, AwakenPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
