package com.soulland.net;

import com.soulland.SoulLand;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** เซิร์ฟเวอร์ -> ไคลเอนต์: เริ่มอนิเมชั่นดูดซับวงแหวน (tier = ระดับวงแหวน 0-5) */
public record AbsorbPayload(int tier) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<AbsorbPayload> TYPE =
            new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(SoulLand.MOD_ID, "absorb"));

    public static final StreamCodec<ByteBuf, AbsorbPayload> CODEC =
            StreamCodec.composite(ByteBufCodecs.VAR_INT, AbsorbPayload::tier, AbsorbPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
