package com.soulland.client;

import com.soulland.SoulLand;
import com.soulland.net.FxPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * เอฟเฟกต์สกิลแบบสร้างเอง (ฝั่งไคลเอนต์): คลื่นคมเคียว วงเวท วงแหวน สายฟ้า เสาแสง ดวงอาทิตย์ ปีก เคียวยักษ์ ประกายดาว
 * วาดเป็นภาพ/สี่เหลี่ยมโปร่งแสงเรืองแสงทุกเฟรม ตามข้อมูลที่เซิร์ฟเวอร์ส่งมา (FxPayload) ไม่ใช้พาร์ติเคิลของเกม
 */
public final class Fxs {
    // ชนิด (ตรงกับ Fx ฝั่งเซิร์ฟเวอร์)
    private static final int BEAM = 0, RING = 1, RUNE = 2, CRESCENT = 3, BOLT = 4, PILLAR = 5, SUN = 6,
            WINGS = 7, SCYTHE = 8, SPARK = 9, SHELL = 10;

    private static final Identifier[] TEX = {
            tex("fx_beam"), tex("fx_ring"), tex("fx_rune"), tex("fx_crescent"), tex("fx_bolt"), tex("fx_pillar"),
            tex("fx_sun"), tex("fx_wing"), tex("fx_scythe"), tex("fx_spark"), tex("fx_shell")
    };

    private static final class E {
        final FxPayload.Decoded d;
        int age = 0;
        double[] ox, oy, oz;      // ทิศประกายแต่ละดวง (SPARK)
        float[] roll;

        E(FxPayload.Decoded d) {
            this.d = d;
            if (d.type() == SPARK) {
                int n = Math.max(1, Math.min(60, d.ref()));
                ox = new double[n];
                oy = new double[n];
                oz = new double[n];
                roll = new float[n];
                Random r = new Random(Double.doubleToLongBits(d.x() * 31 + d.z()) ^ d.life());
                for (int i = 0; i < n; i++) {
                    double y = r.nextDouble() * 2 - 1;
                    double a = r.nextDouble() * Math.PI * 2;
                    double rr = Math.sqrt(1 - y * y);
                    double sp = 0.35 + r.nextDouble() * 0.65;
                    ox[i] = Math.cos(a) * rr * sp;
                    oy[i] = y * sp;
                    oz[i] = Math.sin(a) * rr * sp;
                    roll[i] = (float) (r.nextDouble() * Math.PI);
                }
            }
        }
    }

    private static final List<E> LIST = new ArrayList<>();

    private Fxs() {}

    private static Identifier tex(String name) {
        return Identifier.fromNamespaceAndPath(SoulLand.MOD_ID, "textures/fx/" + name + ".png");
    }

    public static void add(FxPayload p) {
        if (LIST.size() > 700) return;
        LIST.add(new E(p.decode()));
    }

    public static void tick() {
        Iterator<E> it = LIST.iterator();
        while (it.hasNext()) {
            E e = it.next();
            e.age++;
            if (e.age >= Math.max(1, e.d.life())) it.remove();
        }
    }

    public static void clear() {
        LIST.clear();
    }

    private static double ease(double x) {
        x = Mth.clamp(x, 0.0, 1.0);
        return x * x * (3 - 2 * x);
    }

    private static void add(Map<Identifier, List<KnightRenderer.Quad>> out, int type, double[] p, float[] u, float[] v, int color) {
        out.computeIfAbsent(TEX[type], k -> new ArrayList<>()).add(new KnightRenderer.Quad(TEX[type], p, u, v, color));
    }

    private static final float[] U4 = {0f, 0f, 1f, 1f};
    private static final float[] V4 = {0f, 1f, 1f, 0f};

    public static Map<Identifier, List<KnightRenderer.Quad>> collect(Minecraft mc, float partial,
                                                                      double camX, double camY, double camZ) {
        Map<Identifier, List<KnightRenderer.Quad>> out = new LinkedHashMap<>();
        if (LIST.isEmpty()) return out;
        for (E e : LIST) {
            FxPayload.Decoded d = e.d;
            double age = e.age + partial;
            double f = Math.min(1.0, age / Math.max(1, d.life()));
            double alpha = Math.min(1.0, f / 0.1) * Math.min(1.0, (1.0 - f) / 0.35);
            alpha = Mth.clamp(alpha, 0.0, 1.0);
            if (alpha <= 0.01) continue;
            int color = ((int) (255 * alpha) << 24) | (d.tint() & 0xFFFFFF);
            switch (d.type()) {
                case BEAM -> beam(out, d, camX, camY, camZ, color);
                case RING -> flat(out, RING, d, f, age, false, color);
                case RUNE -> flat(out, RUNE, d, f, age, true, color);
                case CRESCENT -> crescent(out, d, age, color);
                case BOLT -> {
                    int flick = (e.age + (int) (partial * 3)) % 3 == 0 ? 0xAA : 0xFF;
                    int c = (Math.min(flick, (int) (255 * alpha)) << 24) | (d.tint() & 0xFFFFFF);
                    vertical(out, BOLT, d, d.size() * 0.22, camX, camZ, c);
                }
                case PILLAR -> vertical(out, PILLAR, d, d.x2(), camX, camZ, color);
                case SUN -> {
                    double s = Mth.lerp(ease(f), d.size(), d.x2());
                    billboard(out, SUN, d.x(), d.y(), d.z(), s, s, 0f, camX, camY, camZ, color);
                }
                case SHELL -> billboard(out, SHELL, d.x(), d.y(), d.z(), d.size(), d.size(), 0f, camX, camY, camZ, color);
                case SCYTHE -> {
                    double ang = Mth.lerp(ease(f), d.x2(), d.y2());
                    billboard(out, SCYTHE, d.x(), d.y(), d.z(), d.size() * 0.764, d.size(), (float) Math.toRadians(ang),
                            camX, camY, camZ, color);
                }
                case SPARK -> spark(out, e, f, camX, camY, camZ, color);
                case WINGS -> wings(out, mc, d, age, partial, color);
                default -> { }
            }
        }
        return out;
    }

    // ---------- รูปทรง ----------

    private static void beam(Map<Identifier, List<KnightRenderer.Quad>> out, FxPayload.Decoded d,
                             double camX, double camY, double camZ, int color) {
        double ax = d.x2() - d.x(), ay = d.y2() - d.y(), az = d.z2() - d.z();
        double mx = (d.x() + d.x2()) / 2 - camX, my = (d.y() + d.y2()) / 2 - camY, mz = (d.z() + d.z2()) / 2 - camZ;
        double sx = ay * mz - az * my, sy = az * mx - ax * mz, sz = ax * my - ay * mx;
        double sl = Math.sqrt(sx * sx + sy * sy + sz * sz);
        if (sl < 1e-6) return;
        double w = d.size() / 2 / sl;
        sx *= w;
        sy *= w;
        sz *= w;
        double[] p = {d.x() - sx, d.y() - sy, d.z() - sz, d.x() + sx, d.y() + sy, d.z() + sz,
                d.x2() + sx, d.y2() + sy, d.z2() + sz, d.x2() - sx, d.y2() - sy, d.z2() - sz};
        add(out, BEAM, p, new float[]{0f, 0f, 1f, 1f}, new float[]{0f, 1f, 1f, 0f}, color);
    }

    /** วงราบกับพื้น (RING ขยายจาก size ไป x2 / RUNE หมุนช้า) */
    private static void flat(Map<Identifier, List<KnightRenderer.Quad>> out, int type, FxPayload.Decoded d,
                             double f, double age, boolean spin, int color) {
        double r = spin ? d.size() : Mth.lerp(ease(f), d.size(), d.x2() <= 0 ? d.size() : d.x2());
        double half = r / 0.92;
        double ang = spin ? age * 0.04 : 0;
        double c = Math.cos(ang), s = Math.sin(ang);
        double[][] k = {{-1, -1}, {-1, 1}, {1, 1}, {1, -1}};
        double[] p = new double[12];
        for (int i = 0; i < 4; i++) {
            double lx = k[i][0] * half, lz = k[i][1] * half;
            p[i * 3] = d.x() + lx * c - lz * s;
            p[i * 3 + 1] = d.y() + 0.05;
            p[i * 3 + 2] = d.z() + lx * s + lz * c;
        }
        add(out, type, p, U4, V4, color);
    }

    /** คลื่นคมเคียวแบนราบ พุ่งไปทิศ (x2,z2) ด้วยความเร็ว y2 */
    private static void crescent(Map<Identifier, List<KnightRenderer.Quad>> out, FxPayload.Decoded d, double age, int color) {
        double dx = d.x2(), dz = d.z2();
        double dl = Math.hypot(dx, dz);
        if (dl < 1e-6) return;
        dx /= dl;
        dz /= dl;
        double lx = -dz, lz = dx;
        double cx = d.x() + dx * d.y2() * age, cz = d.z() + dz * d.y2() * age;
        double w = d.size(), dep = d.size() * 0.5;
        double[] p = new double[12];
        float[] u = {0f, 0f, 1f, 1f};
        float[] v = {0f, 1f, 1f, 0f};
        for (int i = 0; i < 4; i++) {
            p[i * 3] = cx + lx * (u[i] - 0.5) * w + dx * (0.5 - v[i]) * dep;
            p[i * 3 + 1] = d.y();
            p[i * 3 + 2] = cz + lz * (u[i] - 0.5) * w + dz * (0.5 - v[i]) * dep;
        }
        add(out, CRESCENT, p, u, v, color);
    }

    /** แผ่นตั้งหันเข้าหากล้องในแนวนอน (ฐานอยู่ที่พื้น สูง size) */
    private static void vertical(Map<Identifier, List<KnightRenderer.Quad>> out, int type, FxPayload.Decoded d,
                                 double width, double camX, double camZ, int color) {
        double nx = camX - d.x(), nz = camZ - d.z();
        double nl = Math.max(1e-6, Math.hypot(nx, nz));
        double rx = -nz / nl, rz = nx / nl;
        double[] p = new double[12];
        float[] u = {0f, 0f, 1f, 1f};
        float[] v = {0f, 1f, 1f, 0f};
        for (int i = 0; i < 4; i++) {
            p[i * 3] = d.x() + rx * (u[i] - 0.5) * width;
            p[i * 3 + 1] = d.y() + (1 - v[i]) * d.size();
            p[i * 3 + 2] = d.z() + rz * (u[i] - 0.5) * width;
        }
        add(out, type, p, u, v, color);
    }

    /** แผ่นหันเข้าหากล้องเต็มตัว (หมุนรอบแกนมองได้ด้วย roll) */
    private static void billboard(Map<Identifier, List<KnightRenderer.Quad>> out, int type, double px, double py, double pz,
                                  double hw, double hh, float roll, double camX, double camY, double camZ, int color) {
        double tx = camX - px, ty = camY - py, tz = camZ - pz;
        double tl = Math.sqrt(tx * tx + ty * ty + tz * tz);
        if (tl < 1e-6) return;
        tx /= tl;
        ty /= tl;
        tz /= tl;
        double hl = Math.max(1e-6, Math.hypot(tz, tx));
        double rx = tz / hl, ry = 0, rz = -tx / hl;
        double ux = ty * rz - tz * ry, uy = tz * rx - tx * rz, uz = tx * ry - ty * rx;
        double c = Math.cos(roll), s = Math.sin(roll);
        double r2x = rx * c + ux * s, r2y = ry * c + uy * s, r2z = rz * c + uz * s;
        double u2x = -rx * s + ux * c, u2y = -ry * s + uy * c, u2z = -rz * s + uz * c;
        double[][] k = {{-1, 1}, {-1, -1}, {1, -1}, {1, 1}};
        double[] p = new double[12];
        for (int i = 0; i < 4; i++) {
            p[i * 3] = px + r2x * k[i][0] * hw + u2x * k[i][1] * hh;
            p[i * 3 + 1] = py + r2y * k[i][0] * hw + u2y * k[i][1] * hh;
            p[i * 3 + 2] = pz + r2z * k[i][0] * hw + u2z * k[i][1] * hh;
        }
        add(out, type, p, U4, V4, color);
    }

    private static void spark(Map<Identifier, List<KnightRenderer.Quad>> out, E e, double f,
                              double camX, double camY, double camZ, int color) {
        double reach = e.d.size() * (1 - Math.pow(1 - f, 2));
        double sz = 0.28 * (1 - f * 0.7);
        for (int i = 0; i < e.ox.length; i++) {
            billboard(out, SPARK, e.d.x() + e.ox[i] * reach, e.d.y() + e.oy[i] * reach, e.d.z() + e.oz[i] * reach,
                    sz, sz, e.roll[i] + (float) (f * 2), camX, camY, camZ, color);
        }
    }

    /** ปีกพลังงาน 2 ข้าง (ติดตัวเอนทิตี ถ้ามี ref >= 0 หรือวางนิ่งที่จุดที่ระบุ) */
    private static void wings(Map<Identifier, List<KnightRenderer.Quad>> out, Minecraft mc, FxPayload.Decoded d,
                              double age, float partial, int color) {
        double px = d.x(), py = d.y(), pz = d.z(), h = 1.8, fx, fz;
        Entity ent = (d.ref() >= 0 && mc.level != null) ? mc.level.getEntity(d.ref()) : null;
        if (ent != null) {
            px = Mth.lerp((double) partial, ent.xo, ent.getX());
            py = Mth.lerp((double) partial, ent.yo, ent.getY());
            pz = Mth.lerp((double) partial, ent.zo, ent.getZ());
            h = ent.getBbHeight();
            float yaw = ent instanceof LivingEntity le ? Mth.rotLerp(partial, le.yBodyRotO, le.yBodyRot) : ent.getYRot();
            double th = Math.toRadians(yaw);
            fx = -Math.sin(th);
            fz = Math.cos(th);
        } else {
            double dl = Math.max(1e-6, Math.hypot(d.x2(), d.z2()));
            fx = d.x2() / dl;
            fz = d.z2() / dl;
        }
        double lx = -fz, lz = fx;                       // ซ้ายของทิศหน้า
        double scale = Math.max(0.3, d.size());
        double wingW = 2.4 * scale, wingH = wingW * 275.0 / 256.0;
        double shoulderY = py + h * 0.55;
        for (int s = 1; s >= -1; s -= 2) {
            double alpha = Math.toRadians(40 + Math.sin(age * 0.2) * 9);
            double ldx = s * lx * Math.cos(alpha) - fx * Math.sin(alpha);
            double ldz = s * lz * Math.cos(alpha) - fz * Math.sin(alpha);
            double lean = Math.toRadians(14);
            double udx = -fx * Math.sin(lean), udz = -fz * Math.sin(lean), udy = Math.cos(lean);
            double ox = px - fx * 0.22 + s * lx * 0.1;
            double oy = shoulderY - 0.2;
            double oz = pz - fz * 0.22 + s * lz * 0.1;
            double[][] ab = {{0, 0}, {1, 0}, {1, 1}, {0, 1}};
            double[] p = new double[12];
            float[] u = new float[4];
            float[] v = new float[4];
            for (int i = 0; i < 4; i++) {
                double a = ab[i][0], b = ab[i][1];
                p[i * 3] = ox + ldx * a * wingW + udx * b * wingH;
                p[i * 3 + 1] = oy + udy * b * wingH;
                p[i * 3 + 2] = oz + ldz * a * wingW + udz * b * wingH;
                u[i] = (float) (s > 0 ? 1.0 - a : a);
                v[i] = (float) (1.0 - b);
            }
            add(out, WINGS, p, u, v, color);
        }
    }
}
