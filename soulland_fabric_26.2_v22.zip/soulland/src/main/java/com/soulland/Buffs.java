package com.soulland;

import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** บัฟชั่วคราวจากสกิล: เพิ่มพลังโจมตี (คูณ) ความเร็วเดิน (บวกเป็นสัดส่วน) และระยะโจมตี */
public final class Buffs {
    private static final class Def {
        final long until;
        final double attack, speed, range;

        Def(long until, double attack, double speed, double range) {
            this.until = until;
            this.attack = attack;
            this.speed = speed;
            this.range = range;
        }
    }

    private static final Map<UUID, Map<String, Def>> ACTIVE = new HashMap<>();

    private Buffs() {}

    private static Identifier id(String kind, String key) {
        return Identifier.fromNamespaceAndPath(SoulLand.MOD_ID, "buff_" + kind + "_" + key);
    }

    /** ใส่บัฟ key นาน ticks: attack = ตัวคูณดาเมจ, speed = เพิ่มความเร็วเดิน (1.0 = เร็วขึ้น 100%), range = ระยะโจมตีที่เพิ่ม */
    public static void apply(ServerPlayer p, String key, int ticks, double attack, double speed, double range) {
        if (!(p.level() instanceof ServerLevel sl)) return;
        final long until = sl.getServer().getTickCount() + ticks;
        ACTIVE.computeIfAbsent(p.getUUID(), k -> new HashMap<>()).put(key, new Def(until, attack, speed, range));

        AttributeInstance sp = p.getAttribute(Attributes.MOVEMENT_SPEED);
        if (sp != null && speed != 0) {
            sp.removeModifier(id("speed", key));
            sp.addOrReplacePermanentModifier(new AttributeModifier(id("speed", key), speed,
                    AttributeModifier.Operation.ADD_MULTIPLIED_BASE));
        }
        AttributeInstance rg = p.getAttribute(Attributes.ENTITY_INTERACTION_RANGE);
        if (rg != null && range != 0) {
            rg.removeModifier(id("range", key));
            rg.addOrReplacePermanentModifier(new AttributeModifier(id("range", key), range,
                    AttributeModifier.Operation.ADD_VALUE));
        }
        Scheduler.after(ticks + 1, () -> expire(p, key, until));
    }

    private static void strip(ServerPlayer p, String key) {
        AttributeInstance sp = p.getAttribute(Attributes.MOVEMENT_SPEED);
        if (sp != null) sp.removeModifier(id("speed", key));
        AttributeInstance rg = p.getAttribute(Attributes.ENTITY_INTERACTION_RANGE);
        if (rg != null) rg.removeModifier(id("range", key));
    }

    private static void expire(ServerPlayer p, String key, long until) {
        Map<String, Def> m = ACTIVE.get(p.getUUID());
        if (m == null) return;
        Def d = m.get(key);
        if (d == null || d.until != until) return;
        m.remove(key);
        strip(p, key);
        Soul.msg(p, "บัฟหมดเวลา", true);
    }

    /** ตัวคูณพลังโจมตีรวมของบัฟที่ยังทำงานอยู่ */
    public static double attackMult(ServerPlayer p) {
        Map<String, Def> m = ACTIVE.get(p.getUUID());
        if (m == null) return 1.0;
        double r = 1.0;
        for (Def d : m.values()) r *= d.attack;
        return r;
    }

    public static void clear(ServerPlayer p) {
        Map<String, Def> m = ACTIVE.remove(p.getUUID());
        if (m == null) return;
        for (String key : m.keySet()) strip(p, key);
    }

    public static void clearAll() {
        ACTIVE.clear();
    }
}
