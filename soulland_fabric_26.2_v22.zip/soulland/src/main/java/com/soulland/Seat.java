package com.soulland;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;

import java.lang.reflect.Method;
import java.util.Locale;
import java.util.UUID;

/** ที่นั่งล่องหน (เอนทิตี interaction ขนาดเล็ก) ให้ผู้เล่นนั่งตอนดูดซับวงแหวน — เป็นท่านั่งแบบเดียวกับนั่งบนเรือ/รถราง */
public final class Seat {
    private Seat() {}

    public static void sit(ServerPlayer p, int ticks) {
        if (!(p.level() instanceof ServerLevel sl)) return;
        MinecraftServer server = sl.getServer();
        UUID u = UUID.randomUUID();
        int a = (int) (u.getMostSignificantBits() >> 32);
        int b = (int) u.getMostSignificantBits();
        int c = (int) (u.getLeastSignificantBits() >> 32);
        int d = (int) u.getLeastSignificantBits();
        String cmd = String.format(Locale.ROOT,
                "summon minecraft:interaction %.3f %.3f %.3f {UUID:[I;%d,%d,%d,%d],Tags:[\"soulland_ring\"],width:0.1f,height:0.1f}",
                p.getX(), p.getY() - 0.25, p.getZ(), a, b, c, d);
        CommandSourceStack src = server.createCommandSourceStack().withLevel(sl).withSuppressedOutput();
        server.getCommands().performPrefixedCommand(src, cmd);
        Entity seat = sl.getEntity(u);
        if (seat == null) return;
        if (!mount(p, seat)) {
            seat.discard();
            return;
        }
        Scheduler.after(ticks, () -> {
            p.stopRiding();
            Entity e = sl.getEntity(u);
            if (e != null) e.discard();
        });
    }

    /** ให้ rider ขึ้นไปนั่งบน vehicle — เรียกผ่าน reflection เพราะรูปแบบเมธอดเปลี่ยนตามเวอร์ชัน */
    private static boolean mount(Entity rider, Entity vehicle) {
        Object r = invoke(rider, new Class<?>[]{Entity.class, boolean.class, boolean.class}, vehicle, true, true);
        if (r == null) r = invoke(rider, new Class<?>[]{Entity.class, boolean.class}, vehicle, true);
        if (r == null) r = invoke(rider, new Class<?>[]{Entity.class}, vehicle);
        return rider.getVehicle() == vehicle;
    }

    private static Object invoke(Entity target, Class<?>[] types, Object... args) {
        try {
            Method m = Entity.class.getMethod("startRiding", types);
            return m.invoke(target, args);
        } catch (ReflectiveOperationException e) {
            return null;
        }
    }
}
