package com.soulland;

import com.soulland.net.FxPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

import java.util.Random;

/**
 * เอฟเฟกต์สกิลแบบสร้างเอง: ไม่ใช้พาร์ติเคิลของเกม — ส่งคำสั่งไปให้ไคลเอนต์วาดด้วยภาพ/โมเดลของมอด
 * (คลื่นเคียว วงเวท สายฟ้า เสาแสง ดวงอาทิตย์ ปีก เคียวยักษ์ ฯลฯ)
 * ค่าสี Fx.GOLD / CYAN / BLUE / PURPLE ใช้เป็นตัวระบุโทนสีของเอฟเฟกต์
 */
public final class Fx {
    public static final DustParticleOptions BLUE = new DustParticleOptions(0x2EE6FF, 1.0f);
    public static final DustParticleOptions CYAN = new DustParticleOptions(0xC8F8FF, 0.8f);
    public static final DustParticleOptions PURPLE = new DustParticleOptions(0xAA00FF, 1.1f);
    public static final DustParticleOptions GOLD = new DustParticleOptions(0xFFC800, 1.3f);

    // ชนิดเอฟเฟกต์ (ต้องตรงกับฝั่งไคลเอนต์ Fxs)
    public static final int BEAM = 0, RING = 1, RUNE = 2, CRESCENT = 3, BOLT = 4, PILLAR = 5, SUN = 6,
            WINGS = 7, SCYTHE = 8, SPARK = 9, SHELL = 10;

    private static final Random RNG = new Random();

    private Fx() {}

    private static int tint(ParticleOptions o) {
        if (o == GOLD) return 0xFFD040;
        if (o == CYAN) return 0xBFF4FF;
        if (o == BLUE) return 0x38DCFF;
        if (o == PURPLE) return 0xC878FF;
        return 0xFFF0C0;
    }

    public static void send(ServerLevel sl, int type, double x, double y, double z, double x2, double y2, double z2,
                            double size, int life, int tint, int ref) {
        FxPayload pl = FxPayload.make(type, x, y, z, x2, y2, z2, size, life, tint, ref);
        for (ServerPlayer sp : sl.players()) {
            if (sp.distanceToSqr(x, y, z) < 96.0 * 96.0) {
                ServerPlayNetworking.send(sp, pl);
            }
        }
    }

    public static void sound(ServerLevel sl, double x, double y, double z, float vol, float pitch) {
        sl.playSound(null, x, y, z, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, vol, pitch);
    }

    // ------------------------------------------------------------------
    //  เอฟเฟกต์ระดับสูง (ใช้ในสกิลโดยตรง)
    // ------------------------------------------------------------------

    /** คลื่นคมเคียวสีทองพุ่งไปข้างหน้า (ทิศ dx,dz ความเร็ว blocks/tick) */
    public static void wave(ServerLevel sl, ParticleOptions o, double x, double y, double z,
                            double dx, double dz, double size, double speed, int life) {
        send(sl, CRESCENT, x, y, z, dx, speed, dz, size, life, tint(o), 0);
    }

    /** ดวงอาทิตย์ขนาดโตขึ้นจาก from ถึง to */
    public static void sun(ServerLevel sl, double x, double y, double z, double from, double to, int life) {
        send(sl, SUN, x, y, z, to, 0, 0, from, life, 0xFFE9A0, 0);
    }

    /** เคียวยักษ์หมุนฟัน (องศาเริ่ม -> องศาจบ) */
    public static void scythe(ServerLevel sl, double x, double y, double z, double size, double angFrom, double angTo, int life) {
        send(sl, SCYTHE, x, y, z, angFrom, angTo, 0, size, life, 0xFFFFFF, 0);
    }

    /** ปีกพลังงานติดตัวผู้เล่น (ตามตัวตลอดอายุเอฟเฟกต์) */
    public static void wingsBound(ServerLevel sl, int entityId, double x, double y, double z, double scale, int life) {
        send(sl, WINGS, x, y, z, 0, 0, 1, scale, life, 0xFFFFFF, entityId);
    }

    /** ประกายดาวระเบิดกระจาย */
    public static void spark(ServerLevel sl, double x, double y, double z, int count, double radius) {
        send(sl, SPARK, x, y, z, 0, 0, 0, radius, 16, 0xFFEFA8, Math.min(60, Math.max(1, count)));
    }

    // ------------------------------------------------------------------
    //  ตัวช่วยเดิม (คงชื่อไว้ แต่เปลี่ยนไปวาดด้วยเอฟเฟกต์ของมอด)
    // ------------------------------------------------------------------

    public static void line(ServerLevel sl, ParticleOptions o, double x0, double y0, double z0,
                            double x1, double y1, double z1, double step) {
        send(sl, BEAM, x0, y0, z0, x1, y1, z1, 0.22, 10, tint(o), 0);
    }

    public static void ring(ServerLevel sl, ParticleOptions o, double cx, double cy, double cz, double r) {
        send(sl, RING, cx, cy, cz, r, 0, 0, r, 10, tint(o), 0);
    }

    /** ดาว/รูปหลายเหลี่ยม (ใช้วงเวทขนาดเล็กแทน) */
    public static void star(ServerLevel sl, ParticleOptions o, double cx, double cy, double cz, double r, int n, double rot) {
        send(sl, RUNE, cx, cy + 0.02, cz, 0, 0, 0, r, 18, tint(o), 0);
    }

    /** วงเวทบนพื้น */
    public static void rune(ServerLevel sl, double cx, double cy, double cz, double r,
                            ParticleOptions main, ParticleOptions accent) {
        send(sl, RUNE, cx, cy, cz, 0, 0, 0, r, 50, tint(main), 0);
        send(sl, RING, cx, cy + 0.03, cz, r * 1.05, 0, 0, r * 0.85, 26, tint(accent), 0);
    }

    /** เกลียว: วงแหวนซ้อนขึ้นไปตามความสูง */
    public static void helix(ServerLevel sl, ParticleOptions o, double cx, double cy, double cz,
                             double r, double h, double turns, double phase) {
        int n = Math.max(3, (int) (h * 1.4));
        for (int i = 0; i < n; i++) {
            send(sl, RING, cx, cy + h * i / n, cz, r, 0, 0, r, 14, tint(o), 0);
        }
    }

    public static void vortex(ServerLevel sl, ParticleOptions o, double cx, double cy, double cz,
                              double r0, double r1, double h, double turns, double phase) {
        int n = Math.max(3, (int) (h * 1.4));
        for (int i = 0; i < n; i++) {
            double t = (double) i / n;
            double r = r0 + (r1 - r0) * t;
            send(sl, RING, cx, cy + h * t, cz, r, 0, 0, r * 0.9, 14, tint(o), 0);
        }
    }

    /** คลื่นกระแทก: วงแผ่ขยายจากรัศมี r */
    public static void shock(ServerLevel sl, double cx, double cy, double cz, double r) {
        send(sl, RING, cx, cy + 0.1, cz, r * 0.6, 0, 0, r * 1.4, 12, 0xFFE070, 0);
    }

    /** เสาแสงตั้งขึ้นฟ้า */
    public static void pillar(ServerLevel sl, double x, double y, double z, double h) {
        send(sl, PILLAR, x, y, z, 1.8, 0, 0, h, 22, 0xFFE070, 0);
    }

    /** จุดกระทบ: ประกายดาว + วงแตก + เสียงฟ้าร้อง */
    public static void impact(ServerLevel sl, double x, double y, double z) {
        spark(sl, x, y + 0.6, z, 10, 1.4);
        send(sl, RING, x, y + 0.1, z, 0.5, 0, 0, 1.7, 9, 0xFFE070, 0);
        sound(sl, x, y, z, 0.6f, 1.0f + RNG.nextFloat() * 0.3f);
    }

    /** สายฟ้าจากฟ้าลงพื้น */
    public static void bolt(ServerLevel sl, double x, double y, double z, double height) {
        send(sl, BOLT, x, y, z, 0, 0, 0, height, 9, 0xCFF4FF, 0);
        impact(sl, x, y, z);
    }

    /** ลำแสงเส้นตรง */
    public static void beam(ServerLevel sl, double sx, double sy, double sz,
                            double dx, double dy, double dz, double len) {
        send(sl, BEAM, sx, sy, sz, sx + dx * len, sy + dy * len, sz + dz * len, 0.7, 12, 0xFFE070, 0);
        send(sl, BEAM, sx, sy, sz, sx + dx * len, sy + dy * len, sz + dz * len, 0.25, 12, 0xFFFFFF, 0);
    }

    /** ระเบิดประกาย */
    public static void sphere(ServerLevel sl, ParticleOptions o, double cx, double cy, double cz, double speed, int n) {
        spark(sl, cx, cy, cz, Math.max(6, n / 3), Math.max(1.0, speed * 9));
    }

    /** โดมพลัง (วงแสงหันเข้าหากล้อง) */
    public static void shell(ServerLevel sl, ParticleOptions o, double cx, double cy, double cz, double rad, int n) {
        send(sl, SHELL, cx, cy, cz, 0, 0, 0, rad * 2, 8, tint(o), 0);
    }

    /** สายฟ้าแผ่ไปตามพื้น */
    public static void groundBolts(ServerLevel sl, double cx, double cy, double cz, double len, int rays) {
        double base = RNG.nextDouble() * Math.PI * 2;
        for (int i = 0; i < rays; i++) {
            double a = base + Math.PI * 2 * i / rays;
            double dx = Math.cos(a), dz = Math.sin(a);
            int segs = Math.max(2, (int) (len / 3));
            double step = len / segs;
            double px = cx, pz = cz;
            for (int s = 1; s <= segs; s++) {
                double j = (RNG.nextDouble() - 0.5) * 0.9 * step;
                double nx = cx + dx * step * s - dz * j;
                double nz = cz + dz * step * s + dx * j;
                send(sl, BEAM, px, cy + 0.15, pz, nx, cy + 0.15, nz, 0.28, 12, 0xC8F0FF, 0);
                px = nx;
                pz = nz;
            }
            spark(sl, px, cy + 0.3, pz, 3, 0.7);
        }
    }

    /** มงกุฎหนามแสง */
    public static void crown(ServerLevel sl, ParticleOptions o, double cx, double cy, double cz,
                             double r, int spikes, double h) {
        for (int i = 0; i < spikes; i++) {
            double a = Math.PI * 2 * i / spikes;
            double top = h * (0.6 + RNG.nextDouble() * 0.4);
            send(sl, PILLAR, cx + Math.cos(a) * r, cy, cz + Math.sin(a) * r, 0.55, 0, 0, top, 18, tint(o), 0);
        }
    }

    /** วงแหวนลอยขึ้นฟ้าทีละวง */
    public static void risingRings(ServerLevel sl, ParticleOptions o, double cx, double cy, double cz,
                                   double r, int count) {
        for (int k = 0; k < count; k++) {
            final double yy = cy + 0.2 + k * 0.55;
            final double rr = r * (1.0 - k * 0.07);
            Scheduler.after(k * 3 + 1, () -> ring(sl, o, cx, yy, cz, rr));
        }
    }

    /** เสี้ยวจันทร์ (นิ่ง) ทิศ (dx,dz) */
    public static void crescent(ServerLevel sl, ParticleOptions o, double cx, double cy, double cz,
                                double dx, double dz, double r, double spanDeg, double thick) {
        wave(sl, o, cx + dx * r * 0.7, cy, cz + dz * r * 0.7, dx, dz, Math.max(2.0, r * 1.5 * (spanDeg / 110.0)), 0.0, 8);
    }

    /** ปีกขนนกกางด้านหลัง (นิ่ง ชั่วคราว) */
    public static void wings(ServerLevel sl, double cx, double cy, double cz, double dx, double dz, double scale) {
        send(sl, WINGS, cx, cy, cz, dx, 0, dz, scale, 26, 0xFFFFFF, -1);
    }

    /** ดาบแสงปักลงมาจากฟ้า */
    public static void lightSword(ServerLevel sl, double x, double y, double z, double h) {
        send(sl, PILLAR, x, y, z, 0.9, 0, 0, h, 14, 0xFFE070, 0);
        spark(sl, x, y + 0.4, z, 6, 0.9);
        ring(sl, GOLD, x, y + 0.1, z, 1.0);
    }
}
