package com.soulland;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/** 9 ทักษะของค้อนเฮ่าเทียน — ทักษะที่ k ปลดล็อกเมื่อมีวงแหวนครบ (k-1) วง */
public final class Skills {
    public static final String[] NAMES = {
            "สายฟ้าฟาดฟ้า", "ค้อนสะท้านพื้น", "พุ่งสายฟ้า", "เกราะเฮ่าเทียน", "คลื่นฟ้าตรง",
            "พายุสายฟ้า", "ฟ้าผ่าเป้าหมาย", "วงคลื่นสายฟ้า", "เฮ่าเทียนทลายฟ้า"
    };
    public static final int[] COST = {20, 30, 25, 40, 35, 60, 45, 70, 120};
    public static final int[] COOLDOWN_TICKS = {60, 100, 80, 300, 120, 300, 160, 400, 800};

    private static final DustParticleOptions BLUE = new DustParticleOptions(0x2EE6FF, 1.2f);
    private static final DustParticleOptions GOLD = new DustParticleOptions(0xFFC800, 1.3f);
    private static final DustParticleOptions PURPLE = new DustParticleOptions(0xAA00FF, 1.4f);

    private static final Map<UUID, long[]> COOLDOWNS = new HashMap<>();
    private static final Map<UUID, Long> INVULN_UNTIL = new HashMap<>();
    private static final Random RNG = new Random();

    private Skills() {}

    /** ทักษะลำดับ i (เริ่มที่ 0) ต้องมีวงแหวน i วง */
    public static boolean unlocked(Player p, int i) {
        return Soul.rings(p).length() >= i;
    }

    public static boolean isInvulnerable(ServerPlayer p, long nowTick) {
        Long until = INVULN_UNTIL.get(p.getUUID());
        return until != null && nowTick < until;
    }

    public static void clear(ServerPlayer p) {
        COOLDOWNS.remove(p.getUUID());
        INVULN_UNTIL.remove(p.getUUID());
    }

    public static void clearAll() {
        COOLDOWNS.clear();
        INVULN_UNTIL.clear();
    }

    public static void use(ServerPlayer p) {
        if (!(p.level() instanceof ServerLevel sl)) return;
        MinecraftServer server = sl.getServer();
        int i = Soul.skill(p);
        if (i < 0 || i >= NAMES.length) i = 0;

        if (!unlocked(p, i)) {
            Soul.msg(p, "ทักษะ " + (i + 1) + " ต้องมีวงแหวนครบ " + i + " วง", true);
            return;
        }
        long now = server.getTickCount();
        long[] cd = COOLDOWNS.computeIfAbsent(p.getUUID(), k -> new long[NAMES.length]);
        if (now < cd[i]) {
            Soul.msg(p, "ทักษะยังคูลดาวน์ อีก " + ((cd[i] - now + 19) / 20) + " วินาที", true);
            return;
        }
        if (Soul.power(p) < COST[i]) {
            Soul.msg(p, "พลังวิญญาณไม่พอ (ต้องใช้ " + COST[i] + ")", true);
            return;
        }

        boolean ok = switch (i) {
            case 0 -> s1(sl, p);
            case 1 -> s2(sl, p);
            case 2 -> s3(sl, p);
            case 3 -> s4(sl, p, now);
            case 4 -> s5(sl, p);
            case 5 -> s6(sl, p);
            case 6 -> s7(sl, p);
            case 7 -> s8(sl, p);
            case 8 -> s9(sl, p);
            default -> false;
        };
        if (!ok) return;

        Soul.setPower(p, Soul.power(p) - COST[i]);
        cd[i] = now + COOLDOWN_TICKS[i];
        Soul.msg(p, "ทักษะ " + (i + 1) + ": " + NAMES[i], true);
    }

    // ---------- helpers ----------

    private static float dmg(ServerPlayer p, double mult) {
        return (float) ((8 + Soul.level(p) * 0.4 + Soul.ringBonus(p)) * mult);
    }

    private static java.util.List<LivingEntity> around(ServerLevel sl, ServerPlayer p, double r) {
        return sl.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(r), e -> e != p && e.isAlive());
    }

    private static void hit(ServerLevel sl, ServerPlayer p, LivingEntity t, float d) {
        t.hurtServer(sl, sl.damageSources().playerAttack(p), d);
    }

    /** ผลักเป้าหมายให้ห่างจากผู้เล่น (แทน knockback ที่เปลี่ยนรูปแบบใน 26.2) */
    private static void shove(LivingEntity t, ServerPlayer p, double strength) {
        double dx = t.getX() - p.getX();
        double dz = t.getZ() - p.getZ();
        double len = Math.max(0.001, Math.hypot(dx, dz));
        t.push(dx / len * strength, 0.35, dz / len * strength);
    }

    private static void bolt(ServerLevel sl, double x, double y, double z) {
        LightningBolt b = new LightningBolt(EntityTypes.LIGHTNING_BOLT, sl);
        b.setPos(x, y, z);
        b.setVisualOnly(true);
        sl.addFreshEntity(b);
    }

    private static void ring(ServerLevel sl, double x, double y, double z, double r, DustParticleOptions o, int n) {
        for (int i = 0; i < n; i++) {
            double a = Math.PI * 2 * i / n;
            sl.sendParticles(o, x + Math.cos(a) * r, y, z + Math.sin(a) * r, 1, 0, 0, 0, 0);
        }
    }

    // ---------- 9 ทักษะ ----------

    /** 1 สายฟ้าฟาดฟ้า: ฟ้าผ่าศัตรูรอบตัว (สูงสุด 8 ตัว) */
    private static boolean s1(ServerLevel sl, ServerPlayer p) {
        float d = dmg(p, 1.0);
        int n = 0;
        for (LivingEntity t : around(sl, p, 8)) {
            if (n++ >= 8) break;
            bolt(sl, t.getX(), t.getY(), t.getZ());
            hit(sl, p, t, d);
        }
        ring(sl, p.getX(), p.getY() + 0.1, p.getZ(), 3, BLUE, 32);
        sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 0.5, p.getZ(), 40, 2.5, 0.3, 2.5, 0.2);
        return true;
    }

    /** 2 ค้อนสะท้านพื้น: ฟาดพื้นเป็นคลื่นกระแทก ผลักศัตรูออก */
    private static boolean s2(ServerLevel sl, ServerPlayer p) {
        float d = dmg(p, 1.3);
        for (LivingEntity t : around(sl, p, 6)) {
            hit(sl, p, t, d);
            shove(t, p, 0.9);
        }
        for (int k = 1; k <= 4; k++) {
            ring(sl, p.getX(), p.getY() + 0.1, p.getZ(), k * 1.5, BLUE, 12 + k * 8);
        }
        sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 0.3, p.getZ(), 80, 3, 0.3, 3, 0.3);
        return true;
    }

    /** 3 พุ่งสายฟ้า: พุ่งไปข้างหน้า 8 บล็อก ศัตรูที่ขวางโดนดาเมจ */
    private static boolean s3(ServerLevel sl, ServerPlayer p) {
        Vec3 dir = Vec3.directionFromRotation(0, p.getYRot());
        AABB box = p.getBoundingBox();
        int dist = 0;
        for (int i = 1; i <= 8; i++) {
            if (!sl.noCollision(box.move(dir.x * i, 0, dir.z * i))) break;
            dist = i;
        }
        if (dist == 0) {
            Soul.msg(p, "ข้างหน้าถูกขวาง พุ่งไม่ได้", true);
            return false;
        }
        Vec3 from = p.position();
        float d = dmg(p, 1.2);
        AABB path = box.expandTowards(dir.x * dist, 0, dir.z * dist).inflate(1.5);
        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, path, e -> e != p && e.isAlive())) {
            hit(sl, p, t, d);
        }
        for (int i = 0; i <= dist * 2; i++) {
            double s = i / 2.0;
            sl.sendParticles(BLUE, from.x + dir.x * s, from.y + 1.0, from.z + dir.z * s, 3, 0.2, 0.4, 0.2, 0);
        }
        p.connection.teleport(from.x + dir.x * dist, from.y, from.z + dir.z * dist, p.getYRot(), p.getXRot());
        return true;
    }

    /** 4 เกราะเฮ่าเทียน: อมตะ 3 วินาที + เกราะดูดซับ */
    private static boolean s4(ServerLevel sl, ServerPlayer p, long now) {
        INVULN_UNTIL.put(p.getUUID(), now + 60);
        p.setAbsorptionAmount(Math.max(p.getAbsorptionAmount(), 6.0f));
        for (int k = 0; k < 3; k++) {
            final int step = k;
            Scheduler.after(step * 8, () -> {
                if (p.isAlive()) ring(sl, p.getX(), p.getY() + 0.3 + step * 0.6, p.getZ(), 1.0, GOLD, 24);
            });
        }
        return true;
    }

    /** 5 คลื่นฟ้าตรง: คลื่นสายฟ้าพุ่งเป็นเส้นตรง 14 บล็อก */
    private static boolean s5(ServerLevel sl, ServerPlayer p) {
        Vec3 dir = p.getLookAngle();
        Vec3 start = p.position();
        double len = 14;
        float d = dmg(p, 1.2);
        AABB box = p.getBoundingBox().expandTowards(dir.x * len, dir.y * len, dir.z * len).inflate(2.5);
        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, box, e -> e != p && e.isAlive())) {
            Vec3 rel = t.position().subtract(start);
            double along = rel.dot(dir);
            if (along < 0 || along > len) continue;
            if (rel.subtract(dir.x * along, dir.y * along, dir.z * along).length() > 2.5) continue;
            hit(sl, p, t, d);
        }
        for (double s = 1; s <= len; s += 0.7) {
            sl.sendParticles(BLUE, start.x + dir.x * s, start.y + 1.0 + dir.y * s, start.z + dir.z * s, 2, 0.15, 0.15, 0.15, 0);
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, start.x + dir.x * s, start.y + 1.0 + dir.y * s, start.z + dir.z * s, 1, 0.2, 0.2, 0.2, 0.05);
        }
        return true;
    }

    /** 6 พายุสายฟ้า: ฟ้าผ่าสุ่มรอบตัว 6 ครั้งใน 3 วินาที */
    private static boolean s6(ServerLevel sl, ServerPlayer p) {
        float d = dmg(p, 1.0);
        for (int i = 0; i < 6; i++) {
            Scheduler.after(i * 10 + 1, () -> {
                if (!p.isAlive()) return;
                double a = RNG.nextDouble() * Math.PI * 2;
                double r = 3 + RNG.nextDouble() * 6;
                double x = p.getX() + Math.cos(a) * r;
                double z = p.getZ() + Math.sin(a) * r;
                double y = p.getY();
                bolt(sl, x, y, z);
                AABB area = new AABB(x - 3, y - 2, z - 3, x + 3, y + 3, z + 3);
                for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, area, e -> e != p && e.isAlive())) {
                    hit(sl, p, t, d);
                }
            });
        }
        return true;
    }

    /** 7 ฟ้าผ่าเป้าหมาย: ฟ้าผ่าตัวที่เล็งอยู่ ดาเมจ x3 */
    private static boolean s7(ServerLevel sl, ServerPlayer p) {
        Vec3 dir = p.getLookAngle();
        Vec3 eye = p.getEyePosition();
        double len = 32;
        AABB box = p.getBoundingBox().expandTowards(dir.x * len, dir.y * len, dir.z * len).inflate(2.0);
        LivingEntity best = null;
        double bestAlong = Double.MAX_VALUE;
        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, box, e -> e != p && e.isAlive())) {
            Vec3 rel = t.getEyePosition().subtract(eye);
            double along = rel.dot(dir);
            if (along < 0 || along > len) continue;
            if (rel.subtract(dir.x * along, dir.y * along, dir.z * along).length() > 1.8) continue;
            if (along < bestAlong) {
                bestAlong = along;
                best = t;
            }
        }
        if (best == null) {
            Soul.msg(p, "ไม่มีเป้าหมายในแนวสายตา", true);
            return false;
        }
        bolt(sl, best.getX(), best.getY(), best.getZ());
        bolt(sl, best.getX(), best.getY(), best.getZ());
        hit(sl, p, best, dmg(p, 3.0));
        sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, best.getX(), best.getY() + 1, best.getZ(), 60, 0.5, 1, 0.5, 0.3);
        return true;
    }

    /** 8 วงคลื่นสายฟ้า: วงคลื่นขยายออกจากตัว รัศมี 12 บล็อก */
    private static boolean s8(ServerLevel sl, ServerPlayer p) {
        final double cx = p.getX(), cy = p.getY() + 0.1, cz = p.getZ();
        final Set<UUID> done = new HashSet<>();
        final float d = dmg(p, 1.5);
        for (int t = 1; t <= 10; t++) {
            final int step = t;
            Scheduler.after(step * 2, () -> {
                double r = 1.5 + step * 1.15;
                ring(sl, cx, cy, cz, r, GOLD, Math.max(24, (int) (r * 8)));
                AABB area = new AABB(cx - r - 1.5, cy - 2, cz - r - 1.5, cx + r + 1.5, cy + 4, cz + r + 1.5);
                for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, area, x -> x != p && x.isAlive())) {
                    double dist = Math.hypot(e.getX() - cx, e.getZ() - cz);
                    if (Math.abs(dist - r) <= 1.4 && done.add(e.getUUID())) {
                        hit(sl, p, e, d);
                    }
                }
            });
        }
        return true;
    }

    /** 9 เฮ่าเทียนทลายฟ้า: รวมพลัง 1 วินาที แล้วฟ้าผ่า 10 ครั้ง ดาเมจ x4 ในรัศมี 12 บล็อก */
    private static boolean s9(ServerLevel sl, ServerPlayer p) {
        final float d = dmg(p, 4.0);
        for (int k = 0; k < 4; k++) {
            final int step = k;
            Scheduler.after(step * 5 + 1, () -> {
                if (p.isAlive()) ring(sl, p.getX(), p.getY() + 0.1, p.getZ(), 6 - step * 1.5, PURPLE, 32);
            });
        }
        Scheduler.after(20, () -> {
            if (!p.isAlive()) return;
            for (int i = 0; i < 10; i++) {
                double a = RNG.nextDouble() * Math.PI * 2;
                double r = 3 + RNG.nextDouble() * 9;
                bolt(sl, p.getX() + Math.cos(a) * r, p.getY(), p.getZ() + Math.sin(a) * r);
            }
            for (LivingEntity t : around(sl, p, 12)) {
                hit(sl, p, t, d);
                shove(t, p, 1.2);
            }
            for (int k = 1; k <= 6; k++) {
                ring(sl, p.getX(), p.getY() + 0.1, p.getZ(), k * 2, GOLD, 16 + k * 8);
            }
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 1, p.getZ(), 150, 5, 1, 5, 0.4);
        });
        return true;
    }
}
