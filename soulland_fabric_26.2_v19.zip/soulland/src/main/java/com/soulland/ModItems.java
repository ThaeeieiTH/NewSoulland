package com.soulland;

import com.soulland.item.SoulCrystalItem;
import com.soulland.item.SoulRingItem;
import net.minecraft.core.Registry;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

import java.util.function.Function;

public final class ModItems {
    /** ค้อนเฮ่าเทียน: ได้เมื่อเปิดวิญญาณยุทธ์ (G) หายเมื่อเก็บวิญญาณ */
    public static final Item HAOTIAN_HAMMER = register("haotian_hammer", Item::new, new Item.Properties().stacksTo(1));
    /** เคียวศักดิ์สิทธิ์ / ดาบ+โล่อัศวินศักดิ์สิทธิ์ */
    public static final Item HOLY_SCYTHE = register("holy_scythe", Item::new, new Item.Properties().stacksTo(1));
    public static final Item SOUL_CRYSTAL = register("soul_crystal", SoulCrystalItem::new, new Item.Properties().stacksTo(64));

    public static final Item[] RINGS = new Item[6];
    public static final String[] RING_IDS = {"ring_ten", "ring_hundred", "ring_thousand", "ring_tenthousand", "ring_hundredthousand", "ring_million"};

    static {
        for (int i = 0; i < RINGS.length; i++) {
            final int color = i;
            RINGS[i] = register(RING_IDS[i], props -> new SoulRingItem(props, color), new Item.Properties().stacksTo(64));
        }
    }

    private static <T extends Item> T register(String name, Function<Item.Properties, T> factory, Item.Properties props) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(SoulLand.MOD_ID, name));
        T item = factory.apply(props.setId(key));
        Registry.register(BuiltInRegistries.ITEM, key, item);
        return item;
    }

    public static void init() {
        ResourceKey<CreativeModeTab> key = ResourceKey.create(Registries.CREATIVE_MODE_TAB,
                Identifier.fromNamespaceAndPath(SoulLand.MOD_ID, "main"));
        CreativeModeTab tab = CreativeModeTab.builder()
                .title(Component.translatable("itemGroup.soulland"))
                .icon(() -> new ItemStack(HAOTIAN_HAMMER))
                .displayItems((params, output) -> {
                    output.accept(HAOTIAN_HAMMER);
                    output.accept(HOLY_SCYTHE);
                    output.accept(SOUL_CRYSTAL);
                    for (Item ring : RINGS) output.accept(ring);
                })
                .build();
        Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, key, tab);
    }
}
