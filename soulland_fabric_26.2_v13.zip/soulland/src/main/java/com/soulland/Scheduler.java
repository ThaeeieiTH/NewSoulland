package com.soulland;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** ตั้งเวลาให้ทำงานอีก N tick (ใช้กับทักษะที่ต่อเนื่อง) */
public final class Scheduler {
    private static final class Task {
        int left;
        final Runnable run;

        Task(int left, Runnable run) {
            this.left = left;
            this.run = run;
        }
    }

    private static final List<Task> TASKS = new ArrayList<>();

    private Scheduler() {}

    public static void after(int ticks, Runnable run) {
        TASKS.add(new Task(Math.max(1, ticks), run));
    }

    public static void tick() {
        if (TASKS.isEmpty()) return;
        List<Task> due = new ArrayList<>();
        Iterator<Task> it = TASKS.iterator();
        while (it.hasNext()) {
            Task t = it.next();
            t.left--;
            if (t.left <= 0) {
                due.add(t);
                it.remove();
            }
        }
        for (Task t : due) {
            try {
                t.run.run();
            } catch (RuntimeException ignored) {
                // กันเกมล่มถ้าผู้เล่นออกจากโลกระหว่างทักษะ
            }
        }
    }

    public static void clear() {
        TASKS.clear();
    }
}
