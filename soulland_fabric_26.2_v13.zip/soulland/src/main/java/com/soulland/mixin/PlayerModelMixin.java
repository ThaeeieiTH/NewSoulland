package com.soulland.mixin;

import com.soulland.client.PlayerPoses;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** ฉีดท่าทางผู้เล่น (เดิน วิ่ง หมัด อาวุธ) ต่อท้าย setupAnim ของโมเดลผู้เล่น */
@Mixin(PlayerModel.class)
public abstract class PlayerModelMixin {
    @SuppressWarnings({"rawtypes", "unchecked"})
    @Inject(method = "setupAnim(Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;)V",
            at = @At("TAIL"))
    private void soulland$animate(AvatarRenderState state, CallbackInfo ci) {
        Model model = (Model) (Object) this;
        PlayerPoses.apply(model.root(), state.id, state.walkAnimationPos, state.walkAnimationSpeed, state.attackTime);
    }
}
