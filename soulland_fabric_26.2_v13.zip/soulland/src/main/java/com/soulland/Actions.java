package com.soulland;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

import java.util.HashMap;
import java.util.Random;
import java.util.Map;
import java.util.UUID;

/** จัดการปุ่มที่ผู้เล่นกด (ส่งมาจากไคลเอนต์) */
public final class Actions {
    public static final int AWAKEN = 0;       // M
    public static final int REROLL = 1;       // N
    public static final int TOGGLE_SOUL = 2;  // G
    public static final int TOGGLE_RINGS = 3; // H
    public static final int NEXT_SKILL = 4;   // V
    public static final int USE_SKILL = 5;    // R

    private static final Map<UUID, Long> REROLL_CONFIRM = new HashMap<>();
    private static final Random RNG = new Random();

    private Actions() {}

    public static void clearAll() {
        REROLL_CONFIRM.clear();
    }

    public static void handle(ServerPlayer p, int action) {
        switch (action) {
            case AWAKEN -> awaken(p);
            case REROLL -> reroll(p);
            case TOGGLE_SOUL -> toggleSoul(p);
            case TOGGLE_RINGS -> toggleRings(p);
            case NEXT_SKILL -> nextSkill(p);
            case USE_SKILL -> useSkill(p);
            default -> { }
        }
    }

    private static void awaken(ServerPlayer p) {
        if (!Soul.soul(p).isEmpty()) {
            Soul.msg(p, "ปลุกวิญญาณยุทธ์แล้ว (กด N เพื่อรีวิญญาณยุทธ์)", true);
            return;
        }
        int startLevel = 1 + RNG.nextInt(10); // สุ่มเลเวลตอนปลุก 1-10
        p.setAttached(ModAttachments.SOUL, Soul.HAOTIAN);
        p.setAttached(ModAttachments.SKILL, 0);
        p.setAttached(ModAttachments.SOUL_OPEN, 0);
        p.setAttached(ModAttachments.LEVEL, startLevel);
        p.setAttached(ModAttachments.EXP, 0);
        Soul.setPower(p, Soul.maxPower(p));
        if (p.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.ENCHANT, p.getX(), p.getY() + 1.0, p.getZ(), 80, 0.6, 0.8, 0.6, 0.6);
        }
        Soul.msg(p, "ปลุกวิญญาณยุทธ์สำเร็จ: " + Soul.soulName(Soul.HAOTIAN) + " เลเวลเริ่มต้น Lv." + startLevel + " (กด G เพื่อเปิด)", false);
    }

    private static void reroll(ServerPlayer p) {
        long now = System.currentTimeMillis();
        Long first = REROLL_CONFIRM.get(p.getUUID());
        if (first == null || now - first > 5000) {
            REROLL_CONFIRM.put(p.getUUID(), now);
            Soul.msg(p, "กด N อีกครั้งภายใน 5 วินาทีเพื่อยืนยัน: รีวิญญาณยุทธ์จะทำให้ตาย และรีวิญญาณยุทธ์ เลเวล วงแหวนทั้งหมด", false);
            return;
        }
        REROLL_CONFIRM.remove(p.getUUID());
        if (!(p.level() instanceof ServerLevel sl)) return;

        Skills.clear(p);
        removeHammer(p);
        Soul.resetAll(p);
        Soul.msg(p, "รีวิญญาณยุทธ์แล้ว เกิดใหม่แล้วกด M เพื่อปลุกวิญญาณยุทธ์อีกครั้ง", false);
        p.hurtServer(sl, sl.damageSources().genericKill(), Float.MAX_VALUE);
    }

    private static void toggleSoul(ServerPlayer p) {
        if (Soul.soul(p).isEmpty()) {
            Soul.msg(p, "ยังไม่ได้ปลุกวิญญาณยุทธ์ (กด M)", true);
            return;
        }
        if (Soul.soulOpen(p)) {
            p.setAttached(ModAttachments.SOUL_OPEN, 0);
            removeHammer(p);
            Soul.msg(p, "เก็บวิญญาณยุทธ์", true);
        } else {
            p.setAttached(ModAttachments.SOUL_OPEN, 1);
            giveHammer(p);
            if (p.level() instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 1.0, p.getZ(), 40, 0.5, 0.8, 0.5, 0.3);
            }
            Soul.msg(p, "เปิดวิญญาณยุทธ์: " + Soul.soulName(Soul.soul(p)), true);
        }
    }

    private static void toggleRings(ServerPlayer p) {
        if (Soul.ringsOpen(p)) {
            p.setAttached(ModAttachments.RINGS_OPEN, 0);
            Soul.msg(p, "ปิดวงแหวน", true);
            return;
        }
        if (Soul.rings(p).isEmpty()) {
            Soul.msg(p, "ยังไม่มีวงแหวนวิญญาณ", true);
            return;
        }
        p.setAttached(ModAttachments.RINGS_OPEN, 1);
        Soul.msg(p, "เปิดวงแหวน", true);
    }

    private static void nextSkill(ServerPlayer p) {
        if (Soul.soul(p).isEmpty()) {
            Soul.msg(p, "ยังไม่ได้ปลุกวิญญาณยุทธ์ (กด M)", true);
            return;
        }
        int s = (Soul.skill(p) + 1) % Skills.NAMES.length;
        p.setAttached(ModAttachments.SKILL, s);
        String lock = Skills.unlocked(p, s) ? "" : " [ล็อก: ต้องมีวงแหวน " + (s + 1) + " วง]";
        Soul.msg(p, "ทักษะ " + (s + 1) + ": " + Skills.NAMES[s] + " (พลัง " + Skills.COST[s] + ")" + lock, true);
    }

    private static void useSkill(ServerPlayer p) {
        if (Soul.soul(p).isEmpty()) {
            Soul.msg(p, "ยังไม่ได้ปลุกวิญญาณยุทธ์ (กด M)", true);
            return;
        }
        if (!Soul.soulOpen(p)) {
            Soul.msg(p, "เปิดวิญญาณยุทธ์ก่อน (กด G)", true);
            return;
        }
        if (!p.getMainHandItem().is(ModItems.HAOTIAN_HAMMER) && !p.getOffhandItem().is(ModItems.HAOTIAN_HAMMER)) {
            Soul.msg(p, "ต้องถือค้อนเฮ่าเทียนในมือถึงจะใช้สกิลได้", true);
            return;
        }
        Skills.use(p);
    }

    private static boolean hasHammer(ServerPlayer p) {
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            if (inv.getItem(i).is(ModItems.HAOTIAN_HAMMER)) return true;
        }
        return false;
    }

    private static void giveHammer(ServerPlayer p) {
        if (hasHammer(p)) return;
        ItemStack s = new ItemStack(ModItems.HAOTIAN_HAMMER);
        if (!p.getInventory().add(s)) {
            p.drop(s, false);
        }
    }

    private static void removeHammer(ServerPlayer p) {
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            if (inv.getItem(i).is(ModItems.HAOTIAN_HAMMER)) {
                inv.setItem(i, ItemStack.EMPTY);
            }
        }
    }
}
