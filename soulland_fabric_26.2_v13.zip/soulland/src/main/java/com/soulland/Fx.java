package com.soulland;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

import java.util.Random;

/** เอฟเฟกต์พาร์ติเคิลที่ประกอบเอง: สายฟ้าซิกแซก วงเวท เฮลิกซ์ คลื่นกระแทก เสาแสง */
public final class Fx {
    public static final DustParticleOptions BLUE = new DustParticleOptions(0x2EE6FF, 1.0f);
    public static final DustParticleOptions CYAN = new DustParticleOptions(0xC8F8FF, 0.8f);
    public static final DustParticleOptions PURPLE = new DustParticleOptions(0xAA00FF, 1.1f);
    public static final DustParticleOptions GOLD = new DustParticleOptions(0xFFC800, 1.1f);

    private static final Random RNG = new Random();

    private Fx() {}

    private static void dot(ServerLevel sl, ParticleOptions o, double x, double y, double z) {
        sl.sendParticles(o, x, y, z, 1, 0, 0, 0, 0);
    }

    public static void sound(ServerLevel sl, double x, double y, double z, float vol, float pitch) {
        sl.playSound(null, x, y, z, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, vol, pitch);
    }

    public static void line(ServerLevel sl, ParticleOptions o, double x0, double y0, double z0,
                            double x1, double y1, double z1, double step) {
        double len = Math.sqrt((x1 - x0) * (x1 - x0) + (y1 - y0) * (y1 - y0) + (z1 - z0) * (z1 - z0));
        int n = Math.max(1, (int) Math.ceil(len / step));
        for (int i = 0; i <= n; i++) {
            double t = (double) i / n;
            dot(sl, o, x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, z0 + (z1 - z0) * t);
        }
    }

    public static void ring(ServerLevel sl, ParticleOptions o, double cx, double cy, double cz, double r) {
        int n = Math.max(16, (int) (2 * Math.PI * r / 0.25));
        for (int i = 0; i < n; i++) {
            double a = Math.PI * 2 * i / n;
            dot(sl, o, cx + Math.cos(a) * r, cy, cz + Math.sin(a) * r);
        }
    }

    /** ดาว/รูปหลายเหลี่ยมประสานกัน (n=6 = ดาวหกแฉก) */
    public static void star(ServerLevel sl, ParticleOptions o, double cx, double cy, double cz, double r, int n, double rot) {
        for (int i = 0; i < n; i++) {
            double a0 = rot + Math.PI * 2 * i / n;
            double a1 = rot + Math.PI * 2 * (i + 2) / n;
            line(sl, o, cx + Math.cos(a0) * r, cy, cz + Math.sin(a0) * r,
                    cx + Math.cos(a1) * r, cy, cz + Math.sin(a1) * r, 0.3);
        }
    }

    /** วงเวทบนพื้น: วงคู่ + ดาวหกแฉก + ขีดรอบวง */
    public static void rune(ServerLevel sl, double cx, double cy, double cz, double r,
                            ParticleOptions main, ParticleOptions accent) {
        ring(sl, main, cx, cy, cz, r);
        ring(sl, accent, cx, cy, cz, r * 0.86);
        star(sl, main, cx, cy, cz, r * 0.86, 6, RNG.nextDouble());
        int ticks = Math.max(12, (int) (r * 6));
        for (int i = 0; i < ticks; i++) {
            double a = Math.PI * 2 * i / ticks;
            line(sl, accent, cx + Math.cos(a) * r * 0.92, cy, cz + Math.sin(a) * r * 0.92,
                    cx + Math.cos(a) * r * 1.06, cy, cz + Math.sin(a) * r * 1.06, 0.2);
        }
        dot(sl, ParticleTypes.END_ROD, cx, cy + 0.1, cz);
    }

    /** เกลียวพันขึ้นข้างบน */
    public static void helix(ServerLevel sl, ParticleOptions o, double cx, double cy, double cz,
                             double r, double h, double turns, double phase) {
        int n = (int) (h * 8);
        for (int i = 0; i <= n; i++) {
            double t = (double) i / n;
            double a = phase + t * turns * Math.PI * 2;
            dot(sl, o, cx + Math.cos(a) * r, cy + t * h, cz + Math.sin(a) * r);
            dot(sl, o, cx + Math.cos(a + Math.PI) * r, cy + t * h, cz + Math.sin(a + Math.PI) * r);
        }
    }

    /** คลื่นกระแทก: ประกายพุ่งออกจากวงรัศมี r */
    public static void shock(ServerLevel sl, double cx, double cy, double cz, double r) {
        int n = Math.max(16, (int) (r * 10));
        for (int i = 0; i < n; i++) {
            double a = Math.PI * 2 * i / n;
            double dx = Math.cos(a), dz = Math.sin(a);
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, cx + dx * r, cy + 0.1, cz + dz * r, 0, dx, 0.05, dz, 0.6);
        }
    }

    /** เสาแสงตั้งขึ้นฟ้า */
    public static void pillar(ServerLevel sl, double x, double y, double z, double h) {
        for (double dy = 0; dy <= h; dy += 0.5) {
            sl.sendParticles(ParticleTypes.END_ROD, x, y + dy, z, 2, 0.25, 0.1, 0.25, 0.01);
        }
        helix(sl, CYAN, x, y, z, 0.7, Math.min(h, 12), 4, RNG.nextDouble() * 6);
    }

    /** จุดกระทบ: ประกาย + วงแตก + เสียงฟ้าร้อง */
    public static void impact(ServerLevel sl, double x, double y, double z) {
        sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, y + 0.5, z, 30, 0.4, 0.3, 0.4, 0.25);
        sl.sendParticles(ParticleTypes.END_ROD, x, y + 0.4, z, 12, 0.3, 0.3, 0.3, 0.08);
        ring(sl, BLUE, x, y + 0.1, z, 1.1);
        shock(sl, x, y, z, 0.6);
        sound(sl, x, y, z, 0.6f, 1.0f + RNG.nextFloat() * 0.3f);
    }

    /** สายฟ้าซิกแซกจากฟ้าลงพื้น มีกิ่งแขนง */
    public static void bolt(ServerLevel sl, double x, double y, double z, double height) {
        int segs = Math.max(4, (int) (height / 1.5));
        double px = x + (RNG.nextDouble() - 0.5) * 2.0;
        double pz = z + (RNG.nextDouble() - 0.5) * 2.0;
        double py = y + height;
        for (int i = 1; i <= segs; i++) {
            double t = (double) i / segs;
            double nx = x + (RNG.nextDouble() - 0.5) * 1.8 * (1 - t);
            double nz = z + (RNG.nextDouble() - 0.5) * 1.8 * (1 - t);
            double ny = y + height * (1 - t);
            if (i == segs) {
                nx = x;
                nz = z;
                ny = y;
            }
            line(sl, ParticleTypes.END_ROD, px, py, pz, nx, ny, nz, 0.35);
            line(sl, BLUE, px, py, pz, nx, ny, nz, 0.45);
            if (i < segs && RNG.nextInt(3) == 0) {
                double bx = nx + (RNG.nextDouble() - 0.5) * 3.0;
                double bz = nz + (RNG.nextDouble() - 0.5) * 3.0;
                line(sl, CYAN, nx, ny, nz, bx, ny - 1.5, bz, 0.35);
            }
            px = nx;
            py = ny;
            pz = nz;
        }
        impact(sl, x, y, z);
    }

    /** ลำแสงเส้นตรงพร้อมเกลียวสองเส้น */
    public static void beam(ServerLevel sl, double sx, double sy, double sz,
                            double dx, double dy, double dz, double len) {
        // เวกเตอร์ตั้งฉาก
        double ux = -dz, uz = dx;
        double ul = Math.max(1e-6, Math.sqrt(ux * ux + uz * uz));
        ux /= ul;
        uz /= ul;
        double vx = dy * uz, vy = dz * ux - dx * uz, vz = -dy * ux;
        for (double s = 0.5; s <= len; s += 0.35) {
            double bx = sx + dx * s, by = sy + dy * s, bz = sz + dz * s;
            dot(sl, ParticleTypes.END_ROD, bx, by, bz);
            double a = s * 2.2;
            double c = Math.cos(a) * 0.55, si = Math.sin(a) * 0.55;
            dot(sl, BLUE, bx + (ux * c + vx * si), by + (vy * si), bz + (uz * c + vz * si));
            dot(sl, CYAN, bx - (ux * c + vx * si), by - (vy * si), bz - (uz * c + vz * si));
        }
    }
    /** ระเบิดประกายเป็นทรงกลม (พุ่งออกรอบทิศ) */
    public static void sphere(ServerLevel sl, ParticleOptions o, double cx, double cy, double cz, double speed, int n) {
        for (int i = 0; i < n; i++) {
            double y = 1 - 2.0 * (i + 0.5) / n;
            double r = Math.sqrt(Math.max(0, 1 - y * y));
            double phi = i * 2.399963;
            sl.sendParticles(o, cx, cy, cz, 0, Math.cos(phi) * r, y, Math.sin(phi) * r, speed);
        }
    }

    /** เปลือกทรงกลมนิ่ง (โล่) */
    public static void shell(ServerLevel sl, ParticleOptions o, double cx, double cy, double cz, double rad, int n) {
        for (int i = 0; i < n; i++) {
            double y = 1 - 2.0 * (i + 0.5) / n;
            double r = Math.sqrt(Math.max(0, 1 - y * y));
            double phi = i * 2.399963;
            dot(sl, o, cx + Math.cos(phi) * r * rad, cy + y * rad, cz + Math.sin(phi) * r * rad);
        }
    }

    /** สายฟ้าแผ่ไปตามพื้นเป็นรัศมี (เหมือนใยแมงมุม) */
    public static void groundBolts(ServerLevel sl, double cx, double cy, double cz, double len, int rays) {
        double base = RNG.nextDouble() * Math.PI * 2;
        for (int i = 0; i < rays; i++) {
            double a = base + Math.PI * 2 * i / rays;
            double dx = Math.cos(a), dz = Math.sin(a);
            double px = cx, pz = cz;
            for (double s = 1.0; s <= len; s += 1.0) {
                double j = (RNG.nextDouble() - 0.5) * 0.9;
                double nx = cx + dx * s - dz * j;
                double nz = cz + dz * s + dx * j;
                line(sl, ParticleTypes.END_ROD, px, cy + 0.15, pz, nx, cy + 0.15, nz, 0.35);
                line(sl, BLUE, px, cy + 0.15, pz, nx, cy + 0.15, nz, 0.45);
                px = nx;
                pz = nz;
            }
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, px, cy + 0.3, pz, 6, 0.2, 0.2, 0.2, 0.1);
        }
    }

    /** มงกุฎหนามแสงพุ่งขึ้นจากวง */
    public static void crown(ServerLevel sl, ParticleOptions o, double cx, double cy, double cz,
                             double r, int spikes, double h) {
        for (int i = 0; i < spikes; i++) {
            double a = Math.PI * 2 * i / spikes;
            double bx = cx + Math.cos(a) * r, bz = cz + Math.sin(a) * r;
            double top = h * (0.6 + RNG.nextDouble() * 0.4);
            line(sl, o, bx, cy, bz, bx, cy + top, bz, 0.3);
        }
    }

    /** เกลียวหดเข้า/ขยายออกขณะพันขึ้น (รวมพลัง) */
    public static void vortex(ServerLevel sl, ParticleOptions o, double cx, double cy, double cz,
                              double r0, double r1, double h, double turns, double phase) {
        int n = (int) (h * 10);
        for (int i = 0; i <= n; i++) {
            double t = (double) i / n;
            double r = r0 + (r1 - r0) * t;
            double a = phase + t * turns * Math.PI * 2;
            dot(sl, o, cx + Math.cos(a) * r, cy + t * h, cz + Math.sin(a) * r);
            dot(sl, o, cx + Math.cos(a + Math.PI) * r, cy + t * h, cz + Math.sin(a + Math.PI) * r);
        }
    }

    /** วงแหวนลอยขึ้นฟ้าทีละวง */
    public static void risingRings(ServerLevel sl, ParticleOptions o, double cx, double cy, double cz,
                                   double r, int count) {
        for (int k = 0; k < count; k++) {
            final double yy = cy + 0.2 + k * 0.55;
            final double rr = r * (1.0 - k * 0.07);
            Scheduler.after(k * 3 + 1, () -> ring(sl, o, cx, yy, cz, rr));
        }
    }
}
