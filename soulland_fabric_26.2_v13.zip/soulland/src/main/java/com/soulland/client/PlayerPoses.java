package com.soulland.client;

import com.soulland.ModItems;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

/**
 * ท่าทางผู้เล่นแบบสร้างเอง (มองเห็นในมุมมองบุคคลที่สาม กด F5):
 * เดิน = เดินร่อนนุ่มๆ ตัวโยกเบาๆ / วิ่ง = โน้มตัวไปข้างหน้า แกว่งแขนแรง
 * หมัด = ตั้งการ์ดแล้วต่อยตรง บิดลำตัว / อาวุธ (ค้อนเฮ่าเทียน) = ยกสองมือเหนือหัวแล้วฟาดลง
 */
public final class PlayerPoses {
    private static final float PI = (float) Math.PI;

    private PlayerPoses() {}

    private static ModelPart part(ModelPart root, String name) {
        return root.hasChild(name) ? root.getChild(name) : null;
    }

    public static void apply(ModelPart root, int entityId, float walkPos, float walkSpeed, float attack) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        Entity e = mc.level.getEntity(entityId);
        if (!(e instanceof Player pl)) return;

        ModelPart head = part(root, "head");
        ModelPart body = part(root, "body");
        ModelPart ra = part(root, "right_arm");
        ModelPart la = part(root, "left_arm");
        ModelPart rl = part(root, "right_leg");
        ModelPart ll = part(root, "left_leg");
        if (head == null || body == null || ra == null || la == null || rl == null || ll == null) return;

        boolean hammer = pl.getMainHandItem().is(ModItems.HAOTIAN_HAMMER);
        float speed = Mth.clamp(walkSpeed, 0f, 1f);
        boolean sprint = pl.isSprinting() && speed > 0.2f;
        float p = walkPos * 0.6662f;

        if (sprint) {
            // ---- วิ่ง ----
            body.xRot = 0.30f * speed;
            body.yRot = Mth.sin(p) * 0.18f * speed;
            head.xRot -= 0.25f * speed;
            head.yRot -= Mth.sin(p) * 0.12f * speed;
            head.y += 0.8f * speed;
            ra.y += 0.7f * speed;
            la.y += 0.7f * speed;
            ra.xRot = Mth.cos(p + PI) * 1.5f * speed - 0.6f * speed;
            la.xRot = Mth.cos(p) * 1.5f * speed - 0.6f * speed;
            ra.zRot = 0.10f;
            la.zRot = -0.10f;
            rl.xRot = Mth.cos(p) * 1.6f * speed;
            ll.xRot = Mth.cos(p + PI) * 1.6f * speed;
        } else if (speed > 0.02f) {
            // ---- เดิน (ร่อนนุ่ม ตัวโยกเบาๆ) ----
            float bob = -Math.abs(Mth.sin(p)) * 0.5f * speed;
            body.yRot = Mth.sin(p) * 0.10f * speed;
            head.yRot -= Mth.sin(p) * 0.07f * speed;
            head.y += bob;
            body.y += bob;
            ra.y += bob;
            la.y += bob;
            ra.xRot = Mth.cos(p + PI) * 0.8f * speed - 0.1f * speed;
            la.xRot = Mth.cos(p) * 0.8f * speed - 0.1f * speed;
            ra.zRot = 0.06f + Mth.sin(p) * 0.05f * speed;
            la.zRot = -0.06f - Mth.sin(p) * 0.05f * speed;
            rl.xRot = Mth.cos(p) * 1.2f * speed;
            ll.xRot = Mth.cos(p + PI) * 1.2f * speed;
            rl.zRot = 0.03f;
            ll.zRot = -0.03f;
        }

        if (attack > 0f) {
            if (hammer) {
                weaponSwing(attack, body, head, ra, la, rl, ll);
            } else {
                punch(attack, body, head, ra, la, rl, ll);
            }
        }

        // ชั้นเสริม (แขนเสื้อ กางเกง เสื้อ หมวก) ที่แยกจากแขนขา ให้ตามท่าเดียวกัน
        sync(root, "left_sleeve", la);
        sync(root, "right_sleeve", ra);
        sync(root, "left_pants", ll);
        sync(root, "right_pants", rl);
        sync(root, "jacket", body);
        sync(root, "hat", head);
    }

    private static void sync(ModelPart root, String overlay, ModelPart base) {
        if (root.hasChild(overlay)) {
            root.getChild(overlay).copyFrom(base);
        }
    }

    /** หมัด: ตั้งการ์ด แล้วต่อยตรงด้วยแขนขวา บิดลำตัว ก้าวขา */
    private static void punch(float t, ModelPart body, ModelPart head, ModelPart ra, ModelPart la,
                              ModelPart rl, ModelPart ll) {
        float ext = Mth.sin(Mth.clamp(t, 0f, 1f) * PI);
        ra.xRot = Mth.lerp(ext, -0.9f, -1.55f);
        ra.yRot = Mth.lerp(ext, -0.2f, -0.1f);
        ra.zRot = 0.05f;
        la.xRot = -1.0f;
        la.yRot = 0.55f;
        la.zRot = -0.12f;
        body.yRot = 0.4f * ext;
        body.xRot = Math.max(body.xRot, 0.15f * ext);
        head.yRot -= 0.3f * ext;
        rl.xRot = Mth.lerp(ext, 0.1f, -0.35f);
        ll.xRot = Mth.lerp(ext, -0.1f, 0.35f);
    }

    /** ค้อน: ยกสองมือเหนือหัว (ง้าง) แล้วฟาดลงแรงๆ แล้วคืนท่า */
    private static void weaponSwing(float t, ModelPart body, ModelPart head, ModelPart ra, ModelPart la,
                                    ModelPart rl, ModelPart ll) {
        float ang;
        float lean;
        float stance;
        if (t < 0.35f) {                       // ง้าง
            float k = smooth(t / 0.35f);
            ang = Mth.lerp(k, -0.4f, -3.0f);
            lean = Mth.lerp(k, 0f, -0.18f);
            stance = k * 0.3f;
        } else if (t < 0.6f) {                 // ฟาดลง
            float k = (t - 0.35f) / 0.25f;
            k = k * k;
            ang = Mth.lerp(k, -3.0f, -0.35f);
            lean = Mth.lerp(k, -0.18f, 0.45f);
            stance = Mth.lerp(k, 0.3f, 0.6f);
        } else {                               // คืนท่า
            float k = smooth((t - 0.6f) / 0.4f);
            ang = Mth.lerp(k, -0.35f, -0.4f);
            lean = Mth.lerp(k, 0.45f, 0f);
            stance = Mth.lerp(k, 0.6f, 0f);
        }
        ra.xRot = ang;
        la.xRot = ang;
        ra.yRot = -0.15f;
        la.yRot = 0.35f;
        ra.zRot = 0.1f;
        la.zRot = -0.1f;
        body.xRot = lean;
        body.yRot = 0.0f;
        head.xRot -= lean * 0.6f;
        rl.xRot = -stance;
        ll.xRot = stance * 0.7f;
    }

    private static float smooth(float t) {
        t = Mth.clamp(t, 0f, 1f);
        return t * t * (3 - 2 * t);
    }
}
