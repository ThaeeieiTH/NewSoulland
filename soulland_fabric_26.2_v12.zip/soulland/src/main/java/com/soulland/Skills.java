package com.soulland;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/** 9 ทักษะของค้อนเฮ่าเทียน — ต้องมีวงแหวน: ทักษะที่ k ใช้ได้เมื่อมีวงแหวนครบ k วง */
public final class Skills {
    public static final String[] NAMES = {
            "สายฟ้าฟาดฟ้า", "ค้อนสะท้านพื้น", "พุ่งสายฟ้า", "เกราะเฮ่าเทียน", "คลื่นฟ้าตรง",
            "พายุสายฟ้า", "ฟ้าผ่าเป้าหมาย", "วงคลื่นสายฟ้า", "เฮ่าเทียนทลายฟ้า"
    };
    public static final int[] COST = {20, 30, 25, 40, 35, 60, 45, 70, 120};
    public static final int[] COOLDOWN_TICKS = {60, 100, 80, 300, 120, 300, 160, 400, 800};

    private static final DustParticleOptions BLUE = new DustParticleOptions(0x2EE6FF, 1.2f);
    private static final DustParticleOptions GOLD = new DustParticleOptions(0xFFC800, 1.3f);
    private static final DustParticleOptions PURPLE = new DustParticleOptions(0xAA00FF, 1.4f);

    private static final Map<UUID, long[]> COOLDOWNS = new HashMap<>();
    private static final Map<UUID, Long> INVULN_UNTIL = new HashMap<>();
    private static final Random RNG = new Random();

    private Skills() {}

    /** ทักษะลำดับ i (เริ่มที่ 0) ต้องมีวงแหวนอย่างน้อย i+1 วง (ไม่มีวงแหวน = ใช้สกิลไม่ได้) */
    public static boolean unlocked(Player p, int i) {
        return Soul.rings(p).length() >= i + 1;
    }

    public static boolean isInvulnerable(ServerPlayer p, long nowTick) {
        Long until = INVULN_UNTIL.get(p.getUUID());
        return until != null && nowTick < until;
    }

    public static void clear(ServerPlayer p) {
        COOLDOWNS.remove(p.getUUID());
        INVULN_UNTIL.remove(p.getUUID());
    }

    public static void clearAll() {
        COOLDOWNS.clear();
        INVULN_UNTIL.clear();
    }

    public static void use(ServerPlayer p) {
        if (!(p.level() instanceof ServerLevel sl)) return;
        MinecraftServer server = sl.getServer();
        int i = Soul.skill(p);
        if (i < 0 || i >= NAMES.length) i = 0;

        if (!unlocked(p, i)) {
            Soul.msg(p, "ใช้ทักษะ " + (i + 1) + " ไม่ได้ ต้องมีวงแหวนครบ " + (i + 1) + " วง (ตอนนี้มี " + Soul.rings(p).length() + ")", true);
            return;
        }
        long now = server.getTickCount();
        long[] cd = COOLDOWNS.computeIfAbsent(p.getUUID(), k -> new long[NAMES.length]);
        if (now < cd[i]) {
            Soul.msg(p, "ทักษะยังคูลดาวน์ อีก " + ((cd[i] - now + 19) / 20) + " วินาที", true);
            return;
        }
        if (Soul.power(p) < COST[i]) {
            Soul.msg(p, "พลังวิญญาณไม่พอ (ต้องใช้ " + COST[i] + ")", true);
            return;
        }

        boolean ok = switch (i) {
            case 0 -> s1(sl, p);
            case 1 -> s2(sl, p);
            case 2 -> s3(sl, p);
            case 3 -> s4(sl, p, now);
            case 4 -> s5(sl, p);
            case 5 -> s6(sl, p);
            case 6 -> s7(sl, p);
            case 7 -> s8(sl, p);
            case 8 -> s9(sl, p);
            default -> false;
        };
        if (!ok) return;

        Soul.setPower(p, Soul.power(p) - COST[i]);
        cd[i] = now + COOLDOWN_TICKS[i];
        Soul.msg(p, "ทักษะ " + (i + 1) + ": " + NAMES[i], true);
    }

    // ---------- helpers ----------

    private static float dmg(ServerPlayer p, double mult) {
        return (float) ((8 + Soul.level(p) * 0.4 + Soul.ringBonus(p)) * mult);
    }

    private static java.util.List<LivingEntity> around(ServerLevel sl, ServerPlayer p, double r) {
        return sl.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(r), e -> e != p && e.isAlive());
    }

    private static void hit(ServerLevel sl, ServerPlayer p, LivingEntity t, float d) {
        SoulLand.SKILL_HIT = true;
        try {
            t.hurtServer(sl, sl.damageSources().playerAttack(p), d);
        } finally {
            SoulLand.SKILL_HIT = false;
        }
    }

    /** ผลักเป้าหมายให้ห่างจากผู้เล่น (แทน knockback ที่เปลี่ยนรูปแบบใน 26.2) */
    private static void shove(LivingEntity t, ServerPlayer p, double strength) {
        double dx = t.getX() - p.getX();
        double dz = t.getZ() - p.getZ();
        double len = Math.max(0.001, Math.hypot(dx, dz));
        t.push(dx / len * strength, 0.35, dz / len * strength);
    }

    // ---------- 9 ทักษะ (เอฟเฟกต์พาร์ติเคิลที่ประกอบเอง) ----------

    /** 1 สายฟ้าฟาดฟ้า: วงเวทใต้เท้า แล้วฟ้าผ่าศัตรูรอบตัว (8 ตัว) */
    private static boolean s1(ServerLevel sl, ServerPlayer p) {
        float d = dmg(p, 1.0);
        Fx.rune(sl, p.getX(), p.getY() + 0.05, p.getZ(), 2.6, Fx.BLUE, Fx.CYAN);
        Fx.helix(sl, Fx.CYAN, p.getX(), p.getY(), p.getZ(), 0.9, 2.4, 2, 0);
        int n = 0;
        for (LivingEntity t : around(sl, p, 8)) {
            if (n++ >= 8) break;
            Fx.bolt(sl, t.getX(), t.getY(), t.getZ(), 16);
            hit(sl, p, t, d);
        }
        if (n == 0) {
            for (int i = 0; i < 3; i++) {
                double a = RNG.nextDouble() * Math.PI * 2;
                Fx.bolt(sl, p.getX() + Math.cos(a) * 4, p.getY(), p.getZ() + Math.sin(a) * 4, 14);
            }
        }
        return true;
    }

    /** 2 ค้อนสะท้านพื้น: ฟาดพื้นเป็นคลื่นกระแทก 3 ระลอก ผลักศัตรูออก */
    private static boolean s2(ServerLevel sl, ServerPlayer p) {
        float d = dmg(p, 1.3);
        final double cx = p.getX(), cy = p.getY(), cz = p.getZ();
        for (LivingEntity t : around(sl, p, 6)) {
            hit(sl, p, t, d);
            shove(t, p, 0.9);
        }
        Fx.rune(sl, cx, cy + 0.05, cz, 2.2, Fx.GOLD, Fx.CYAN);
        for (int k = 0; k < 3; k++) {
            final double r = 1.2 + k * 1.6;
            Scheduler.after(1 + k * 4, () -> {
                Fx.shock(sl, cx, cy, cz, r);
                Fx.ring(sl, Fx.BLUE, cx, cy + 0.1, cz, r);
            });
        }
        sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, cx, cy + 0.3, cz, 80, 3, 0.3, 3, 0.3);
        Fx.sound(sl, cx, cy, cz, 1.0f, 0.7f);
        return true;
    }

    /** 3 พุ่งสายฟ้า: พุ่งไปข้างหน้า 8 บล็อก ทิ้งรอยสายฟ้า ศัตรูที่ขวางโดนดาเมจ */
    private static boolean s3(ServerLevel sl, ServerPlayer p) {
        Vec3 dir = Vec3.directionFromRotation(0, p.getYRot());
        AABB box = p.getBoundingBox();
        int dist = 0;
        for (int i = 1; i <= 8; i++) {
            if (!sl.noCollision(box.move(dir.x * i, 0, dir.z * i))) break;
            dist = i;
        }
        if (dist == 0) {
            Soul.msg(p, "ข้างหน้าถูกขวาง พุ่งไม่ได้", true);
            return false;
        }
        Vec3 from = p.position();
        float d = dmg(p, 1.2);
        AABB path = box.expandTowards(dir.x * dist, 0, dir.z * dist).inflate(1.5);
        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, path, e -> e != p && e.isAlive())) {
            hit(sl, p, t, d);
            Fx.impact(sl, t.getX(), t.getY(), t.getZ());
        }
        Fx.shock(sl, from.x, from.y, from.z, 1.0);
        Fx.ring(sl, Fx.CYAN, from.x, from.y + 0.1, from.z, 1.2);
        Fx.beam(sl, from.x, from.y + 1.0, from.z, dir.x, 0, dir.z, dist);
        double ex = from.x + dir.x * dist, ez = from.z + dir.z * dist;
        p.connection.teleport(ex, from.y, ez, p.getYRot(), p.getXRot());
        Fx.rune(sl, ex, from.y + 0.05, ez, 1.8, Fx.BLUE, Fx.CYAN);
        Fx.sound(sl, ex, from.y, ez, 0.8f, 1.4f);
        return true;
    }

    /** 4 เกราะเฮ่าเทียน: อมตะ 3 วินาที + เกราะดูดซับ + ออร่าเกลียวทองห่อตัว */
    private static boolean s4(ServerLevel sl, ServerPlayer p, long now) {
        INVULN_UNTIL.put(p.getUUID(), now + 60);
        p.setAbsorptionAmount(Math.max(p.getAbsorptionAmount(), 6.0f));
        Fx.rune(sl, p.getX(), p.getY() + 0.05, p.getZ(), 2.0, Fx.GOLD, Fx.CYAN);
        for (int k = 0; k < 12; k++) {
            final int step = k;
            Scheduler.after(1 + step * 5, () -> {
                if (!p.isAlive()) return;
                Fx.helix(sl, Fx.GOLD, p.getX(), p.getY(), p.getZ(), 1.0, 2.2, 1.5, step * 0.7);
                Fx.ring(sl, Fx.CYAN, p.getX(), p.getY() + 0.3 + (step % 4) * 0.55, p.getZ(), 0.9);
            });
        }
        Fx.sound(sl, p.getX(), p.getY(), p.getZ(), 0.7f, 1.6f);
        return true;
    }

    /** 5 คลื่นฟ้าตรง: ลำแสงสายฟ้าพุ่งเป็นเส้นตรง 14 บล็อก */
    private static boolean s5(ServerLevel sl, ServerPlayer p) {
        Vec3 dir = p.getLookAngle();
        Vec3 start = p.position();
        double len = 14;
        float d = dmg(p, 1.2);
        AABB box = p.getBoundingBox().expandTowards(dir.x * len, dir.y * len, dir.z * len).inflate(2.5);
        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, box, e -> e != p && e.isAlive())) {
            Vec3 rel = t.position().subtract(start);
            double along = rel.dot(dir);
            if (along < 0 || along > len) continue;
            if (rel.subtract(dir.x * along, dir.y * along, dir.z * along).length() > 2.5) continue;
            hit(sl, p, t, d);
            Fx.impact(sl, t.getX(), t.getY(), t.getZ());
        }
        Fx.beam(sl, start.x, start.y + 1.2, start.z, dir.x, dir.y, dir.z, len);
        Fx.rune(sl, start.x, start.y + 0.05, start.z, 1.6, Fx.BLUE, Fx.CYAN);
        double ex = start.x + dir.x * len, ey = start.y + 1.2 + dir.y * len, ez = start.z + dir.z * len;
        sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, ex, ey, ez, 50, 0.6, 0.6, 0.6, 0.3);
        Fx.sound(sl, start.x, start.y, start.z, 0.9f, 1.2f);
        return true;
    }

    /** 6 พายุสายฟ้า: ฟ้าผ่าสุ่มรอบตัว 6 ครั้งใน 3 วินาที พร้อมวงเวทใหญ่ */
    private static boolean s6(ServerLevel sl, ServerPlayer p) {
        float d = dmg(p, 1.0);
        Fx.rune(sl, p.getX(), p.getY() + 0.05, p.getZ(), 4.5, Fx.BLUE, Fx.PURPLE);
        for (int i = 0; i < 6; i++) {
            Scheduler.after(i * 10 + 1, () -> {
                if (!p.isAlive()) return;
                double a = RNG.nextDouble() * Math.PI * 2;
                double r = 3 + RNG.nextDouble() * 6;
                double x = p.getX() + Math.cos(a) * r;
                double z = p.getZ() + Math.sin(a) * r;
                double y = p.getY();
                Fx.bolt(sl, x, y, z, 18);
                Fx.ring(sl, Fx.BLUE, x, y + 0.1, z, 2.0);
                AABB area = new AABB(x - 3, y - 2, z - 3, x + 3, y + 3, z + 3);
                for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, area, e -> e != p && e.isAlive())) {
                    hit(sl, p, t, d);
                }
            });
        }
        return true;
    }

    /** 7 ฟ้าผ่าเป้าหมาย: เสาฟ้าผ่าใส่ตัวที่เล็งอยู่ ดาเมจ x3 */
    private static boolean s7(ServerLevel sl, ServerPlayer p) {
        Vec3 dir = p.getLookAngle();
        Vec3 eye = p.getEyePosition();
        double len = 32;
        AABB box = p.getBoundingBox().expandTowards(dir.x * len, dir.y * len, dir.z * len).inflate(2.0);
        LivingEntity best = null;
        double bestAlong = Double.MAX_VALUE;
        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, box, e -> e != p && e.isAlive())) {
            Vec3 rel = t.getEyePosition().subtract(eye);
            double along = rel.dot(dir);
            if (along < 0 || along > len) continue;
            if (rel.subtract(dir.x * along, dir.y * along, dir.z * along).length() > 1.8) continue;
            if (along < bestAlong) {
                bestAlong = along;
                best = t;
            }
        }
        if (best == null) {
            Soul.msg(p, "ไม่มีเป้าหมายในแนวสายตา", true);
            return false;
        }
        final double x = best.getX(), y = best.getY(), z = best.getZ();
        Fx.rune(sl, x, y + 0.05, z, 2.4, Fx.PURPLE, Fx.CYAN);
        Fx.bolt(sl, x, y, z, 26);
        Fx.bolt(sl, x, y, z, 26);
        Fx.bolt(sl, x, y, z, 26);
        Fx.pillar(sl, x, y, z, 10);
        Fx.shock(sl, x, y, z, 1.5);
        Scheduler.after(4, () -> Fx.shock(sl, x, y, z, 3.0));
        hit(sl, p, best, dmg(p, 3.0));
        return true;
    }

    /** 8 วงคลื่นสายฟ้า: วงคลื่นขยายออกจากตัวรัศมี 12 บล็อก มีสายฟ้าผ่าตามขอบคลื่น */
    private static boolean s8(ServerLevel sl, ServerPlayer p) {
        final double cx = p.getX(), cy = p.getY() + 0.1, cz = p.getZ();
        final Set<UUID> done = new HashSet<>();
        final float d = dmg(p, 1.5);
        Fx.rune(sl, cx, cy, cz, 3.2, Fx.GOLD, Fx.CYAN);
        for (int t = 1; t <= 10; t++) {
            final int step = t;
            Scheduler.after(step * 2, () -> {
                double r = 1.5 + step * 1.15;
                Fx.ring(sl, Fx.GOLD, cx, cy, cz, r);
                Fx.shock(sl, cx, cy, cz, r);
                if (step % 3 == 0) {
                    double a = RNG.nextDouble() * Math.PI * 2;
                    Fx.bolt(sl, cx + Math.cos(a) * r, cy, cz + Math.sin(a) * r, 10);
                }
                AABB area = new AABB(cx - r - 1.5, cy - 2, cz - r - 1.5, cx + r + 1.5, cy + 4, cz + r + 1.5);
                for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, area, x -> x != p && x.isAlive())) {
                    double dist = Math.hypot(e.getX() - cx, e.getZ() - cz);
                    if (Math.abs(dist - r) <= 1.4 && done.add(e.getUUID())) {
                        hit(sl, p, e, d);
                    }
                }
            });
        }
        Fx.sound(sl, cx, cy, cz, 1.0f, 0.9f);
        return true;
    }

    /** 9 เฮ่าเทียนทลายฟ้า: รวมพลัง 1 วินาที วงเวทหดเข้า แล้วฟ้าผ่า 12 ครั้ง เสาแสง คลื่นกระแทกซ้อน ดาเมจ x4 */
    private static boolean s9(ServerLevel sl, ServerPlayer p) {
        final float d = dmg(p, 4.0);
        final double cx = p.getX(), cy = p.getY(), cz = p.getZ();
        for (int k = 0; k < 4; k++) {
            final int step = k;
            Scheduler.after(step * 5 + 1, () -> {
                if (!p.isAlive()) return;
                double r = 7 - step * 1.4;
                Fx.rune(sl, p.getX(), p.getY() + 0.05, p.getZ(), r, Fx.PURPLE, Fx.CYAN);
                Fx.helix(sl, Fx.PURPLE, p.getX(), p.getY(), p.getZ(), r * 0.6, 3.5, 2, step);
                Fx.sound(sl, p.getX(), p.getY(), p.getZ(), 0.4f, 0.6f + step * 0.2f);
            });
        }
        Scheduler.after(20, () -> {
            if (!p.isAlive()) return;
            Fx.pillar(sl, cx, cy, cz, 14);
            for (int i = 0; i < 12; i++) {
                double a = RNG.nextDouble() * Math.PI * 2;
                double r = 2 + RNG.nextDouble() * 10;
                Fx.bolt(sl, cx + Math.cos(a) * r, cy, cz + Math.sin(a) * r, 20);
            }
            for (LivingEntity t : around(sl, p, 12)) {
                hit(sl, p, t, d);
                shove(t, p, 1.2);
            }
            Fx.rune(sl, cx, cy + 0.05, cz, 10, Fx.GOLD, Fx.CYAN);
            for (int k = 1; k <= 4; k++) {
                final double r = k * 2.5;
                Scheduler.after(k * 2, () -> {
                    Fx.shock(sl, cx, cy, cz, r);
                    Fx.ring(sl, Fx.GOLD, cx, cy + 0.1, cz, r);
                });
            }
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, cx, cy + 1, cz, 150, 5, 1, 5, 0.4);
            Fx.sound(sl, cx, cy, cz, 1.5f, 0.6f);
        });
        return true;
    }
}
