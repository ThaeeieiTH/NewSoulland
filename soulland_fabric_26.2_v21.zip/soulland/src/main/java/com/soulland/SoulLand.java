package com.soulland;

import com.soulland.net.AbsorbPayload;
import com.soulland.net.ActionPayload;
import com.soulland.net.AwakenPayload;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

public class SoulLand implements ModInitializer {
    public static final String MOD_ID = "soulland";

    /** true ระหว่างที่ทักษะกำลังทำดาเมจ (กันไม่ให้โบนัสตีด้วยค้อนซ้อน) */
    public static boolean SKILL_HIT = false;
    private static boolean inHammerHit = false;

    @Override
    public void onInitialize() {
        ModAttachments.init();
        ModItems.init();

        // ปุ่มจากไคลเอนต์
        PayloadTypeRegistry.serverboundPlay().register(ActionPayload.TYPE, ActionPayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(AwakenPayload.TYPE, AwakenPayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(AbsorbPayload.TYPE, AbsorbPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(ActionPayload.TYPE, (payload, context) -> {
            ServerPlayer p = context.player();
            Actions.handle(p, payload.action());
        });

        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            // เกราะเฮ่าเทียน = อมตะช่วงสั้นๆ
            if (entity instanceof ServerPlayer p && p.level() instanceof ServerLevel sl) {
                if (Skills.isInvulnerable(p, sl.getServer().getTickCount())) return false;
            }

            // ค้อนเฮ่าเทียนเป็นอาวุธจริง: ตีด้วยมือหลักแล้วได้ดาเมจเพิ่มตามเลเวล/วงแหวน
            if (!SKILL_HIT && !inHammerHit
                    && source.getEntity() instanceof ServerPlayer atk
                    && source.getDirectEntity() == atk
                    && entity != atk
                    && entity.level() instanceof ServerLevel sl2
                    && Soul.isSoulWeapon(atk.getMainHandItem())) {
                float bonus = (float) ((12.0 + Soul.level(atk) * 0.3 + Soul.ringBonus(atk) * 0.5)
                        * atk.getAttackStrengthScale(0.5f));
                inHammerHit = true;
                try {
                    entity.hurtServer(sl2, source, amount + bonus);
                } finally {
                    inHammerHit = false;
                }
                sl2.sendParticles(ParticleTypes.ELECTRIC_SPARK, entity.getX(), entity.getY() + 1.0, entity.getZ(),
                        14, 0.3, 0.4, 0.3, 0.2);
                return false;
            }
            return true;
        });

        // ฆ่ามอนสเตอร์ = ได้ EXP (ต้องปลุกวิญญาณยุทธ์แล้ว) / ตาย = เก็บวิญญาณและวงแหวนเข้าตัว
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof ServerPlayer dead) {
                dead.setAttached(ModAttachments.SOUL_OPEN, 0);
                dead.setAttached(ModAttachments.RINGS_OPEN, 0);
                Skills.clear(dead);
                return;
            }
            if (source.getEntity() instanceof ServerPlayer sp && !Soul.soul(sp).isEmpty()) {
                Soul.addExp(sp, Soul.killExp(entity));
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            Scheduler.tick();
            if (server.getTickCount() % 20 != 0) return;
            for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                Soul.applyHealth(p);
                int cur = Soul.power(p);
                int max = Soul.maxPower(p);
                if (cur < max) {
                    Soul.setPower(p, cur + 1 + Soul.level(p) / 20);
                }
            }
        });

        // ลบวงแหวนแบบเอนทิตีที่อาจค้างจากเวอร์ชันเก่า
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            CommandSourceStack src = server.createCommandSourceStack().withSuppressedOutput();
            server.getCommands().performPrefixedCommand(src, "kill @e[tag=soulland_ring]");
        });

        ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            Scheduler.clear();
            Skills.clearAll();
            Actions.clearAll();
        });
    }
}
