package com.soulland.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.soulland.Soul;
import com.soulland.SoulLand;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

import java.util.ArrayList;
import java.util.List;

/**
 * อัศวินศักดิ์สิทธิ์ (เปิดวิญญาณยุทธ์): โมเดล 3 มิติของอัศวินเกราะทอง มีปีก ฮาโล ดาบ โล่ ผ้าคลุม
 * ยืนด้านหลังผู้เล่น หันหน้าไปทางเดียวกับผู้เล่น (ปีกกระพือ ผ้าคลุมพลิ้ว ลอยโยกเบาๆ)
 * ประกอบจากกล่องสี (ข้อมูลใน KnightModel) วาดฝั่งไคลเอนต์ทุกเฟรม ไม่ใช้เอนทิตี
 */
public final class KnightRenderer {
    private static final Identifier PALETTE = Identifier.fromNamespaceAndPath(SoulLand.MOD_ID, "textures/fx/knight_pal.png");

    /** สี่เหลี่ยม 4 มุม (พิกัดโลก) + UV + สีจุดยอด */
    public record Quad(Identifier texture, double[] p, float[] u, float[] v, int color) {}

    /** ขนาด: 1 พิกเซลของโมเดล = 0.1 บล็อก (อัศวินสูงราว 3.6 บล็อก) */
    private static final double SCALE = 0.1;

    // (หน้า, จุดยอด 4 จุด) ในพื้นที่กล่อง หน่วย -1..1  — ลำดับตามที่ใช้ตอนทดสอบภาพ
    private static final int[][][] FACES = {
            {{1, 0, 0}, {1, -1, -1}, {1, 1, -1}, {1, 1, 1}, {1, -1, 1}},
            {{-1, 0, 0}, {-1, -1, 1}, {-1, 1, 1}, {-1, 1, -1}, {-1, -1, -1}},
            {{0, 1, 0}, {-1, 1, -1}, {-1, 1, 1}, {1, 1, 1}, {1, 1, -1}},
            {{0, -1, 0}, {-1, -1, 1}, {-1, -1, -1}, {1, -1, -1}, {1, -1, 1}},
            {{0, 0, 1}, {-1, -1, 1}, {1, -1, 1}, {1, 1, 1}, {-1, 1, 1}},
            {{0, 0, -1}, {1, -1, -1}, {-1, -1, -1}, {-1, 1, -1}, {1, 1, -1}},
    };

    private KnightRenderer() {}

    /** หมุน (ลำดับ Z แล้ว Y แล้ว X) */
    private static double[] rot(double x, double y, double z, double rx, double ry, double rz) {
        if (rz != 0) {
            double c = Math.cos(rz), s = Math.sin(rz);
            double nx = x * c - y * s, ny = x * s + y * c;
            x = nx;
            y = ny;
        }
        if (ry != 0) {
            double c = Math.cos(ry), s = Math.sin(ry);
            double nx = x * c + z * s, nz = -x * s + z * c;
            x = nx;
            z = nz;
        }
        if (rx != 0) {
            double c = Math.cos(rx), s = Math.sin(rx);
            double ny = y * c - z * s, nz = y * s + z * c;
            y = ny;
            z = nz;
        }
        return new double[]{x, y, z};
    }

    /** มุมโยกของแต่ละกลุ่ม {rx, ry, rz} ตามเวลา */
    private static double[] sway(int g, double t) {
        return switch (g) {
            case 1 -> new double[]{-0.08 + Math.sin(t * 0.07) * 0.05, 0, 0};
            case 2 -> new double[]{-0.05 + Math.sin(t * 0.07 + 1.0) * 0.04, 0, 0};
            case 3 -> new double[]{0, 0, Math.sin(t * 0.12) * 0.12};
            case 4 -> new double[]{0, 0, -Math.sin(t * 0.12) * 0.12};
            case 5 -> new double[]{0.05 + Math.sin(t * 0.09) * 0.04, 0, 0};
            default -> new double[]{0, 0, 0};
        };
    }

    public static List<Quad> collect(Minecraft mc, float partial, double camX, double camZ) {
        List<Quad> out = new ArrayList<>();
        LocalPlayer pl = mc.player;
        if (pl == null || !Soul.KNIGHT.equals(Soul.soul(pl)) || !Soul.soulOpen(pl)) return out;
        if (mc.options.getCameraType().isFirstPerson()) return out;

        double px = Mth.lerp((double) partial, pl.xo, pl.getX());
        double py = Mth.lerp((double) partial, pl.yo, pl.getY());
        double pz = Mth.lerp((double) partial, pl.zo, pl.getZ());
        float bodyYaw = Mth.rotLerp(partial, pl.yBodyRotO, pl.yBodyRot);
        double th = Math.toRadians(bodyYaw);
        double fx = -Math.sin(th), fz = Math.cos(th);
        double t = (mc.level != null ? mc.level.getGameTime() : 0) + partial;

        // ยืนด้านหลังผู้เล่น ลอยโยกเบาๆ
        double bx = px - fx * 2.8, bz = pz - fz * 2.8;
        double by = py + 0.1 + Math.sin(t * 0.08) * 0.08;
        double cy = Math.cos(-th), sy = Math.sin(-th);   // หมุนรอบ Y ด้วย -th เพื่อให้หน้าโมเดล (+z) ไปทางหน้าผู้เล่น

        double[][] boxes = KnightModel.BOXES;
        for (double[] b : boxes) {
            int g = (int) b[0];
            double[] pv = KnightModel.PIVOT[g];
            double[] sw = sway(g, t);
            double w = b[4] / 2, h = b[5] / 2, d = b[6] / 2;
            int col = (int) b[10];
            float uu = (col + 0.5f) / 16f, vv = 0.5f / 16f;
            for (int[][] face : FACES) {
                int[] n = face[0];
                double shade = n[1] > 0 ? 1.0 : n[1] < 0 ? 0.6 : n[2] > 0 ? 0.92 : n[2] < 0 ? 0.74 : 0.82;
                int sh = (int) (255 * shade);
                int color = (0xE0 << 24) | (sh << 16) | (sh << 8) | sh;
                double[] p = new double[12];
                for (int i = 0; i < 4; i++) {
                    int[] c = face[i + 1];
                    double[] v = rot(c[0] * w, c[1] * h, c[2] * d, b[7], b[8], b[9]);
                    double x = v[0] + b[1], y = v[1] + b[2], z = v[2] + b[3];
                    if (g != 0) {                                   // โยกกลุ่มรอบจุดหมุน
                        double[] r = rot(x - pv[0], y - pv[1], z - pv[2], sw[0], sw[1], sw[2]);
                        x = r[0] + pv[0];
                        y = r[1] + pv[1];
                        z = r[2] + pv[2];
                    }
                    x *= SCALE;
                    y *= SCALE;
                    z *= SCALE;
                    double wx = x * cy + z * sy;                    // หมุนรอบ Y
                    double wz = -x * sy + z * cy;
                    p[i * 3] = bx + wx;
                    p[i * 3 + 1] = by + y;
                    p[i * 3 + 2] = bz + wz;
                }
                out.add(new Quad(PALETTE, p, new float[]{uu, uu, uu, uu}, new float[]{vv, vv, vv, vv}, color));
            }
        }
        return out;
    }

    public static void write(PoseStack.Pose pose, VertexConsumer buf, Quad q, double cx, double cy, double cz) {
        for (int i = 0; i < 4; i++) {
            vertex(buf, pose, (float) (q.p()[i * 3] - cx), (float) (q.p()[i * 3 + 1] - cy), (float) (q.p()[i * 3 + 2] - cz),
                    q.u()[i], q.v()[i], q.color(), 1f);
        }
        for (int i = 3; i >= 0; i--) {
            vertex(buf, pose, (float) (q.p()[i * 3] - cx), (float) (q.p()[i * 3 + 1] - cy), (float) (q.p()[i * 3 + 2] - cz),
                    q.u()[i], q.v()[i], q.color(), -1f);
        }
    }

    private static void vertex(VertexConsumer buf, PoseStack.Pose pose, float x, float y, float z,
                               float u, float v, int color, float ny) {
        buf.addVertex(pose, x, y, z)
                .setColor(color)
                .setUv(u, v)
                .setOverlay(655360)
                .setLight(15728880)
                .setNormal(pose, 0f, ny, 0f);
    }
}
