package com.soulland;

import com.soulland.net.AwakenPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.HashMap;
import java.util.Random;
import java.util.Map;
import java.util.UUID;

/** จัดการปุ่มที่ผู้เล่นกด (ส่งมาจากไคลเอนต์) */
public final class Actions {
    public static final int AWAKEN = 0;       // M
    public static final int REROLL = 1;       // N
    public static final int TOGGLE_SOUL = 2;  // G
    public static final int TOGGLE_RINGS = 3; // H
    public static final int NEXT_SKILL = 4;   // V
    public static final int USE_SKILL = 5;    // R

    private static final Map<UUID, Long> REROLL_CONFIRM = new HashMap<>();
    private static final Random RNG = new Random();

    private Actions() {}

    public static void clearAll() {
        REROLL_CONFIRM.clear();
    }

    public static void handle(ServerPlayer p, int action) {
        switch (action) {
            case AWAKEN -> awaken(p);
            case REROLL -> reroll(p);
            case TOGGLE_SOUL -> toggleSoul(p);
            case TOGGLE_RINGS -> toggleRings(p);
            case NEXT_SKILL -> nextSkill(p);
            case USE_SKILL -> useSkill(p);
            default -> { }
        }
    }

    private static void awaken(ServerPlayer p) {
        if (!Soul.soul(p).isEmpty()) {
            Soul.msg(p, "ปลุกวิญญาณยุทธ์แล้ว (กด N เพื่อรีวิญญาณยุทธ์)", true);
            return;
        }
        int startLevel = 1 + RNG.nextInt(10); // สุ่มเลเวลตอนปลุก 1-10
        String soulId = Soul.ALL_SOULS[RNG.nextInt(Soul.ALL_SOULS.length)]; // สุ่มวิญญาณยุทธ์
        p.setAttached(ModAttachments.SOUL, soulId);
        p.setAttached(ModAttachments.SKILL, 0);
        p.setAttached(ModAttachments.SOUL_OPEN, 0);
        p.setAttached(ModAttachments.LEVEL, startLevel);
        p.setAttached(ModAttachments.EXP, 0);
        Soul.applyHealth(p);
        p.setHealth(p.getMaxHealth());
        Soul.setPower(p, Soul.maxPower(p));
        ServerPlayNetworking.send(p, new AwakenPayload(0)); // เริ่มอนิเมชั่นกล้อง/ลอยตัวฝั่งไคลเอนต์
        awakenFx(p);
        Soul.msg(p, "ปลุกวิญญาณยุทธ์สำเร็จ: " + Soul.soulName(soulId) + " เลเวลเริ่มต้น Lv." + startLevel + " (กด G เพื่อเปิด)", false);
    }

    /** เอฟเฟกต์ตอนปลุกวิญญาณยุทธ์: วงเวทที่พื้น เส้นแสงพุ่งขึ้นรอบตัว วงแหวนแสง และระเบิดแสงตอนลอยสุด */
    private static void awakenFx(ServerPlayer p) {
        if (!(p.level() instanceof ServerLevel sl)) return;
        final double bx = p.getX(), by = p.getY(), bz = p.getZ();
        Fx.rune(sl, bx, by + 0.05, bz, 2.6, Fx.GOLD, Fx.CYAN);
        Fx.risingRings(sl, Fx.CYAN, bx, by, bz, 1.6, 5);
        for (int t = 6; t <= 66; t++) {
            final int tick = t;
            Scheduler.after(t, () -> {
                if (!p.isAlive()) return;
                for (int i = 0; i < 6; i++) {
                    double a = RNG.nextDouble() * Math.PI * 2;
                    double r = 0.8 + RNG.nextDouble() * 0.7;
                    double x = p.getX() + Math.cos(a) * r;
                    double z = p.getZ() + Math.sin(a) * r;
                    double y = p.getY() - 0.3 + RNG.nextDouble() * 1.2;
                    sl.sendParticles(ParticleTypes.END_ROD, x, y, z, 0, 0, 1, 0, 0.18 + RNG.nextDouble() * 0.2);
                    if (i % 2 == 0) Fx.line(sl, Fx.CYAN, x, y, z, x, y + 1.4, z, 0.25);
                }
                if (tick % 12 == 0) Fx.ring(sl, Fx.GOLD, p.getX(), p.getY() + 0.9, p.getZ(), 1.1);
            });
        }
        Scheduler.after(50, () -> {
            if (!p.isAlive()) return;
            Fx.sphere(sl, ParticleTypes.END_ROD, p.getX(), p.getY() + 1, p.getZ(), 0.5, 80);
            Fx.sound(sl, p.getX(), p.getY(), p.getZ(), 1.0f, 1.2f);
        });
    }

    private static void reroll(ServerPlayer p) {
        long now = System.currentTimeMillis();
        Long first = REROLL_CONFIRM.get(p.getUUID());
        if (first == null || now - first > 5000) {
            REROLL_CONFIRM.put(p.getUUID(), now);
            Soul.msg(p, "กด N อีกครั้งภายใน 5 วินาทีเพื่อยืนยัน: รีวิญญาณยุทธ์จะทำให้ตาย และรีวิญญาณยุทธ์ เลเวล วงแหวนทั้งหมด", false);
            return;
        }
        REROLL_CONFIRM.remove(p.getUUID());
        if (!(p.level() instanceof ServerLevel sl)) return;

        Skills.clear(p);
        removeHammer(p);
        Soul.resetAll(p);
        Soul.msg(p, "รีวิญญาณยุทธ์แล้ว เกิดใหม่แล้วกด M เพื่อปลุกวิญญาณยุทธ์อีกครั้ง", false);
        p.hurtServer(sl, sl.damageSources().genericKill(), Float.MAX_VALUE);
    }

    private static void toggleSoul(ServerPlayer p) {
        if (Soul.soul(p).isEmpty()) {
            Soul.msg(p, "ยังไม่ได้ปลุกวิญญาณยุทธ์ (กด M)", true);
            return;
        }
        if (Soul.soulOpen(p)) {
            p.setAttached(ModAttachments.SOUL_OPEN, 0);
            removeHammer(p);
            Soul.msg(p, "เก็บวิญญาณยุทธ์", true);
        } else {
            p.setAttached(ModAttachments.SOUL_OPEN, 1);
            giveHammer(p);
            if (p.level() instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 1.0, p.getZ(), 40, 0.5, 0.8, 0.5, 0.3);
            }
            Soul.msg(p, "เปิดวิญญาณยุทธ์: " + Soul.soulName(Soul.soul(p)), true);
        }
    }

    private static void toggleRings(ServerPlayer p) {
        if (Soul.ringsOpen(p)) {
            p.setAttached(ModAttachments.RINGS_OPEN, 0);
            Soul.msg(p, "ปิดวงแหวน", true);
            return;
        }
        if (Soul.rings(p).isEmpty()) {
            Soul.msg(p, "ยังไม่มีวงแหวนวิญญาณ", true);
            return;
        }
        p.setAttached(ModAttachments.RINGS_OPEN, 1);
        Soul.msg(p, "เปิดวงแหวน", true);
    }

    private static void nextSkill(ServerPlayer p) {
        if (Soul.soul(p).isEmpty()) {
            Soul.msg(p, "ยังไม่ได้ปลุกวิญญาณยุทธ์ (กด M)", true);
            return;
        }
        String[] names = Skills.names(Soul.soul(p));
        int[] cost = Skills.costs(Soul.soul(p));
        int s = (Soul.skill(p) + 1) % names.length;
        p.setAttached(ModAttachments.SKILL, s);
        String lock = Skills.unlocked(p, s) ? "" : " [ล็อก: ต้องมีวงแหวน " + (s + 1) + " วง]";
        Soul.msg(p, "ทักษะ " + (s + 1) + ": " + names[s] + " (พลัง " + cost[s] + ")" + lock, true);
    }

    private static void useSkill(ServerPlayer p) {
        if (Soul.soul(p).isEmpty()) {
            Soul.msg(p, "ยังไม่ได้ปลุกวิญญาณยุทธ์ (กด M)", true);
            return;
        }
        if (!Soul.soulOpen(p)) {
            Soul.msg(p, "เปิดวิญญาณยุทธ์ก่อน (กด G)", true);
            return;
        }
        Item weapon = Soul.weapon(Soul.soul(p));
        if (weapon != null && !p.getMainHandItem().is(weapon) && !p.getOffhandItem().is(weapon)) {
            Soul.msg(p, "ต้องถือ" + Soul.soulName(Soul.soul(p)) + "ในมือถึงจะใช้สกิลได้", true);
            return;
        }
        Skills.use(p);
    }

    private static boolean has(ServerPlayer p, Item item) {
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            if (inv.getItem(i).is(item)) return true;
        }
        return false;
    }

    private static void give(ServerPlayer p, Item item, boolean offhand) {
        if (has(p, item)) return;
        ItemStack s = new ItemStack(item);
        if (offhand && p.getOffhandItem().isEmpty()) {
            p.setItemSlot(EquipmentSlot.OFFHAND, s);
            return;
        }
        if (!p.getInventory().add(s)) {
            p.drop(s, false);
        }
    }

    /** เปิดวิญญาณยุทธ์: ได้อาวุธประจำวิญญาณ (อัศวินศักดิ์สิทธิ์ไม่มีอาวุธ ยืนด้านหลังแทน) */
    private static void giveHammer(ServerPlayer p) {
        String soul = Soul.soul(p);
        Item weapon = Soul.weapon(soul);
        if (weapon != null) give(p, weapon, false);
    }

    /** เก็บวิญญาณยุทธ์: อาวุธทุกชิ้นหายไป */
    private static void removeHammer(ServerPlayer p) {
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack st = inv.getItem(i);
            if (st.is(ModItems.HAOTIAN_HAMMER) || st.is(ModItems.HOLY_SCYTHE)) {
                inv.setItem(i, ItemStack.EMPTY);
            }
        }
    }
}
