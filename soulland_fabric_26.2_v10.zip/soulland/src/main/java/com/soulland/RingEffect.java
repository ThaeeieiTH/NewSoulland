package com.soulland;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * วงแหวน (ปุ่ม H) เป็นโมเดลจริง ไม่ใช่พาร์ติเคิล: เอนทิตี item_display แสดงรูปวงเวท (ย้อมสีตามระดับ)
 * - ผูกเป็น "ผู้โดยสาร" ของผู้เล่น จึงขยับพร้อมตัวผู้เล่นเป๊ะ ไม่หน่วง
 * - อยู่ระดับเอว วางราบ ซ้อนกัน (ในสุด = ระดับต่ำ, นอกสุด = ระดับสูงสุด) หมุนสลับทิศ
 * - อนิเมชั่นเปิด: วงขยายออกจากกลางตัวทีละวง (ในสุดก่อน) พร้อมหมุนเร็วแล้วช้าลง / ปิด: หดกลับแล้วหาย
 */
public final class RingEffect {
    private static final String[] IDS = {"ten", "hundred", "thousand", "tenthousand", "hundredthousand", "million"};
    private static final String TAG = "soulland_ring";

    /** ระดับเอว: ผู้โดยสารอยู่เหนือผู้เล่นประมาณ 1.8 บล็อก จึงเลื่อนลง ~0.85 */
    private static final double WAIST_OFFSET = -0.85;
    private static final int OPEN_TICKS = 14;
    private static final int CLOSE_TICKS = 8;

    private static final class State {
        String rings;
        ServerLevel level;
        long born;
        long closeAt = -1;
        final List<UUID> ids = new ArrayList<>();
        final List<Double> sizes = new ArrayList<>();
        final List<Double> offsets = new ArrayList<>();
        float[] yaw;
    }

    private static final Map<UUID, State> STATES = new HashMap<>();

    private RingEffect() {}

    public static void tick(MinecraftServer server) {
        long now = server.getTickCount();
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            State st = STATES.get(p.getUUID());
            boolean want = p.isAlive() && Soul.ringsOpen(p) && !Soul.rings(p).isEmpty();

            if (!want) {
                if (st == null) continue;
                if (!p.isAlive()) {
                    discard(st);
                    STATES.remove(p.getUUID());
                } else if (st.closeAt < 0) {
                    startClose(server, st, now);
                } else if (now >= st.closeAt) {
                    discard(st);
                    STATES.remove(p.getUUID());
                } else {
                    follow(st, now);
                }
                continue;
            }

            if (!(p.level() instanceof ServerLevel sl)) continue;
            String rings = Soul.rings(p);
            if (st != null && (st.closeAt >= 0 || st.level != sl || !st.rings.equals(rings) || broken(st))) {
                discard(st);
                STATES.remove(p.getUUID());
                st = null;
            }
            if (st == null) {
                st = build(server, sl, p, rings, now);
                if (st == null) {
                    p.setAttached(ModAttachments.RINGS_OPEN, 0);
                    Soul.msg(p, "สร้างวงแหวนไม่สำเร็จ", true);
                    continue;
                }
                STATES.put(p.getUUID(), st);
            }
            follow(st, now);
        }

        // ผู้เล่นที่ออกจากเกมแล้ว: เก็บวงแหวนออกทันที
        Iterator<Map.Entry<UUID, State>> it = STATES.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, State> e = it.next();
            if (server.getPlayerList().getPlayer(e.getKey()) == null) {
                discard(e.getValue());
                it.remove();
            }
        }
    }

    public static void removeAll() {
        for (State st : STATES.values()) discard(st);
        STATES.clear();
    }

    /** ลบวงแหวนที่ค้างจากรอบก่อน (เช่น เกมปิดผิดปกติ) */
    public static void cleanupOrphans(MinecraftServer server) {
        CommandSourceStack src = server.createCommandSourceStack().withSuppressedOutput();
        server.getCommands().performPrefixedCommand(src, "kill @e[tag=" + TAG + "]");
    }

    // ---------- ภายใน ----------

    /** วงหายไป หรือหลุดจากตัวผู้เล่น (เช่น เทเลพอร์ต/ข้ามมิติ) */
    private static boolean broken(State st) {
        for (UUID id : st.ids) {
            Entity e = st.level.getEntity(id);
            if (e == null || e.getVehicle() == null) return true;
        }
        return false;
    }

    private static void discard(State st) {
        for (UUID id : st.ids) {
            Entity e = st.level.getEntity(id);
            if (e != null) e.discard();
        }
        st.ids.clear();
    }

    private static String transform(double y, double size) {
        return String.format(Locale.ROOT,
                "transformation:{left_rotation:[-0.70710677f,0f,0f,0.70710677f],right_rotation:[0f,0f,0f,1f],"
                        + "translation:[0f,%.3ff,0f],scale:[%.3ff,%.3ff,%.3ff]}", y, size, size, size);
    }

    private static void run(MinecraftServer server, ServerLevel sl, String cmd) {
        CommandSourceStack src = server.createCommandSourceStack().withLevel(sl).withSuppressedOutput();
        server.getCommands().performPrefixedCommand(src, cmd);
    }

    private static void animate(MinecraftServer server, ServerLevel sl, UUID id, double y, double size, int ticks) {
        run(server, sl, "data merge entity " + id + " {start_interpolation:0,interpolation_duration:" + ticks + ","
                + transform(y, size) + "}");
    }

    private static State build(MinecraftServer server, ServerLevel sl, ServerPlayer p, String rings, long now) {
        List<Integer> tiers = new ArrayList<>();
        for (char c : rings.toCharArray()) {
            int t = c - '0';
            if (t >= 0 && t < IDS.length) tiers.add(t);
        }
        if (tiers.isEmpty()) return null;
        Collections.sort(tiers); // ต่ำ -> สูง : ในสุด -> นอกสุด

        State st = new State();
        st.rings = rings;
        st.level = sl;
        st.born = now;
        st.yaw = new float[tiers.size()];

        for (int k = 0; k < tiers.size(); k++) {
            boolean outer = k == tiers.size() - 1;
            String model = (outer ? "ring_full_" : "ring_band_") + IDS[tiers.get(k)];
            double radius = 1.0 + 0.4 * k;
            double size = radius * 2.5;
            double y = WAIST_OFFSET + k * 0.012;
            UUID u = UUID.randomUUID();
            int a = (int) (u.getMostSignificantBits() >> 32);
            int b = (int) u.getMostSignificantBits();
            int c = (int) (u.getLeastSignificantBits() >> 32);
            int d = (int) u.getLeastSignificantBits();
            String cmd = String.format(Locale.ROOT,
                    "summon minecraft:item_display %.3f %.3f %.3f {UUID:[I;%d,%d,%d,%d],Tags:[\"%s\"],"
                            + "item:{id:\"minecraft:stick\",count:1,components:{\"minecraft:item_model\":\"soulland:%s\"}},"
                            + "item_display:\"fixed\",billboard:\"fixed\",brightness:{sky:15,block:15},view_range:2.0f,%s}",
                    p.getX(), p.getY(), p.getZ(), a, b, c, d, TAG, model, transform(y, 0.01));
            run(server, sl, cmd);
            Entity e = sl.getEntity(u);
            if (e == null) {
                discard(st);
                return null;
            }
            // ผูกกับผู้เล่น: ขยับตามตัวทันที
            run(server, sl, "ride " + u + " mount " + p.getUUID());
            if (sl.getEntity(u) == null || sl.getEntity(u).getVehicle() == null) {
                st.ids.add(u);
                discard(st);
                return null;
            }
            st.ids.add(u);
            st.sizes.add(size);
            st.offsets.add(y);

            // อนิเมชั่นเปิด: ขยายออกทีละวง
            final double fs = size;
            final double fy = y;
            Scheduler.after(2 + 3 * k, () -> animate(server, sl, u, fy, fs, OPEN_TICKS));
        }
        return st;
    }

    private static void startClose(MinecraftServer server, State st, long now) {
        for (int k = 0; k < st.ids.size(); k++) {
            animate(server, st.level, st.ids.get(k), st.offsets.get(k), 0.01, CLOSE_TICKS);
        }
        st.closeAt = now + CLOSE_TICKS + 2;
    }

    private static void follow(State st, long now) {
        double age = now - st.born;
        double boost = 1.0 + 5.0 * Math.max(0.0, 1.0 - age / 30.0); // หมุนเร็วตอนเปิด แล้วช้าลง
        for (int k = 0; k < st.ids.size(); k++) {
            Entity e = st.level.getEntity(st.ids.get(k));
            if (e == null) continue;
            float step = (float) ((1.5 + 0.35 * k) * boost);
            st.yaw[k] = (st.yaw[k] + (k % 2 == 0 ? step : -step)) % 360f;
            e.setYRot(st.yaw[k]);
        }
    }
}
