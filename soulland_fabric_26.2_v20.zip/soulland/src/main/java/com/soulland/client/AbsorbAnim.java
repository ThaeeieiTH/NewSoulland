package com.soulland.client;

import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * อนิเมชั่นดูดซับวงแหวน (ฝั่งไคลเอนต์ ~3.3 วินาที):
 * กล้องไปอยู่ด้านหน้าตัวละคร → วงแหวนใหญ่ขยับจากด้านนอกเข้าด้านใน (หมุนเร็ว) →
 * ลอยขึ้นจากระดับเอวไปอยู่เหนือหัว → จางหายเป็นส่วนหนึ่งของตัว → คืนกล้อง
 */
public final class AbsorbAnim {
    private static final int TOTAL = 66;

    private static boolean active = false;
    private static int t = 0;
    private static int tier = 0;
    private static float startPitch;
    private static CameraType prevCamera;

    private AbsorbAnim() {}

    private static double ease(double x) {
        x = Mth.clamp(x, 0.0, 1.0);
        return x * x * (3 - 2 * x);
    }

    public static boolean isActive() {
        return active;
    }

    public static void start(Minecraft mc, int ringTier) {
        LocalPlayer p = mc.player;
        if (p == null || active) return;
        active = true;
        t = 0;
        tier = ringTier;
        startPitch = p.getXRot();
        prevCamera = mc.options.getCameraType();
        mc.options.setCameraType(CameraType.THIRD_PERSON_FRONT);
        p.setXRot(10f);
    }

    /** ก่อนเริ่มแต่ละ tick: หยุดแรงเคลื่อนที่ ให้ผู้เล่นยืนนิ่งตอนดูดซับ */
    public static void tickStart(Minecraft mc) {
        if (active && mc.player != null) {
            Vec3 v = mc.player.getDeltaMovement();
            mc.player.setDeltaMovement(0, Math.min(0, v.y), 0);
        }
    }

    public static void tick(Minecraft mc) {
        if (!active) return;
        LocalPlayer p = mc.player;
        if (p == null || !p.isAlive()) {
            finish(mc);
            return;
        }
        t++;
        if (t >= TOTAL) finish(mc);
    }

    private static void finish(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p != null) p.setXRot(startPitch);
        if (prevCamera != null) mc.options.setCameraType(prevCamera);
        active = false;
    }

    /** เพิ่มวงแหวนที่กำลังถูกดูดซับเข้ารายการวาด */
    public static void collect(List<RingRenderer.Draw> out, Minecraft mc, float partial) {
        if (!active) return;
        LocalPlayer p = mc.player;
        if (p == null) return;
        double time = t + partial;
        double px = Mth.lerp((double) partial, p.xo, p.getX());
        double py = Mth.lerp((double) partial, p.yo, p.getY());
        double pz = Mth.lerp((double) partial, p.zo, p.getZ());
        double h = p.getBbHeight();
        double waist = py + h * 0.53;
        double head = py + h + 0.45;

        double radius, y, alpha;
        if (time < 8) {                         // ปรากฏไกลตัว
            radius = 6.0;
            y = waist;
            alpha = time / 8.0;
        } else if (time < 36) {                 // ขยับจากด้านนอกเข้าด้านใน
            double k = ease((time - 8) / 28.0);
            radius = 6.0 + (0.9 - 6.0) * k;
            y = waist;
            alpha = 1.0;
        } else if (time < 56) {                 // ลอยขึ้นไปเหนือหัว
            double k = ease((time - 36) / 20.0);
            radius = 0.9 + (0.45 - 0.9) * k;
            y = waist + (head - waist) * k;
            alpha = 1.0;
        } else {                                // จางหาย
            radius = 0.45;
            y = head;
            alpha = Math.max(0.0, 1.0 - (time - 56) / 8.0);
        }
        if (alpha <= 0.01) return;
        float angle = (float) (time * (time < 36 ? 0.5 : 0.25));
        int color = ((int) (255 * Mth.clamp(alpha, 0.0, 1.0)) << 24) | 0xFFFFFF;
        out.add(new RingRenderer.Draw(RingRenderer.fullTexture(tier), px, y, pz, radius * 1.25, angle, color));
    }
}
