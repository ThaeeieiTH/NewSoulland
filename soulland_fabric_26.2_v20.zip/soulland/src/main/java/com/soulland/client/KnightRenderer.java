package com.soulland.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.soulland.Soul;
import com.soulland.SoulLand;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

import java.util.ArrayList;
import java.util.List;

/**
 * อัศวินศักดิ์สิทธิ์ (เปิดวิญญาณยุทธ์): วิญญาณอัศวินมีปีกและฮาโลยืนด้านหลังผู้เล่น
 * วาดฝั่งไคลเอนต์ทุกเฟรมจากภาพอ้างอิง (ภาพตัดจากรูป หันเข้าหากล้อง โยกลอยเบาๆ)
 */
public final class KnightRenderer {
    private static final Identifier KNIGHT = Identifier.fromNamespaceAndPath(SoulLand.MOD_ID, "textures/fx/knight.png");

    /** สี่เหลี่ยม 4 มุม (พิกัดโลก) + UV */
    public record Quad(Identifier texture, double[] p, float[] u, float[] v) {}

    private KnightRenderer() {}

    private static Quad quad(Identifier tex, double[] p, float[] u, float[] v) {
        return new Quad(tex, p, u, v);
    }

    public static List<Quad> collect(Minecraft mc, float partial, double camX, double camZ) {
        List<Quad> out = new ArrayList<>();
        LocalPlayer pl = mc.player;
        if (pl == null || !Soul.KNIGHT.equals(Soul.soul(pl)) || !Soul.soulOpen(pl)) return out;
        if (mc.options.getCameraType().isFirstPerson()) return out;

        double px = Mth.lerp((double) partial, pl.xo, pl.getX());
        double py = Mth.lerp((double) partial, pl.yo, pl.getY());
        double pz = Mth.lerp((double) partial, pl.zo, pl.getZ());
        float bodyYaw = Mth.rotLerp(partial, pl.yBodyRotO, pl.yBodyRot);
        double ang = Math.toRadians(bodyYaw);
        double fx = -Math.sin(ang), fz = Math.cos(ang);       // ทิศหน้าของผู้เล่น
        double t = (mc.level != null ? mc.level.getGameTime() : 0) + partial;

        // อัศวินศักดิ์สิทธิ์ยืนด้านหลังผู้เล่น ลอยโยกเบาๆ หันหน้าเข้าหากล้อง
        double bx = px - fx * 2.4, bz = pz - fz * 2.4;
        double bob = 0.12 + Math.sin(t * 0.08) * 0.1;
        double height = 4.0, halfW = height * 640.0 / 556.0 / 2.0;
        double nx = camX - bx, nz = camZ - bz;
        double nl = Math.max(1e-6, Math.hypot(nx, nz));
        nx /= nl;
        nz /= nl;
        double ax = -nz, az = nx;                              // แกนซ้าย-ขวาของภาพ
        double[][] c = {{-1, 0}, {1, 0}, {1, 1}, {-1, 1}};
        float[] u = {0f, 1f, 1f, 0f};
        float[] v = {1f, 1f, 0f, 0f};
        double[] p = new double[12];
        for (int i = 0; i < 4; i++) {
            p[i * 3] = bx + ax * c[i][0] * halfW;
            p[i * 3 + 1] = py + bob + c[i][1] * height;
            p[i * 3 + 2] = bz + az * c[i][0] * halfW;
        }
        out.add(quad(KNIGHT, p, u, v));
        return out;
    }

    public static void write(PoseStack.Pose pose, VertexConsumer buf, Quad q, double cx, double cy, double cz) {
        for (int i = 0; i < 4; i++) {
            vertex(buf, pose, (float) (q.p()[i * 3] - cx), (float) (q.p()[i * 3 + 1] - cy), (float) (q.p()[i * 3 + 2] - cz),
                    q.u()[i], q.v()[i], 1f);
        }
        for (int i = 3; i >= 0; i--) {
            vertex(buf, pose, (float) (q.p()[i * 3] - cx), (float) (q.p()[i * 3 + 1] - cy), (float) (q.p()[i * 3 + 2] - cz),
                    q.u()[i], q.v()[i], -1f);
        }
    }

    private static void vertex(VertexConsumer buf, PoseStack.Pose pose, float x, float y, float z, float u, float v, float ny) {
        buf.addVertex(pose, x, y, z)
                .setColor(0xD8FFFFFF)
                .setUv(u, v)
                .setOverlay(655360)
                .setLight(15728880)
                .setNormal(pose, 0f, ny, 0f);
    }
}
