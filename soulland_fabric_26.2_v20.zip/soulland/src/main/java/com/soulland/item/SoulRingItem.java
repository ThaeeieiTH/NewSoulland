package com.soulland.item;

import com.soulland.Fx;
import com.soulland.Soul;
import com.soulland.net.AbsorbPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

/** วงแหวนวิญญาณ: คลิกขวาเพื่อดูดซับ */
public class SoulRingItem extends Item {
    private final int color;

    public SoulRingItem(Properties properties, int color) {
        super(properties);
        this.color = color;
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (!(level instanceof ServerLevel server) || !(player instanceof ServerPlayer sp)) {
            return InteractionResult.PASS;
        }

        String error = Soul.tryAbsorb(sp, color);
        if (error != null) {
            sp.sendSystemMessage(Component.literal(error), true);
            return InteractionResult.FAIL;
        }

        player.getItemInHand(hand).shrink(1);
        ServerPlayNetworking.send(sp, new AbsorbPayload(color)); // เริ่มอนิเมชั่นดูดซับฝั่งไคลเอนต์
        Soul.setPower(sp, Soul.maxPower(sp));
        server.sendParticles(ParticleTypes.ENCHANT,
                sp.getX(), sp.getY() + 1.0, sp.getZ(), 60, 0.6, 0.8, 0.6, 0.5);
        sp.sendSystemMessage(Component.literal(
                "ดูดซับวงแหวน" + Soul.RING_NAMES[color] + "สำเร็จ! (ครบ " + Soul.rings(sp).length() + " วง)"), false);
        return InteractionResult.SUCCESS;
    }
}
